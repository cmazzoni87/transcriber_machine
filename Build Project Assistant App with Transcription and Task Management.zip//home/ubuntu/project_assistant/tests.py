"""
Test script for the Personal Project Assistant.
This script tests the core components of the application.
"""

import os
import sys
from pathlib import Path
import unittest
import json
import datetime

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent))

# Import components to test
from src.database.db_manager import get_db_session
from src.database.models import User, Project, Meeting, Document, SlackMessage, Task
from src.database.vector_db import VectorDatabase
from src.ai.bedrock_ai import BedrockAI
from src.ai.prompt_manager import PromptManager
from src.ai.context_retriever import ContextRetriever
from src.ai.ai_assistant import AIAssistant
from src.integrations.slack import SlackIntegration, SlackAnalyzer, SlackService
from src.integrations.asana import AsanaIntegration, AsanaTaskManager, AsanaService
from src.recorder import transcribe, format_transcript


class TestDatabaseComponents(unittest.TestCase):
    """Test database components."""
    
    def setUp(self):
        """Set up test environment."""
        # Use an in-memory SQLite database for testing
        os.environ["DATABASE_URL"] = "sqlite:///:memory:"
    
    def test_database_connection(self):
        """Test database connection."""
        try:
            session = get_db_session()
            self.assertIsNotNone(session)
            print("Database connection test passed.")
        except Exception as e:
            self.fail(f"Database connection test failed: {e}")
    
    def test_model_relationships(self):
        """Test model relationships."""
        try:
            # Create test data
            with get_db_session() as session:
                # Create user
                user = User(
                    username="testuser",
                    email="test@example.com",
                    name="Test User"
                )
                session.add(user)
                session.commit()
                
                # Create project
                project = Project(
                    name="Test Project",
                    description="Test project description",
                    user_id=user.id
                )
                session.add(project)
                session.commit()
                
                # Create meeting
                meeting = Meeting(
                    title="Test Meeting",
                    date=datetime.datetime.now(),
                    duration=30,
                    project_id=project.id
                )
                session.add(meeting)
                session.commit()
                
                # Create document
                document = Document(
                    title="Test Document",
                    content="Test document content",
                    project_id=project.id,
                    user_id=user.id
                )
                session.add(document)
                session.commit()
                
                # Create Slack message
                slack_message = SlackMessage(
                    channel="test-channel",
                    user="testuser",
                    text="Test message",
                    timestamp=datetime.datetime.now(),
                    project_id=project.id
                )
                session.add(slack_message)
                session.commit()
                
                # Create task
                task = Task(
                    title="Test Task",
                    description="Test task description",
                    status="Not Started",
                    due_date=datetime.datetime.now() + datetime.timedelta(days=1),
                    project_id=project.id,
                    user_id=user.id
                )
                session.add(task)
                session.commit()
                
                # Test relationships
                self.assertEqual(project.user.id, user.id)
                self.assertEqual(meeting.project.id, project.id)
                self.assertEqual(document.project.id, project.id)
                self.assertEqual(document.user.id, user.id)
                self.assertEqual(slack_message.project.id, project.id)
                self.assertEqual(task.project.id, project.id)
                self.assertEqual(task.user.id, user.id)
                
                print("Model relationships test passed.")
        except Exception as e:
            self.fail(f"Model relationships test failed: {e}")


class TestVectorDatabase(unittest.TestCase):
    """Test vector database components."""
    
    def test_vector_db_initialization(self):
        """Test vector database initialization."""
        try:
            vector_db = VectorDatabase()
            self.assertIsNotNone(vector_db)
            print("Vector database initialization test passed.")
        except Exception as e:
            self.fail(f"Vector database initialization test failed: {e}")


class TestAIComponents(unittest.TestCase):
    """Test AI components."""
    
    def test_bedrock_ai_initialization(self):
        """Test BedrockAI initialization."""
        try:
            bedrock_ai = BedrockAI()
            self.assertIsNotNone(bedrock_ai)
            print("BedrockAI initialization test passed.")
        except Exception as e:
            self.fail(f"BedrockAI initialization test failed: {e}")
    
    def test_prompt_manager_initialization(self):
        """Test PromptManager initialization."""
        try:
            prompt_manager = PromptManager()
            self.assertIsNotNone(prompt_manager)
            print("PromptManager initialization test passed.")
        except Exception as e:
            self.fail(f"PromptManager initialization test failed: {e}")
    
    def test_context_retriever_initialization(self):
        """Test ContextRetriever initialization."""
        try:
            context_retriever = ContextRetriever()
            self.assertIsNotNone(context_retriever)
            print("ContextRetriever initialization test passed.")
        except Exception as e:
            self.fail(f"ContextRetriever initialization test failed: {e}")
    
    def test_ai_assistant_initialization(self):
        """Test AIAssistant initialization."""
        try:
            ai_assistant = AIAssistant()
            self.assertIsNotNone(ai_assistant)
            print("AIAssistant initialization test passed.")
        except Exception as e:
            self.fail(f"AIAssistant initialization test failed: {e}")


class TestIntegrationComponents(unittest.TestCase):
    """Test integration components."""
    
    def test_slack_integration_initialization(self):
        """Test SlackIntegration initialization."""
        try:
            # Use mock credentials for testing
            os.environ["SLACK_API_TOKEN"] = "xoxb-test-token"
            slack_integration = SlackIntegration()
            self.assertIsNotNone(slack_integration)
            print("SlackIntegration initialization test passed.")
        except Exception as e:
            self.fail(f"SlackIntegration initialization test failed: {e}")
    
    def test_slack_analyzer_initialization(self):
        """Test SlackAnalyzer initialization."""
        try:
            slack_analyzer = SlackAnalyzer()
            self.assertIsNotNone(slack_analyzer)
            print("SlackAnalyzer initialization test passed.")
        except Exception as e:
            self.fail(f"SlackAnalyzer initialization test failed: {e}")
    
    def test_slack_service_initialization(self):
        """Test SlackService initialization."""
        try:
            # Use mock credentials for testing
            os.environ["SLACK_API_TOKEN"] = "xoxb-test-token"
            slack_service = SlackService()
            self.assertIsNotNone(slack_service)
            print("SlackService initialization test passed.")
        except Exception as e:
            self.fail(f"SlackService initialization test failed: {e}")
    
    def test_asana_integration_initialization(self):
        """Test AsanaIntegration initialization."""
        try:
            # Use mock credentials for testing
            os.environ["ASANA_ACCESS_TOKEN"] = "test-token"
            asana_integration = AsanaIntegration()
            self.assertIsNotNone(asana_integration)
            print("AsanaIntegration initialization test passed.")
        except Exception as e:
            self.fail(f"AsanaIntegration initialization test failed: {e}")
    
    def test_asana_task_manager_initialization(self):
        """Test AsanaTaskManager initialization."""
        try:
            # Use mock credentials for testing
            os.environ["ASANA_ACCESS_TOKEN"] = "test-token"
            asana_task_manager = AsanaTaskManager()
            self.assertIsNotNone(asana_task_manager)
            print("AsanaTaskManager initialization test passed.")
        except Exception as e:
            self.fail(f"AsanaTaskManager initialization test failed: {e}")
    
    def test_asana_service_initialization(self):
        """Test AsanaService initialization."""
        try:
            # Use mock credentials for testing
            os.environ["ASANA_ACCESS_TOKEN"] = "test-token"
            asana_service = AsanaService()
            self.assertIsNotNone(asana_service)
            print("AsanaService initialization test passed.")
        except Exception as e:
            self.fail(f"AsanaService initialization test failed: {e}")


class TestRecorderComponents(unittest.TestCase):
    """Test recorder components."""
    
    def test_transcript_formatting(self):
        """Test transcript formatting."""
        try:
            # Create a mock transcript JSON
            mock_transcript = {
                "results": {
                    "items": [
                        {
                            "type": "pronunciation",
                            "start_time": "0.0",
                            "end_time": "0.5",
                            "alternatives": [{"content": "Hello"}],
                            "speaker_label": "spk_0"
                        },
                        {
                            "type": "punctuation",
                            "alternatives": [{"content": ","}]
                        },
                        {
                            "type": "pronunciation",
                            "start_time": "0.6",
                            "end_time": "1.0",
                            "alternatives": [{"content": "world"}],
                            "speaker_label": "spk_0"
                        },
                        {
                            "type": "punctuation",
                            "alternatives": [{"content": "."}]
                        }
                    ]
                }
            }
            
            # Write mock transcript to a temporary file
            temp_file = "temp_transcript.json"
            with open(temp_file, "w") as f:
                json.dump(mock_transcript, f)
            
            # Test formatting
            formatted = format_transcript(temp_file)
            self.assertIsNotNone(formatted)
            self.assertIn("SPEAKER_0", formatted)
            self.assertIn("Hello, world.", formatted)
            
            # Clean up
            os.remove(temp_file)
            
            print("Transcript formatting test passed.")
        except Exception as e:
            self.fail(f"Transcript formatting test failed: {e}")


def run_tests():
    """Run all tests."""
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test cases
    test_suite.addTest(unittest.makeSuite(TestDatabaseComponents))
    test_suite.addTest(unittest.makeSuite(TestVectorDatabase))
    test_suite.addTest(unittest.makeSuite(TestAIComponents))
    test_suite.addTest(unittest.makeSuite(TestIntegrationComponents))
    test_suite.addTest(unittest.makeSuite(TestRecorderComponents))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(test_suite)


if __name__ == "__main__":
    run_tests()
