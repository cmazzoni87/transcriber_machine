"""
Utils module for the Personal Project Assistant.
This module provides utility functions for transcript formatting.
"""

import os
import re
from datetime import datetime, timedelta
import json


def get_recording_start(filename):
    """
    Extracts the recording start datetime from the filename.
    Expected filename format: ..._YYYYMMDD_HHMMSS.json
    For example: audio_recording_20250214_164959.json
    Returns a datetime object representing that time.
    """
    base = os.path.basename(filename)
    base, _ = os.path.splitext(base)
    # Look for a pattern with 8 digits, an underscore, then 6 digits at the end
    match = re.search(r'(\d{8}_\d{6})$', base)
    if match:
        time_str = match.group(1)  # e.g., "20250214_164959"
        try:
            recording_start = datetime.strptime(time_str, "%Y%m%d_%H%M%S")
            return recording_start
        except ValueError:
            pass
    return None


def format_transcript(input_json_path):
    """
    Reads an AWS Transcribe JSON output file with speaker labels,
    groups consecutive items by speaker, and prints a conversation-style transcript.
    Each transcript line displays the absolute start and end times computed by adding
    the offset (in seconds) to the recording start time.
    """
    recording_start = get_recording_start(input_json_path)
    # Load the JSON data
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Grab the 'items' list from the transcription results
    items = data.get("results", {}).get("items", [])

    # We'll store conversation blocks as tuples:
    # (speaker_label, start_offset, end_offset, combined_text)
    conversation_blocks = []

    # Track the current speaker block
    current_speaker = None
    current_start = None
    current_end = None
    current_words = []

    for item in items:
        item_type = item.get("type")

        if item_type == "pronunciation":
            speaker_label = item.get("speaker_label", "spk_unknown")
            start_time = float(item["start_time"])
            end_time = float(item["end_time"])
            word = item["alternatives"][0]["content"]

            # If the speaker changes, finalize the current block
            if speaker_label != current_speaker:
                if current_speaker is not None:
                    conversation_blocks.append((
                        current_speaker,
                        current_start,
                        current_end,
                        " ".join(current_words)
                    ))
                # Start a new block
                current_speaker = speaker_label
                current_start = start_time
                current_end = end_time
                current_words = [word]
            else:
                # Same speaker: update end time and append word
                current_end = end_time
                current_words.append(word)

        elif item_type == "punctuation":
            punctuation = item["alternatives"][0]["content"]
            if current_words:
                # Append punctuation directly to the last word
                current_words[-1] = current_words[-1] + punctuation

    # Finalize the last block if it exists
    if current_speaker is not None:
        conversation_blocks.append((
            current_speaker,
            current_start,
            current_end,
            " ".join(current_words)
        ))
    transcript = []
    # Print the conversation blocks with absolute times if recording_start is provided
    for speaker, offset_start, offset_end, text in conversation_blocks:
        # Convert "spk_0" to "SPEAKER_0"
        speaker_name = speaker.replace("spk_", "SPEAKER_").upper()

        if recording_start:
            abs_start = recording_start + timedelta(seconds=offset_start)
            abs_end = recording_start + timedelta(seconds=offset_end)
            time_str = f"{abs_start.strftime('%H:%M:%S')}-{abs_end.strftime('%H:%M:%S')}"
        else:
            # Fallback: use offsets in seconds
            time_str = f"{offset_start:.2f}-{offset_end:.2f}"

        transcript.append(f"{speaker_name} [{time_str}]: {text}")
    return "\n".join(transcript)
