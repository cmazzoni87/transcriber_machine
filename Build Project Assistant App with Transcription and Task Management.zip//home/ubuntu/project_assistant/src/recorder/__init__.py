"""
__init__.py file for the recorder package.
Makes the recorder components importable from the recorder package.
"""

from .enhanced_recorder import main as start_recorder
from .transcriber import transcribe
from .utils import format_transcript

__all__ = [
    'start_recorder',
    'transcribe',
    'format_transcript'
]
