"""
Asana task manager module for the Personal Project Assistant.
This module handles task creation, updating, and management with Asana.
"""

import os
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json

# Import database components
from ...database.models import Task, Project, User
from ...database.db_manager import get_db_session

# Import AI components
from ...ai.ai_assistant import AIAssistant

# Import Asana client
from .asana_client import AsanaIntegration

class AsanaTaskManager:
    """
    Asana task manager for creating and managing tasks.
    Handles task creation, updating, and synchronization with the database.
    """
    
    def __init__(self, 
                asana_client: Optional[AsanaIntegration] = None,
                ai_assistant: Optional[AIAssistant] = None):
        """
        Initialize the Asana task manager.
        
        Args:
            asana_client: Asana client instance (creates new one if not provided)
            ai_assistant: AI assistant instance (creates new one if not provided)
        """
        self.asana_client = asana_client or AsanaIntegration()
        self.ai_assistant = ai_assistant or AIAssistant()
    
    def create_task_from_description(self, 
                                   description: str, 
                                   project_id: str, 
                                   assignee: Optional[str] = None, 
                                   due_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a task from a natural language description using AI assistance.
        
        Args:
            description: Natural language task description
            project_id: Project ID in Asana
            assignee: Optional assignee user ID in Asana
            due_date: Optional due date (YYYY-MM-DD)
            
        Returns:
            Created task information
        """
        # Get project name
        project_name = "Unknown Project"
        try:
            # This would typically be a database query
            # For now, we'll get the project directly from Asana
            projects = self.asana_client.get_projects(project_id.split("/")[0])  # Workspace ID
            project = next((p for p in projects if p["id"] == project_id), None)
            if project:
                project_name = project["name"]
        except Exception as e:
            print(f"Error getting project name: {e}")
        
        # Use AI to format the task
        task_data = self.ai_assistant.create_task(
            project=project_name,
            description=description,
            deadline=due_date,
            assignee=assignee
        )
        
        # Extract task data
        task_title = task_data.get("task_data", {}).get("title", description[:50])
        task_notes = task_data.get("task_data", {}).get("description", description)
        
        # Create task in Asana
        asana_task = self.asana_client.create_task(
            name=task_title,
            project_id=project_id,
            notes=task_notes,
            assignee=assignee,
            due_date=due_date
        )
        
        # Store task in database
        self._store_task_in_database(asana_task, project_id)
        
        return {
            "asana_task": asana_task,
            "formatted_task": task_data.get("formatted_task", "")
        }
    
    def create_tasks_from_meeting(self, 
                                transcript: str, 
                                project_id: str) -> List[Dict[str, Any]]:
        """
        Create tasks from a meeting transcript using AI assistance.
        
        Args:
            transcript: Meeting transcript
            project_id: Project ID in Asana
            
        Returns:
            List of created task information
        """
        # Summarize meeting and extract action items
        meeting_summary = self.ai_assistant.summarize_meeting(transcript)
        action_items = meeting_summary.get("action_items", [])
        
        if not action_items:
            return []
        
        # Create tasks for each action item
        created_tasks = []
        for item in action_items:
            # Extract task information
            task_title = item.get("task", "")
            assignee_name = item.get("assignee", "")
            deadline = item.get("deadline", "")
            
            # Skip if no task title
            if not task_title:
                continue
            
            # Find assignee in Asana (simplified approach)
            assignee_id = None
            
            # Create task
            task = self.asana_client.create_task(
                name=task_title,
                project_id=project_id,
                notes=f"Action item from meeting transcript:\n\n{transcript[:500]}...",
                assignee=assignee_id,
                due_date=deadline if deadline else None
            )
            
            # Store task in database
            self._store_task_in_database(task, project_id)
            
            created_tasks.append({
                "asana_task": task,
                "action_item": item
            })
        
        return created_tasks
    
    def create_tasks_from_slack(self, 
                              conversation: str, 
                              project_id: str) -> List[Dict[str, Any]]:
        """
        Create tasks from a Slack conversation using AI assistance.
        
        Args:
            conversation: Slack conversation text
            project_id: Project ID in Asana
            
        Returns:
            List of created task information
        """
        # Analyze conversation and extract action items
        conversation_analysis = self.ai_assistant.analyze_slack_conversation(conversation)
        action_items = conversation_analysis.get("action_items", [])
        
        if not action_items:
            return []
        
        # Create tasks for each action item
        created_tasks = []
        for item in action_items:
            # Extract task information
            task_title = item.get("task", "")
            assignee_name = item.get("assignee", "")
            deadline = item.get("deadline", "")
            
            # Skip if no task title
            if not task_title:
                continue
            
            # Find assignee in Asana (simplified approach)
            assignee_id = None
            
            # Create task
            task = self.asana_client.create_task(
                name=task_title,
                project_id=project_id,
                notes=f"Action item from Slack conversation:\n\n{conversation[:500]}...",
                assignee=assignee_id,
                due_date=deadline if deadline else None
            )
            
            # Store task in database
            self._store_task_in_database(task, project_id)
            
            created_tasks.append({
                "asana_task": task,
                "action_item": item
            })
        
        return created_tasks
    
    def update_task(self, 
                  task_id: str, 
                  name: Optional[str] = None, 
                  notes: Optional[str] = None, 
                  assignee: Optional[str] = None, 
                  due_date: Optional[str] = None, 
                  completed: Optional[bool] = None) -> Dict[str, Any]:
        """
        Update a task in Asana and the database.
        
        Args:
            task_id: Task ID in Asana
            name: Optional new task name
            notes: Optional new task description
            assignee: Optional new assignee user ID
            due_date: Optional new due date (YYYY-MM-DD)
            completed: Optional completion status
            
        Returns:
            Updated task information
        """
        # Update task in Asana
        asana_task = self.asana_client.update_task(
            task_id=task_id,
            name=name,
            notes=notes,
            assignee=assignee,
            due_date=due_date,
            completed=completed
        )
        
        # Update task in database
        self._update_task_in_database(asana_task)
        
        return asana_task
    
    def complete_task(self, task_id: str) -> Dict[str, Any]:
        """
        Mark a task as completed.
        
        Args:
            task_id: Task ID in Asana
            
        Returns:
            Updated task information
        """
        return self.update_task(task_id=task_id, completed=True)
    
    def get_project_tasks(self, 
                        project_id: str, 
                        include_completed: bool = False) -> List[Dict[str, Any]]:
        """
        Get tasks for a project.
        
        Args:
            project_id: Project ID in Asana
            include_completed: Whether to include completed tasks
            
        Returns:
            List of task information
        """
        return self.asana_client.get_tasks(
            project_id=project_id,
            completed=include_completed
        )
    
    def get_user_tasks(self, 
                     workspace_id: str, 
                     user_id: Optional[str] = None, 
                     include_completed: bool = False) -> List[Dict[str, Any]]:
        """
        Get tasks assigned to a user.
        
        Args:
            workspace_id: Workspace ID in Asana
            user_id: User ID in Asana (defaults to current user)
            include_completed: Whether to include completed tasks
            
        Returns:
            List of task information
        """
        return self.asana_client.get_user_tasks(
            workspace_id=workspace_id,
            user_id=user_id,
            completed=include_completed
        )
    
    def sync_tasks_with_database(self, project_id: str) -> Dict[str, int]:
        """
        Synchronize tasks between Asana and the database.
        
        Args:
            project_id: Project ID in Asana
            
        Returns:
            Synchronization statistics
        """
        # Get tasks from Asana
        asana_tasks = self.asana_client.get_tasks(
            project_id=project_id,
            completed=True  # Include completed tasks
        )
        
        # Get tasks from database
        db_tasks = []
        try:
            with get_db_session() as session:
                db_tasks = session.query(Task).filter_by(
                    project_id=project_id
                ).all()
        except Exception as e:
            print(f"Error getting tasks from database: {e}")
        
        # Track statistics
        stats = {
            "created": 0,
            "updated": 0,
            "unchanged": 0
        }
        
        # Process each Asana task
        for asana_task in asana_tasks:
            # Check if task exists in database
            db_task = next((t for t in db_tasks if t.asana_id == asana_task["id"]), None)
            
            if db_task:
                # Update existing task
                updated = self._update_task_in_database(asana_task)
                if updated:
                    stats["updated"] += 1
                else:
                    stats["unchanged"] += 1
            else:
                # Create new task
                self._store_task_in_database(asana_task, project_id)
                stats["created"] += 1
        
        return stats
    
    def _store_task_in_database(self, 
                              asana_task: Dict[str, Any], 
                              project_id: str) -> bool:
        """
        Store a task in the database.
        
        Args:
            asana_task: Task information from Asana
            project_id: Project ID in the database
            
        Returns:
            Success status
        """
        try:
            with get_db_session() as session:
                # Check if task already exists
                existing_task = session.query(Task).filter_by(
                    asana_id=asana_task["id"]
                ).first()
                
                if existing_task:
                    # Update existing task
                    existing_task.title = asana_task["name"]
                    existing_task.description = asana_task.get("notes", "")
                    existing_task.status = "completed" if asana_task.get("completed", False) else "active"
                    
                    if asana_task.get("due_date"):
                        existing_task.due_date = datetime.fromisoformat(asana_task["due_date"].replace("Z", "+00:00"))
                    
                    if asana_task.get("assignee"):
                        # This would typically look up the user in the database
                        # For now, we'll just store the Asana user ID
                        existing_task.assigned_to = None
                    
                    existing_task.updated_at = datetime.now()
                    
                    session.commit()
                    return True
                else:
                    # Create new task
                    new_task = Task(
                        project_id=project_id,
                        asana_id=asana_task["id"],
                        title=asana_task["name"],
                        description=asana_task.get("notes", ""),
                        status="completed" if asana_task.get("completed", False) else "active"
                    )
                    
                    if asana_task.get("due_date"):
                        new_task.due_date = datetime.fromisoformat(asana_task["due_date"].replace("Z", "+00:00"))
                    
                    if asana_task.get("assignee"):
                        # This would typically look up the user in the database
                        # For now, we'll just store the Asana user ID
                        new_task.assigned_to = None
                    
                    session.add(new_task)
                    session.commit()
                    return True
        except Exception as e:
            print(f"Error storing task in database: {e}")
            return False
    
    def _update_task_in_database(self, asana_task: Dict[str, Any]) -> bool:
        """
        Update a task in the database.
        
        Args:
            asana_task: Task information from Asana
            
        Returns:
            Success status
        """
        try:
            with get_db_session() as session:
                # Find task in database
                db_task = session.query(Task).filter_by(
                    asana_id=asana_task["id"]
                ).first()
                
                if not db_task:
                    return False
                
                # Check if update is needed
                needs_update = False
                
                if db_task.title != asana_task["name"]:
                    db_task.title = asana_task["name"]
                    needs_update = True
                
                if db_task.description != asana_task.get("notes", ""):
                    db_task.description = asana_task.get("notes", "")
                    needs_update = True
                
                new_status = "completed" if asana_task.get("completed", False) else "active"
                if db_task.status != new_status:
                    db_task.status = new_status
                    needs_update = True
                
                if asana_task.get("due_date"):
                    new_due_date = datetime.fromisoformat(asana_task["due_date"].replace("Z", "+00:00"))
                    if not db_task.due_date or db_task.due_date.date() != new_due_date.date():
                        db_task.due_date = new_due_date
                        needs_update = True
                elif db_task.due_date:
         <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>