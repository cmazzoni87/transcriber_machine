"""
Asana service module for the Personal Project Assistant.
This module provides high-level functions for interacting with Asana.
"""

import os
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json

# Import Asana components
from .asana_client import AsanaIntegration
from .asana_task_manager import AsanaTaskManager

# Import database components
from ...database.models import Task, Project, User
from ...database.db_manager import get_db_session

class AsanaService:
    """
    Asana service for high-level Asana operations.
    Provides a unified interface for Asana integration.
    """
    
    def __init__(self, 
                asana_client: Optional[AsanaIntegration] = None,
                asana_task_manager: Optional[AsanaTaskManager] = None):
        """
        Initialize the Asana service.
        
        Args:
            asana_client: Asana client instance (creates new one if not provided)
            asana_task_manager: Asana task manager instance (creates new one if not provided)
        """
        self.asana_client = asana_client or AsanaIntegration()
        self.asana_task_manager = asana_task_manager or AsanaTaskManager(asana_client=self.asana_client)
    
    def get_workspaces(self) -> List[Dict[str, Any]]:
        """
        Get list of workspaces.
        
        Returns:
            List of workspace information
        """
        return self.asana_client.get_workspaces()
    
    def get_projects(self, workspace_id: str) -> List[Dict[str, Any]]:
        """
        Get list of projects in a workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            List of project information
        """
        return self.asana_client.get_projects(workspace_id)
    
    def get_tasks(self, 
                project_id: str, 
                include_completed: bool = False) -> List[Dict[str, Any]]:
        """
        Get tasks for a project.
        
        Args:
            project_id: Project ID
            include_completed: Whether to include completed tasks
            
        Returns:
            List of task information
        """
        return self.asana_client.get_tasks(
            project_id=project_id,
            completed=include_completed
        )
    
    def get_task(self, task_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            Task information
        """
        return self.asana_client.get_task(task_id)
    
    def create_task(self, 
                  name: str, 
                  project_id: str, 
                  notes: Optional[str] = None, 
                  assignee: Optional[str] = None, 
                  due_date: Optional[str] = None, 
                  tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Create a new task in a project.
        
        Args:
            name: Task name
            project_id: Project ID
            notes: Optional task description
            assignee: Optional assignee user ID
            due_date: Optional due date (YYYY-MM-DD)
            tags: Optional list of tag names
            
        Returns:
            Created task information
        """
        return self.asana_client.create_task(
            name=name,
            project_id=project_id,
            notes=notes,
            assignee=assignee,
            due_date=due_date,
            tags=tags
        )
    
    def create_task_from_description(self, 
                                   description: str, 
                                   project_id: str, 
                                   assignee: Optional[str] = None, 
                                   due_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a task from a natural language description using AI assistance.
        
        Args:
            description: Natural language task description
            project_id: Project ID
            assignee: Optional assignee user ID
            due_date: Optional due date (YYYY-MM-DD)
            
        Returns:
            Created task information
        """
        return self.asana_task_manager.create_task_from_description(
            description=description,
            project_id=project_id,
            assignee=assignee,
            due_date=due_date
        )
    
    def create_tasks_from_meeting(self, 
                                transcript: str, 
                                project_id: str) -> List[Dict[str, Any]]:
        """
        Create tasks from a meeting transcript using AI assistance.
        
        Args:
            transcript: Meeting transcript
            project_id: Project ID
            
        Returns:
            List of created task information
        """
        return self.asana_task_manager.create_tasks_from_meeting(
            transcript=transcript,
            project_id=project_id
        )
    
    def create_tasks_from_slack(self, 
                              conversation: str, 
                              project_id: str) -> List[Dict[str, Any]]:
        """
        Create tasks from a Slack conversation using AI assistance.
        
        Args:
            conversation: Slack conversation text
            project_id: Project ID
            
        Returns:
            List of created task information
        """
        return self.asana_task_manager.create_tasks_from_slack(
            conversation=conversation,
            project_id=project_id
        )
    
    def update_task(self, 
                  task_id: str, 
                  name: Optional[str] = None, 
                  notes: Optional[str] = None, 
                  assignee: Optional[str] = None, 
                  due_date: Optional[str] = None, 
                  completed: Optional[bool] = None) -> Dict[str, Any]:
        """
        Update an existing task.
        
        Args:
            task_id: Task ID
            name: Optional new task name
            notes: Optional new task description
            assignee: Optional new assignee user ID
            due_date: Optional new due date (YYYY-MM-DD)
            completed: Optional completion status
            
        Returns:
            Updated task information
        """
        return self.asana_task_manager.update_task(
            task_id=task_id,
            name=name,
            notes=notes,
            assignee=assignee,
            due_date=due_date,
            completed=completed
        )
    
    def complete_task(self, task_id: str) -> Dict[str, Any]:
        """
        Mark a task as completed.
        
        Args:
            task_id: Task ID
            
        Returns:
            Updated task information
        """
        return self.asana_task_manager.complete_task(task_id)
    
    def delete_task(self, task_id: str) -> Dict[str, bool]:
        """
        Delete a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            Success status
        """
        return self.asana_client.delete_task(task_id)
    
    def add_comment(self, 
                  task_id: str, 
                  text: str) -> Dict[str, Any]:
        """
        Add a comment to a task.
        
        Args:
            task_id: Task ID
            text: Comment text
            
        Returns:
            Created comment information
        """
        return self.asana_client.add_comment(
            task_id=task_id,
            text=text
        )
    
    def get_task_comments(self, task_id: str) -> List[Dict[str, Any]]:
        """
        Get comments on a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            List of comment information
        """
        return self.asana_client.get_task_comments(task_id)
    
    def search_tasks(self, 
                   workspace_id: str, 
                   query: str, 
                   limit: int = 100) -> List[Dict[str, Any]]:
        """
        Search for tasks in a workspace.
        
        Args:
            workspace_id: Workspace ID
            query: Search query
            limit: Maximum number of results
            
        Returns:
            List of matching task information
        """
        return self.asana_client.search_tasks(
            workspace_id=workspace_id,
            query=query,
            limit=limit
        )
    
    def get_user_tasks(self, 
                     workspace_id: str, 
                     user_id: Optional[str] = None, 
                     include_completed: bool = False) -> List[Dict[str, Any]]:
        """
        Get tasks assigned to a user.
        
        Args:
            workspace_id: Workspace ID
            user_id: User ID (defaults to current user)
            include_completed: Whether to include completed tasks
            
        Returns:
            List of task information
        """
        return self.asana_task_manager.get_user_tasks(
            workspace_id=workspace_id,
            user_id=user_id,
            include_completed=include_completed
        )
    
    def sync_tasks_with_database(self, project_id: str) -> Dict[str, int]:
        """
        Synchronize tasks between Asana and the database.
        
        Args:
            project_id: Project ID
            
        Returns:
            Synchronization statistics
        """
        return self.asana_task_manager.sync_tasks_with_database(project_id)
    
    def create_subtask(self, 
                     parent_id: str, 
                     name: str, 
                     notes: Optional[str] = None, 
                     assignee: Optional[str] = None, 
                     due_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a subtask under a parent task.
        
        Args:
            parent_id: Parent task ID
            name: Subtask name
            notes: Optional subtask description
            assignee: Optional assignee user ID
            due_date: Optional due date (YYYY-MM-DD)
            
        Returns:
            Created subtask information
        """
        return self.asana_client.create_subtask(
            parent_id=parent_id,
            name=name,
            notes=notes,
            assignee=assignee,
            due_date=due_date
        )
