"""
__init__.py file for the Slack integration package.
Makes the Slack components importable from the Slack package.
"""

from .slack_client import SlackIntegration
from .slack_analyzer import SlackAnalyzer
from .slack_service import SlackService

__all__ = [
    'SlackIntegration',
    'SlackAnalyzer',
    'SlackService'
]
