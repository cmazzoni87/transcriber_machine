"""
Slack service module for the Personal Project Assistant.
This module provides high-level functions for interacting with Slack.
"""

import os
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json
import time
import threading

# Import Slack components
from .slack_client import SlackIntegration
from .slack_analyzer import SlackAnalyzer

# Import database components
from ...database.models import SlackMessage, SlackChannel, SlackWorkspace, Project
from ...database.db_manager import get_db_session

class SlackService:
    """
    Slack service for high-level Slack operations.
    Provides a unified interface for Slack integration.
    """
    
    def __init__(self, 
                slack_client: Optional[SlackIntegration] = None,
                slack_analyzer: Optional[SlackAnalyzer] = None):
        """
        Initialize the Slack service.
        
        Args:
            slack_client: Slack client instance (creates new one if not provided)
            slack_analyzer: Slack analyzer instance (creates new one if not provided)
        """
        self.slack_client = slack_client or SlackIntegration()
        self.slack_analyzer = slack_analyzer or SlackAnalyzer(slack_client=self.slack_client)
        self.monitor_thread = None
        self.stop_monitoring = threading.Event()
    
    def get_workspace_info(self) -> Dict[str, Any]:
        """
        Get information about the connected Slack workspace.
        
        Returns:
            Workspace information
        """
        return self.slack_client.get_workspace_info()
    
    def get_channels(self, include_private: bool = False) -> List[Dict[str, Any]]:
        """
        Get list of channels in the workspace.
        
        Args:
            include_private: Whether to include private channels
            
        Returns:
            List of channel information
        """
        return self.slack_client.get_channels(include_private=include_private)
    
    def get_channel_messages(self, 
                           channel_id: str, 
                           limit: int = 100, 
                           days_back: int = 7) -> List[Dict[str, Any]]:
        """
        Get messages from a channel.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to retrieve
            days_back: Number of days back to retrieve messages from
            
        Returns:
            List of messages
        """
        # Calculate oldest timestamp
        oldest = str(int((datetime.now() - timedelta(days=days_back)).timestamp()))
        
        return self.slack_client.get_channel_messages(
            channel_id=channel_id,
            limit=limit,
            oldest=oldest
        )
    
    def analyze_channel(self, 
                      channel_id: str, 
                      limit: int = 100, 
                      days_back: int = 7) -> Dict[str, Any]:
        """
        Analyze messages from a channel.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to analyze
            days_back: Number of days back to analyze messages from
            
        Returns:
            Analysis results
        """
        # Get messages
        messages = self.get_channel_messages(
            channel_id=channel_id,
            limit=limit,
            days_back=days_back
        )
        
        if not messages:
            return {
                "channel_id": channel_id,
                "message_count": 0,
                "analysis": "No messages found",
                "project_matches": []
            }
        
        # Get channel info
        channels = self.slack_client.get_channels()
        channel = next((c for c in channels if c["id"] == channel_id), {"id": channel_id, "name": "Unknown"})
        
        # Analyze conversation
        conversation_analysis = self.slack_analyzer.analyze_conversation(messages)
        
        # Match to projects
        project_matches = self.slack_analyzer.match_to_project(
            text="\n".join([m.get("text", "") for m in messages]),
            embedding=conversation_analysis.get("embedding")
        )
        
        return {
            "channel_id": channel_id,
            "channel_name": channel.get("name", "Unknown"),
            "message_count": len(messages),
            "analysis": conversation_analysis.get("analysis", ""),
            "action_items": conversation_analysis.get("action_items", []),
            "project_matches": project_matches
        }
    
    def search_messages(self, query: str, count: int = 100) -> List[Dict[str, Any]]:
        """
        Search for messages across all channels.
        
        Args:
            query: Search query
            count: Maximum number of results
            
        Returns:
            List of matching messages
        """
        return self.slack_client.search_messages(
            query=query,
            count=count
        )
    
    def send_message(self, 
                   channel_id: str, 
                   text: str, 
                   thread_ts: Optional[str] = None) -> Dict[str, Any]:
        """
        Send a message to a channel.
        
        Args:
            channel_id: Channel ID
            text: Message text
            thread_ts: Optional thread timestamp to reply to
            
        Returns:
            Response dictionary
        """
        return self.slack_client.send_message(
            channel_id=channel_id,
            text=text,
            thread_ts=thread_ts
        )
    
    def process_channel(self, 
                      channel_id: str, 
                      limit: int = 100, 
                      days_back: int = 1) -> Dict[str, Any]:
        """
        Process messages from a channel and store them in the database.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to process
            days_back: Number of days back to process messages from
            
        Returns:
            Processing results
        """
        # Calculate oldest timestamp
        oldest = str(int((datetime.now() - timedelta(days=days_back)).timestamp()))
        
        return self.slack_analyzer.process_new_messages(
            channel_id=channel_id,
            limit=limit,
            since=oldest
        )
    
    def start_monitoring(self, 
                       channel_ids: Optional[List[str]] = None, 
                       interval: int = 3600) -> None:
        """
        Start monitoring channels for new messages in a background thread.
        
        Args:
            channel_ids: List of channel IDs to monitor (defaults to all channels)
            interval: Monitoring interval in seconds
        """
        if self.monitor_thread and self.monitor_thread.is_alive():
            print("Monitoring is already running")
            return
        
        # Reset stop event
        self.stop_monitoring.clear()
        
        # Get all channels if not specified
        if not channel_ids:
            channels = self.slack_client.get_channels()
            channel_ids = [c["id"] for c in channels]
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_worker,
            args=(channel_ids, interval)
        )
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        print(f"Started monitoring {len(channel_ids)} channels with interval {interval} seconds")
    
    def stop_monitoring(self) -> None:
        """Stop monitoring channels."""
        if not self.monitor_thread or not self.monitor_thread.is_alive():
            print("Monitoring is not running")
            return
        
        # Set stop event
        self.stop_monitoring.set()
        
        # Wait for thread to finish
        self.monitor_thread.join(timeout=10)
        
        print("Stopped monitoring channels")
    
    def _monitoring_worker(self, channel_ids: List[str], interval: int) -> None:
        """
        Worker function for monitoring channels.
        
        Args:
            channel_ids: List of channel IDs to monitor
            interval: Monitoring interval in seconds
        """
        print(f"Monitoring {len(channel_ids)} channels for new messages...")
        
        try:
            while not self.stop_monitoring.is_set():
                # Process each channel
                for channel_id in channel_ids:
                    if self.stop_monitoring.is_set():
                        break
                    
                    print(f"Processing channel {channel_id}...")
                    result = self.slack_analyzer.process_new_messages(channel_id)
                    print(f"Processed {result['processed_count']} of {result['message_count']} messages in channel {result['channel']['name']}")
                
                # Wait for next interval or until stop event is set
                print(f"Waiting for next monitoring cycle...")
                self.stop_monitoring.wait(timeout=interval)
        except Exception as e:
            print(f"Error during monitoring: {e}")
    
    def get_project_messages(self, project_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get messages associated with a project.
        
        Args:
            project_id: Project ID
            limit: Maximum number of messages to retrieve
            
        Returns:
            List of messages
        """
        messages = []
        
        try:
            # Get messages from database
            with get_db_session() as session:
                db_messages = session.query(SlackMessage).filter_by(
                    project_id=project_id
                ).order_by(
                    SlackMessage.timestamp.desc()
                ).limit(limit).all()
                
                for msg in db_messages:
                    # Get channel info
                    channel = session.query(SlackChannel).filter_by(
                        id=msg.channel_id
                    ).first()
                    
                    # Format message
                    formatted_msg = {
                        "id": msg.message_id,
                        "text": msg.message,
                        "sender": msg.sender,
                        "timestamp": msg.timestamp.isoformat(),
                        "channel": {
                            "id": channel.channel_id if channel else "Unknown",
                            "name": channel.name if channel else "Unknown"
                        }
                    }
                    
                    messages.append(formatted_msg)
            
            return messages
        except Exception as e:
            print(f"Error getting project messages: {e}")
            return []
