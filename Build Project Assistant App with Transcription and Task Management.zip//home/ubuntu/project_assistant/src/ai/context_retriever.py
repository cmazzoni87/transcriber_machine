"""
Context retrieval module for the Personal Project Assistant.
This module handles the retrieval of relevant context for AI interactions.
"""

import os
from typing import List, Dict, Any, Optional, Union
from dotenv import load_dotenv

# Import database components
from ..database.memory_manager import MemoryManager
from ..database.vector_db import VectorDatabase

# Import AI components
from .bedrock_ai import BedrockAI

# Load environment variables
load_dotenv()

class ContextRetriever:
    """
    Context retriever for retrieving relevant information for AI interactions.
    Implements retrieval augmented generation (RAG) with vector search and graph traversal.
    """
    
    def __init__(self, 
                memory_manager: Optional[MemoryManager] = None,
                vector_db: Optional[VectorDatabase] = None,
                bedrock_ai: Optional[BedrockAI] = None):
        """
        Initialize the context retriever.
        
        Args:
            memory_manager: Memory manager instance (creates new one if not provided)
            vector_db: Vector database instance (creates new one if not provided)
            bedrock_ai: Bedrock AI instance (creates new one if not provided)
        """
        self.vector_db = vector_db or VectorDatabase()
        self.memory_manager = memory_manager or MemoryManager(self.vector_db)
        self.bedrock_ai = bedrock_ai or BedrockAI()
    
    def retrieve_context_for_query(self, 
                                 query: str, 
                                 project_id: Optional[str] = None,
                                 max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve context for a query using vector search and graph traversal.
        
        Args:
            query: User query
            project_id: Optional project ID to filter results
            max_results: Maximum number of results to return
            
        Returns:
            List of context items with content and metadata
        """
        # Generate embeddings for the query
        query_embedding = self.bedrock_ai.generate_embeddings(query)
        
        if not query_embedding:
            print("Error generating embeddings for query")
            return []
        
        # Retrieve context using memory manager
        raw_context = self.memory_manager.retrieve_context(
            query_embedding=query_embedding,
            project_id=project_id,
            max_results=max_results
        )
        
        # Format context items
        context_items = []
        
        # Add documents
        for doc in raw_context.get("documents", []):
            context_items.append({
                "type": "document",
                "content": doc.get("metadata", {}).get("content", ""),
                "metadata": {
                    "title": doc.get("metadata", {}).get("title", "Untitled Document"),
                    "project_id": doc.get("metadata", {}).get("project_id", ""),
                    "created_at": doc.get("metadata", {}).get("created_at", ""),
                    "score": doc.get("score", 0)
                }
            })
        
        # Add transcripts
        for transcript in raw_context.get("transcripts", []):
            context_items.append({
                "type": "transcript",
                "content": transcript.get("metadata", {}).get("content", ""),
                "metadata": {
                    "title": transcript.get("metadata", {}).get("title", "Untitled Meeting"),
                    "project_id": transcript.get("metadata", {}).get("project_id", ""),
                    "meeting_date": transcript.get("metadata", {}).get("meeting_date", ""),
                    "participants": transcript.get("metadata", {}).get("participants", []),
                    "score": transcript.get("score", 0)
                }
            })
        
        # Add messages
        for message in raw_context.get("messages", []):
            context_items.append({
                "type": "message",
                "content": message.get("metadata", {}).get("content", ""),
                "metadata": {
                    "sender": message.get("metadata", {}).get("sender", "Unknown"),
                    "channel": message.get("metadata", {}).get("channel", "Unknown"),
                    "project_id": message.get("metadata", {}).get("project_id", ""),
                    "timestamp": message.get("metadata", {}).get("timestamp", ""),
                    "score": message.get("score", 0)
                }
            })
        
        # Sort by relevance score
        context_items.sort(key=lambda x: x.get("metadata", {}).get("score", 0), reverse=True)
        
        return context_items[:max_results]
    
    def retrieve_project_context(self, 
                               project_id: str, 
                               max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve context for a specific project.
        
        Args:
            project_id: Project ID
            max_results: Maximum number of results to return
            
        Returns:
            List of context items with content and metadata
        """
        # Create a filter for the project
        filter_dict = {"project_id": project_id}
        
        # Get recent documents
        documents = self.vector_db.search_documents(
            query_embedding=[0.0] * 1536,  # Dummy embedding for recent items
            top_k=max_results,
            filter_dict=filter_dict
        )
        
        # Get recent transcripts
        transcripts = self.vector_db.search_transcripts(
            query_embedding=[0.0] * 1536,  # Dummy embedding for recent items
            top_k=max_results,
            filter_dict=filter_dict
        )
        
        # Get recent messages
        messages = self.vector_db.search_messages(
            query_embedding=[0.0] * 1536,  # Dummy embedding for recent items
            top_k=max_results,
            filter_dict=filter_dict
        )
        
        # Format context items
        context_items = []
        
        # Add documents
        for doc in documents:
            context_items.append({
                "type": "document",
                "content": doc.get("metadata", {}).get("content", ""),
                "metadata": {
                    "title": doc.get("metadata", {}).get("title", "Untitled Document"),
                    "project_id": project_id,
                    "created_at": doc.get("metadata", {}).get("created_at", "")
                }
            })
        
        # Add transcripts
        for transcript in transcripts:
            context_items.append({
                "type": "transcript",
                "content": transcript.get("metadata", {}).get("content", ""),
                "metadata": {
                    "title": transcript.get("metadata", {}).get("title", "Untitled Meeting"),
                    "project_id": project_id,
                    "meeting_date": transcript.get("metadata", {}).get("meeting_date", ""),
                    "participants": transcript.get("metadata", {}).get("participants", [])
                }
            })
        
        # Add messages
        for message in messages:
            context_items.append({
                "type": "message",
                "content": message.get("metadata", {}).get("content", ""),
                "metadata": {
                    "sender": message.get("metadata", {}).get("sender", "Unknown"),
                    "channel": message.get("metadata", {}).get("channel", "Unknown"),
                    "project_id": project_id,
                    "timestamp": message.get("metadata", {}).get("timestamp", "")
                }
            })
        
        return context_items[:max_results]
    
    def retrieve_document_context(self, 
                                document_id: str, 
                                max_results: int = 3) -> List[Dict[str, Any]]:
        """
        Retrieve context for a specific document and related documents.
        
        Args:
            document_id: Document ID
            max_results: Maximum number of related documents to return
            
        Returns:
            List of context items with content and metadata
        """
        # Get the document
        document = None
        try:
            # This would typically be a database query
            # For now, we'll use the vector database
            documents = self.vector_db.search_documents(
                query_embedding=[0.0] * 1536,  # Dummy embedding
                top_k=1,
                filter_dict={"id": document_id}
            )
            if documents:
                document = documents[0]
        except Exception as e:
            print(f"Error retrieving document: {e}")
            return []
        
        if not document:
            return []
        
        # Get document content and metadata
        document_content = document.get("metadata", {}).get("content", "")
        document_metadata = {
            "title": document.get("metadata", {}).get("title", "Untitled Document"),
            "project_id": document.get("metadata", {}).get("project_id", ""),
            "created_at": document.get("metadata", {}).get("created_at", "")
        }
        
        # Create embedding for the document
        document_embedding = self.bedrock_ai.generate_embeddings(document_content)
        
        if not document_embedding:
            # If we can't generate embeddings, just return the document
            return [{
                "type": "document",
                "content": document_content,
                "metadata": document_metadata
            }]
        
        # Find related documents
        related_documents = self.vector_db.search_documents(
            query_embedding=document_embedding,
            top_k=max_results + 1,  # +1 because the document itself will be included
            filter_dict={"project_id": document_metadata.get("project_id", "")}
        )
        
        # Format context items
        context_items = [{
            "type": "document",
            "content": document_content,
            "metadata": document_metadata
        }]
        
        # Add related documents (excluding the document itself)
        for doc in related_documents:
            if doc.get("id") != document_id:
                context_items.append({
                    "type": "document",
                    "content": doc.get("metadata", {}).get("content", ""),
                    "metadata": {
                        "title": doc.get("metadata", {}).get("title", "Related Document"),
                        "project_id": doc.get("metadata", {}).get("project_id", ""),
                        "created_at": doc.get("metadata", {}).get("created_at", ""),
                        "score": doc.get("score", 0)
                    }
                })
        
        return context_items[:max_results + 1]  # Include original document plus related ones
    
    def close(self):
        """Close connections and clean up resources."""
        if self.memory_manager:
            self.memory_manager.close()
        if self.vector_db:
            self.vector_db.close()
