"""
Main Streamlit application for the Personal Project Assistant.
This module provides the frontend interface for the application.
"""

import os
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import json
import sys
from pathlib import Path

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import database components
from src.database.db_manager import get_db_session
from src.database.models import Project, Meeting, Document, SlackMessage, Task, User

# Import AI components
from src.ai.ai_assistant import AIAssistant

# Import integration components
from src.integrations.slack.slack_service import SlackService
from src.integrations.asana.asana_service import AsanaService

# Set page configuration
st.set_page_config(
    page_title="Personal Project Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "current_user" not in st.session_state:
    st.session_state.current_user = None
if "ai_assistant" not in st.session_state:
    st.session_state.ai_assistant = None
if "slack_service" not in st.session_state:
    st.session_state.slack_service = None
if "asana_service" not in st.session_state:
    st.session_state.asana_service = None
if "current_project" not in st.session_state:
    st.session_state.current_project = None

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .section-header {
        font-size: 1.8rem;
        font-weight: bold;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .card {
        padding: 1.5rem;
        border-radius: 0.5rem;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
    }
    .highlight {
        background-color: #e9f5ff;
        padding: 0.5rem;
        border-radius: 0.3rem;
    }
    .sidebar-header {
        font-size: 1.2rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

def login_page():
    """Display the login page."""
    st.markdown('<div class="main-header">Personal Project Assistant</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown('<div class="section-header">Login</div>', unsafe_allow_html=True)
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            # In a real application, this would validate against a database
            # For now, we'll use a simple check
            if username and password:
                st.session_state.authenticated = True
                st.session_state.current_user = {
                    "id": "1",
                    "username": username,
                    "name": username.capitalize()
                }
                
                # Initialize services
                try:
                    st.session_state.ai_assistant = AIAssistant()
                    st.success("AI Assistant initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing AI Assistant: {e}")
                
                try:
                    # In a real application, we would use proper authentication
                    # For now, we'll use environment variables or placeholders
                    st.session_state.slack_service = "placeholder"  # SlackService()
                    st.success("Slack integration initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing Slack integration: {e}")
                
                try:
                    # In a real application, we would use proper authentication
                    # For now, we'll use environment variables or placeholders
                    st.session_state.asana_service = "placeholder"  # AsanaService()
                    st.success("Asana integration initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing Asana integration: {e}")
                
                st.rerun()
            else:
                st.error("Please enter both username and password")
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="section-header">Welcome to Personal Project Assistant</div>', unsafe_allow_html=True)
        st.markdown("""
        Your intelligent assistant for managing projects, meetings, and tasks.
        
        Features:
        - 📊 Project tracking and management
        - 🎤 Meeting recording and transcription
        - 💬 Slack conversation analysis
        - ✅ Task management with Asana
        - 🤖 AI-powered assistance
        
        Login to get started!
        """)
        st.markdown('</div>', unsafe_allow_html=True)

def sidebar():
    """Display the sidebar navigation."""
    st.sidebar.markdown('<div class="sidebar-header">Personal Project Assistant</div>', unsafe_allow_html=True)
    st.sidebar.markdown(f"Welcome, {st.session_state.current_user['name']}!")
    
    # Navigation
    page = st.sidebar.radio(
        "Navigation",
        ["Dashboard", "Projects", "Meetings", "Documents", "Slack", "Tasks", "AI Assistant"]
    )
    
    # Project selector (if not on Dashboard)
    if page != "Dashboard":
        st.sidebar.markdown("---")
        st.sidebar.markdown('<div class="sidebar-header">Select Project</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch projects from the database
        # For now, we'll use placeholder data
        projects = [
            {"id": "1", "name": "Project Alpha"},
            {"id": "2", "name": "Project Beta"},
            {"id": "3", "name": "Project Gamma"}
        ]
        
        project_names = [p["name"] for p in projects]
        selected_project = st.sidebar.selectbox("Project", project_names)
        
        # Update current project in session state
        for project in projects:
            if project["name"] == selected_project:
                st.session_state.current_project = project
    
    # Logout button
    st.sidebar.markdown("---")
    if st.sidebar.button("Logout"):
        st.session_state.authenticated = False
        st.session_state.current_user = None
        st.session_state.ai_assistant = None
        st.session_state.slack_service = None
        st.session_state.asana_service = None
        st.session_state.current_project = None
        st.rerun()
    
    return page

def dashboard_page():
    """Display the dashboard page."""
    st.markdown('<div class="main-header">Dashboard</div>', unsafe_allow_html=True)
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Active Projects", value="3")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Recent Meetings", value="5")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col3:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Open Tasks", value="12")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col4:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Documents", value="24")
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Recent activity
    st.markdown('<div class="section-header">Recent Activity</div>', unsafe_allow_html=True)
    
    # In a real application, we would fetch recent activity from the database
    # For now, we'll use placeholder data
    activities = [
        {"timestamp": "2025-03-17 15:30", "type": "Meeting", "description": "Team Standup", "project": "Project Alpha"},
        {"timestamp": "2025-03-17 14:15", "type": "Task", "description": "Update documentation", "project": "Project Beta"},
        {"timestamp": "2025-03-17 11:45", "type": "Slack", "description": "Discussion about API design", "project": "Project Alpha"},
        {"timestamp": "2025-03-17 10:30", "type": "Document", "description": "Requirements specification uploaded", "project": "Project Gamma"},
        {"timestamp": "2025-03-16 16:20", "type": "Meeting", "description": "Client presentation", "project": "Project Beta"}
    ]
    
    activity_df = pd.DataFrame(activities)
    st.dataframe(activity_df, use_container_width=True)
    
    # Project status
    st.markdown('<div class="section-header">Project Status</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-header">Task Completion</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch task data from the database
        # For now, we'll use placeholder data
        task_data = {
            "Project Alpha": {"completed": 8, "total": 15},
            "Project Beta": {"completed": 12, "total": 20},
            "Project Gamma": {"completed": 5, "total": 10}
        }
        
        for project, data in task_data.items():
            completion_rate = data["completed"] / data["total"]
            st.write(f"{project}: {data['completed']}/{data['total']} tasks completed")
            st.progress(completion_rate)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-header">Upcoming Deadlines</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch deadline data from the database
        # For now, we'll use placeholder data
        deadlines = [
            {"project": "Project Alpha", "task": "Finalize design", "deadline": "2025-03-20"},
            {"project": "Project Beta", "task": "Client presentation", "deadline": "2025-03-22"},
            {"project": "Project Gamma", "task": "Code review", "deadline": "2025-03-25"}
        ]
        
        for deadline in deadlines:
            st.write(f"**{deadline['project']}**: {deadline['task']} (Due: {deadline['deadline']})")
        
        st.markdown('</div>', unsafe_allow_html=True)

def projects_page():
    """Display the projects page."""
    st.markdown('<div class="main-header">Projects</div>', unsafe_allow_html=True)
    
    # Project management
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Project list
        st.markdown('<div class="section-header">Project List</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch projects from the database
        # For now, we'll use placeholder data
        projects = [
            {"id": "1", "name": "Project Alpha", "description": "Main product development", "status": "Active", "start_date": "2025-01-15", "end_date": "2025-06-30"},
            {"id": "2", "name": "Project Beta", "description": "Client website redesign", "status": "Active", "start_date": "2025-02-10", "end_date": "2025-04-15"},
            {"id": "3", "name": "Project Gamma", "description": "Internal tools development", "status": "Active", "start_date": "2025-03-01", "end_date": "2025-05-20"}
        ]
        
        project_df = pd.DataFrame(projects)
        st.dataframe(project_df, use_container_width=True)
    
    with col2:
        # Create new project
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-header">Create New Project</div>', unsafe_allow_html=True)
        
        project_name = st.text_input("Project Name")
        project_description = st.text_area("Description")
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Start Date")
        with col2:
            end_date = st.date_input("End Date")
        
        if st.button("Create Project"):
            if project_name and project_description:
                # In a real application, we would save to the database
                st.success(f"Project '{project_name}' created successfully!")
                # Clear form
                project_name = ""
                project_description = ""
            else:
                st.error("Please enter project name and description")
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Project details (if a project is selected)
    if st.session_state.current_project:
        st.markdown('<div class="section-header">Project Details</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="highlight">Currently viewing: {st.session_state.current_project["name"]}</div>', unsafe_allow_html=True)
        
        tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Team", "Timeline", "Resources"])
        
        with tab1:
            st.markdown("### Project Overview")
            st.write("Project description and key information would be displayed here.")
            
            # Project metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric(label="Tasks Completed", value="8/15")
            with col2:
                st.metric(label="Days Remaining", value="45")
            with col3:
                st.metric(label="Team Members", value="6")
        
        with tab2:
            st.markdown("### Team Members")
            
            # In a real application, we would fetch team members from the database
            # For now, we'll use placeholder data
            team_members = [
                {"name": "John Doe", "role": "Project Manager", "email": "john@example.com"},
                {"name": "Jane Smith", "role": "Developer", "email": "jane@example.com"},
                {"name": "Bob Johnson", "role": "Designer", "email": "bob@example.com"},
                {"name": "Alice Brown", "role": "Developer", "email": "alice@example.com"},
                {"name": "Charlie Davis", "role": "QA Engineer", "email": "charlie@example.com"},
                {"name": "Eva Wilson", "role": "Business Analyst", "email": "eva@example.com"}
            ]
            
            team_df = pd.DataFrame(team_members)
            st.dataframe(team_df, use_container_width=True)
        
        with tab3:
            st.markdown("### Project Timeline")
            st.write("Project timeline and milestones would be displayed here.")
            
            # In a real application, we would fetch milestones from the database
            # For now, we'll use placeholder data
            milestones = [
                {"name": "Project Kickoff", "date": "2025-01-15", "status": "Completed"},
                {"name": "Requirements Gathering", "date": "2025-02-01", "status": "Completed"},
                {"name": "Design Phase", "date": "2025-02-15", "status": "In Progress"},
                {"name": "Development Sprint 1", "date": "2025-03-01", "status": "In Progress"},
                {"name": "Development Sprint 2", "date": "2025-04-01", "status": "Not Started"},
                {"name": "Testing", "date": "2025-05-01", "status": "Not Started"},
                {"name": "Deployment", "date": "2025-06-15", "status": "Not Started"}
            ]
            
            milestone_df = pd.DataFrame(milestones)
            st.dataframe(milestone_df, use_container_width=True)
        
        with tab4:
            st.markdown("### Project Resources")
            st.write("Project resources and documents would be displayed here.")
            
            # In a real application, we would fetch resources from the database
 <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>