"""
Memory management system for the Personal Project Assistant.
This module implements GraphRAG (Graph Retrieval Augmented Generation) and structured retrieval.
"""

import os
from typing import List, Dict, Any, Optional, Union, Tuple
import numpy as np
from datetime import datetime
import json
import networkx as nx

# Import vector database
from .vector_db import VectorDatabase

class MemoryManager:
    """
    Memory management system that combines vector search with graph-based retrieval.
    Implements working memory, short-term memory, and long-term memory concepts.
    """
    
    def __init__(self, vector_db: Optional[VectorDatabase] = None):
        """
        Initialize the memory manager.
        
        Args:
            vector_db: Vector database instance (creates new one if not provided)
        """
        self.vector_db = vector_db or VectorDatabase()
        self.knowledge_graph = nx.DiGraph()
        
        # Memory types
        self.working_memory = []  # Current context (cleared frequently)
        self.short_term_memory = []  # Recent interactions (cleared periodically)
        self.long_term_memory = {}  # Persistent knowledge (never cleared)
    
    def add_to_working_memory(self, item: Dict[str, Any]):
        """
        Add an item to working memory.
        
        Args:
            item: Memory item to add
        """
        # Add timestamp
        item['timestamp'] = datetime.now().isoformat()
        
        # Add to working memory (limit size to 10 items)
        self.working_memory.append(item)
        if len(self.working_memory) > 10:
            self.working_memory.pop(0)
    
    def add_to_short_term_memory(self, item: Dict[str, Any]):
        """
        Add an item to short-term memory.
        
        Args:
            item: Memory item to add
        """
        # Add timestamp
        item['timestamp'] = datetime.now().isoformat()
        
        # Add to short-term memory (limit size to 100 items)
        self.short_term_memory.append(item)
        if len(self.short_term_memory) > 100:
            self.short_term_memory.pop(0)
    
    def add_to_long_term_memory(self, key: str, item: Dict[str, Any]):
        """
        Add an item to long-term memory.
        
        Args:
            key: Unique identifier for the item
            item: Memory item to add
        """
        # Add timestamp
        item['timestamp'] = datetime.now().isoformat()
        
        # Add to long-term memory
        self.long_term_memory[key] = item
    
    def clear_working_memory(self):
        """Clear working memory."""
        self.working_memory = []
    
    def clear_short_term_memory(self):
        """Clear short-term memory."""
        self.short_term_memory = []
    
    def add_entity_to_graph(self, 
                           entity_id: str, 
                           entity_type: str, 
                           properties: Dict[str, Any]):
        """
        Add an entity to the knowledge graph.
        
        Args:
            entity_id: Unique identifier for the entity
            entity_type: Type of entity (project, meeting, document, etc.)
            properties: Entity properties
        """
        # Add node to graph
        self.knowledge_graph.add_node(
            entity_id,
            entity_type=entity_type,
            properties=properties
        )
    
    def add_relation_to_graph(self, 
                             source_id: str, 
                             target_id: str, 
                             relation_type: str, 
                             properties: Optional[Dict[str, Any]] = None):
        """
        Add a relation between entities in the knowledge graph.
        
        Args:
            source_id: Source entity ID
            target_id: Target entity ID
            relation_type: Type of relation
            properties: Optional relation properties
        """
        # Add edge to graph
        self.knowledge_graph.add_edge(
            source_id,
            target_id,
            relation_type=relation_type,
            properties=properties or {}
        )
    
    def get_related_entities(self, 
                            entity_id: str, 
                            relation_type: Optional[str] = None, 
                            max_depth: int = 1) -> List[Dict[str, Any]]:
        """
        Get entities related to a given entity in the knowledge graph.
        
        Args:
            entity_id: Entity ID to start from
            relation_type: Optional filter for relation type
            max_depth: Maximum traversal depth
            
        Returns:
            List of related entities with their properties
        """
        related_entities = []
        
        # BFS traversal
        visited = set([entity_id])
        queue = [(entity_id, 0)]  # (node, depth)
        
        while queue:
            node, depth = queue.pop(0)
            
            if depth > max_depth:
                continue
            
            # Get neighbors
            for neighbor in self.knowledge_graph.neighbors(node):
                if neighbor in visited:
                    continue
                
                # Check relation type if specified
                edge_data = self.knowledge_graph.get_edge_data(node, neighbor)
                if relation_type and edge_data['relation_type'] != relation_type:
                    continue
                
                # Add to results
                node_data = self.knowledge_graph.nodes[neighbor]
                related_entities.append({
                    'id': neighbor,
                    'entity_type': node_data['entity_type'],
                    'properties': node_data['properties'],
                    'relation': {
                        'type': edge_data['relation_type'],
                        'properties': edge_data['properties']
                    }
                })
                
                # Add to queue for further traversal
                visited.add(neighbor)
                queue.append((neighbor, depth + 1))
        
        return related_entities
    
    def retrieve_context(self, 
                        query_embedding: List[float], 
                        project_id: Optional[str] = None, 
                        entity_type: Optional[str] = None, 
                        max_results: int = 5) -> Dict[str, List[Dict[str, Any]]]:
        """
        Retrieve context for a query using GraphRAG approach.
        Combines vector search with graph traversal for comprehensive retrieval.
        
        Args:
            query_embedding: Vector embedding of the query
            project_id: Optional project ID to filter results
            entity_type: Optional entity type to filter results
            max_results: Maximum number of results per category
            
        Returns:
            Dictionary of retrieved context by category
        """
        context = {
            'documents': [],
            'transcripts': [],
            'messages': [],
            'related_entities': []
        }
        
        # Create filter dict if project_id is provided
        filter_dict = {}
        if project_id:
            filter_dict['project_id'] = project_id
        
        # Search documents
        document_results = self.vector_db.search_documents(
            query_embedding=query_embedding,
            top_k=max_results,
            filter_dict=filter_dict
        )
        context['documents'] = document_results
        
        # Search transcripts
        transcript_results = self.vector_db.search_transcripts(
            query_embedding=query_embedding,
            top_k=max_results,
            filter_dict=filter_dict
        )
        context['transcripts'] = transcript_results
        
        # Search messages
        message_results = self.vector_db.search_messages(
            query_embedding=query_embedding,
            top_k=max_results,
            filter_dict=filter_dict
        )
        context['messages'] = message_results
        
        # Get related entities from knowledge graph
        if document_results:
            # Use the top document result as a starting point
            top_doc_id = document_results[0]['id']
            related_entities = self.get_related_entities(
                entity_id=top_doc_id,
                max_depth=2
            )
            context['related_entities'] = related_entities[:max_results]
        
        return context
    
    def save_graph(self, filepath: str):
        """
        Save the knowledge graph to a file.
        
        Args:
            filepath: Path to save the graph
        """
        # Convert graph to dictionary
        graph_data = nx.node_link_data(self.knowledge_graph)
        
        # Save to file
        with open(filepath, 'w') as f:
            json.dump(graph_data, f)
    
    def load_graph(self, filepath: str):
        """
        Load the knowledge graph from a file.
        
        Args:
            filepath: Path to load the graph from
        """
        # Load from file
        with open(filepath, 'r') as f:
            graph_data = json.load(f)
        
        # Convert dictionary to graph
        self.knowledge_graph = nx.node_link_graph(graph_data)
    
    def close(self):
        """Close connections and clean up resources."""
        if self.vector_db:
            self.vector_db.close()
