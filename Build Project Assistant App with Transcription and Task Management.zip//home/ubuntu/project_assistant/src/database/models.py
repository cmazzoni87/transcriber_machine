"""
SQL Database models for the Personal Project Assistant application.
These models define the structure of the PostgreSQL database.
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import datetime

Base = declarative_base()

class User(Base):
    """User model for authentication and user management."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    projects = relationship("Project", back_populates="owner")
    documents = relationship("Document", back_populates="created_by_user")
    tasks = relationship("Task", back_populates="assigned_user")
    
    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}', email='{self.email}')>"


class Project(Base):
    """Project model for organizing meetings, documents, and tasks."""
    __tablename__ = 'projects'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    status = Column(String(50), default='active')
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    owner = relationship("User", back_populates="projects")
    meetings = relationship("Meeting", back_populates="project")
    documents = relationship("Document", back_populates="project")
    slack_messages = relationship("SlackMessage", back_populates="project")
    tasks = relationship("Task", back_populates="project")
    
    def __repr__(self):
        return f"<Project(id={self.id}, name='{self.name}', status='{self.status}')>"


class Meeting(Base):
    """Meeting model for storing call/meeting information and recordings."""
    __tablename__ = 'meetings'
    
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'))
    title = Column(String(255))
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime)
    recording_path = Column(String(255))
    transcript_path = Column(String(255))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="meetings")
    participants = relationship("MeetingParticipant", back_populates="meeting")
    
    def __repr__(self):
        return f"<Meeting(id={self.id}, title='{self.title}', start_time='{self.start_time}')>"


class MeetingParticipant(Base):
    """Junction table for meeting participants."""
    __tablename__ = 'meeting_participants'
    
    id = Column(Integer, primary_key=True)
    meeting_id = Column(Integer, ForeignKey('meetings.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    role = Column(String(50), default='participant')
    
    # Relationships
    meeting = relationship("Meeting", back_populates="participants")
    user = relationship("User")
    
    def __repr__(self):
        return f"<MeetingParticipant(meeting_id={self.meeting_id}, user_id={self.user_id}, role='{self.role}')>"


class Document(Base):
    """Document model for storing files and their metadata."""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'))
    title = Column(String(255), nullable=False)
    file_path = Column(String(255), nullable=False)
    file_type = Column(String(50))
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="documents")
    created_by_user = relationship("User", back_populates="documents")
    
    def __repr__(self):
        return f"<Document(id={self.id}, title='{self.title}', file_type='{self.file_type}')>"


class SlackWorkspace(Base):
    """Slack workspace model for storing workspace information."""
    __tablename__ = 'slack_workspaces'
    
    id = Column(Integer, primary_key=True)
    workspace_id = Column(String(255), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    access_token = Column(String(255))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    channels = relationship("SlackChannel", back_populates="workspace")
    
    def __repr__(self):
        return f"<SlackWorkspace(id={self.id}, name='{self.name}')>"


class SlackChannel(Base):
    """Slack channel model for storing channel information."""
    __tablename__ = 'slack_channels'
    
    id = Column(Integer, primary_key=True)
    workspace_id = Column(Integer, ForeignKey('slack_workspaces.id'))
    channel_id = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)
    is_private = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    workspace = relationship("SlackWorkspace", back_populates="channels")
    messages = relationship("SlackMessage", back_populates="channel")
    
    def __repr__(self):
        return f"<SlackChannel(id={self.id}, name='{self.name}', is_private={self.is_private})>"


class SlackMessage(Base):
    """Slack message model for storing message content and metadata."""
    __tablename__ = 'slack_messages'
    
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=True)
    channel_id = Column(Integer, ForeignKey('slack_channels.id'))
    message_id = Column(String(255), nullable=False)
    sender = Column(String(255))
    message = Column(Text)
    timestamp = Column(DateTime)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="slack_messages")
    channel = relationship("SlackChannel", back_populates="messages")
    
    def __repr__(self):
        return f"<SlackMessage(id={self.id}, sender='{self.sender}', timestamp='{self.timestamp}')>"


class Task(Base):
    """Task model for storing task information and Asana integration."""
    __tablename__ = 'tasks'
    
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey('projects.id'))
    asana_id = Column(String(255))
    title = Column(String(255), nullable=False)
    description = Column(Text)
    status = Column(String(50))
    due_date = Column(DateTime)
    assigned_to = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="tasks")
    assigned_user = relationship("User", back_populates="tasks")
    
    def __repr__(self):
        return f"<Task(id={self.id}, title='{self.title}', status='{self.status}')>"


class AsanaWorkspace(Base):
    """Asana workspace model for storing workspace information."""
    __tablename__ = 'asana_workspaces'
    
    id = Column(Integer, primary_key=True)
    workspace_id = Column(String(255), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    access_token = Column(String(255))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    projects = relationship("AsanaProject", back_populates="workspace")
    
    def __repr__(self):
        return f"<AsanaWorkspace(id={self.id}, name='{self.name}')>"


class AsanaProject(Base):
    """Asana project model for storing project information."""
    __tablename__ = 'asana_projects'
    
    id = Column(Integer, primary_key=True)
    workspace_id = Column(Integer, ForeignKey('asana_workspaces.id'))
    project_id = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    workspace = relationship("AsanaWorkspace", back_populates="projects")
    
    def __repr__(self):
        return f"<AsanaProject(id={self.id}, name='{self.name}')>"


def init_db(db_url):
    """Initialize the database with all tables."""
    engine = create_engine(db_url)
    Base.metadata.create_all(engine)
    return engine
