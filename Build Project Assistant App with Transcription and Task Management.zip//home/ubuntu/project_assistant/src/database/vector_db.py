"""
Vector database implementation for the Personal Project Assistant application.
This module handles the creation and management of vector embeddings for semantic search.
"""

import os
import pinecone
from typing import List, Dict, Any, Optional, Union
import numpy as np
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class VectorDatabase:
    """
    Vector database manager for storing and retrieving embeddings.
    Uses Pinecone as the vector database service.
    """
    
    def __init__(self, api_key: Optional[str] = None, environment: Optional[str] = None):
        """
        Initialize the vector database connection.
        
        Args:
            api_key: Pinecone API key (defaults to environment variable)
            environment: Pinecone environment (defaults to environment variable)
        """
        self.api_key = api_key or os.getenv("PINECONE_API_KEY")
        self.environment = environment or os.getenv("PINECONE_ENVIRONMENT")
        
        if not self.api_key or not self.environment:
            raise ValueError("Pinecone API key and environment must be provided")
        
        # Initialize Pinecone
        pinecone.init(api_key=self.api_key, environment=self.environment)
        
        # Collection names
        self.DOCUMENT_COLLECTION = "document_embeddings"
        self.TRANSCRIPT_COLLECTION = "transcript_embeddings"
        self.MESSAGE_COLLECTION = "message_embeddings"
        
        # Ensure collections exist
        self._ensure_collections_exist()
    
    def _ensure_collections_exist(self):
        """Ensure that all required collections exist in Pinecone."""
        existing_indexes = pinecone.list_indexes()
        
        for collection_name in [self.DOCUMENT_COLLECTION, self.TRANSCRIPT_COLLECTION, self.MESSAGE_COLLECTION]:
            if collection_name not in existing_indexes:
                # Create the index with appropriate dimensions for the embedding model
                # Using 1536 dimensions for OpenAI embeddings or 768 for smaller models
                pinecone.create_index(
                    name=collection_name,
                    dimension=1536,  # Adjust based on embedding model
                    metric="cosine"
                )
    
    def get_collection(self, collection_name: str):
        """
        Get a Pinecone index by name.
        
        Args:
            collection_name: Name of the collection/index
            
        Returns:
            Pinecone index object
        """
        return pinecone.Index(collection_name)
    
    def store_document_embedding(self, 
                                document_id: str, 
                                embedding: List[float], 
                                metadata: Dict[str, Any]):
        """
        Store a document embedding in the vector database.
        
        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding of the document
            metadata: Additional metadata about the document
        """
        index = self.get_collection(self.DOCUMENT_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Upsert the embedding
        index.upsert(
            vectors=[
                {
                    "id": document_id,
                    "values": embedding,
                    "metadata": metadata
                }
            ]
        )
    
    def store_transcript_embedding(self, 
                                  transcript_id: str, 
                                  embedding: List[float], 
                                  metadata: Dict[str, Any]):
        """
        Store a transcript embedding in the vector database.
        
        Args:
            transcript_id: Unique identifier for the transcript
            embedding: Vector embedding of the transcript
            metadata: Additional metadata about the transcript
        """
        index = self.get_collection(self.TRANSCRIPT_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Upsert the embedding
        index.upsert(
            vectors=[
                {
                    "id": transcript_id,
                    "values": embedding,
                    "metadata": metadata
                }
            ]
        )
    
    def store_message_embedding(self, 
                               message_id: str, 
                               embedding: List[float], 
                               metadata: Dict[str, Any]):
        """
        Store a message embedding in the vector database.
        
        Args:
            message_id: Unique identifier for the message
            embedding: Vector embedding of the message
            metadata: Additional metadata about the message
        """
        index = self.get_collection(self.MESSAGE_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Upsert the embedding
        index.upsert(
            vectors=[
                {
                    "id": message_id,
                    "values": embedding,
                    "metadata": metadata
                }
            ]
        )
    
    def search_documents(self, 
                        query_embedding: List[float], 
                        top_k: int = 5, 
                        filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar documents using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching documents with scores and metadata
        """
        index = self.get_collection(self.DOCUMENT_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Perform the query
        results = index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True,
            filter=filter_dict
        )
        
        return results.matches
    
    def search_transcripts(self, 
                          query_embedding: List[float], 
                          top_k: int = 5, 
                          filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar transcripts using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching transcripts with scores and metadata
        """
        index = self.get_collection(self.TRANSCRIPT_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Perform the query
        results = index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True,
            filter=filter_dict
        )
        
        return results.matches
    
    def search_messages(self, 
                       query_embedding: List[float], 
                       top_k: int = 5, 
                       filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar messages using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching messages with scores and metadata
        """
        index = self.get_collection(self.MESSAGE_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Perform the query
        results = index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True,
            filter=filter_dict
        )
        
        return results.matches
    
    def delete_document(self, document_id: str):
        """
        Delete a document embedding from the vector database.
        
        Args:
            document_id: Unique identifier for the document
        """
        index = self.get_collection(self.DOCUMENT_COLLECTION)
        index.delete(ids=[document_id])
    
    def delete_transcript(self, transcript_id: str):
        """
        Delete a transcript embedding from the vector database.
        
        Args:
            transcript_id: Unique identifier for the transcript
        """
        index = self.get_collection(self.TRANSCRIPT_COLLECTION)
        index.delete(ids=[transcript_id])
    
    def delete_message(self, message_id: str):
        """
        Delete a message embedding from the vector database.
        
        Args:
            message_id: Unique identifier for the message
        """
        index = self.get_collection(self.MESSAGE_COLLECTION)
        index.delete(ids=[message_id])
    
    def close(self):
        """Close the connection to the vector database."""
        # Pinecone doesn't require explicit connection closing
        pass
