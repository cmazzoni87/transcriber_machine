"""
Main application script for the Personal Project Assistant.
This script serves as the entry point for the application.
"""

import os
import sys
from pathlib import Path

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent))

# Import components
from src.frontend.app import main as run_frontend
from src.database.init_db import initialize_database
from src.recorder.enhanced_recorder import main as run_recorder

def setup_environment():
    """Set up environment variables and configuration."""
    # Set environment variables for AWS services
    os.environ.setdefault("AWS_REGION", "us-east-1")
    
    # Set environment variables for database
    os.environ.setdefault("DATABASE_URL", "sqlite:///project_assistant.db")
    
    # Set environment variables for vector database
    os.environ.setdefault("VECTOR_DB_TYPE", "pinecone")
    
    # Set environment variables for Bedrock AI
    os.environ.setdefault("BEDROCK_MODEL", "anthropic.claude-v2")
    
    # Create necessary directories
    os.makedirs("data", exist_ok=True)
    os.makedirs("logs", exist_ok=True)

def main():
    """Main function to run the application."""
    # Set up environment
    setup_environment()
    
    # Initialize database
    initialize_database()
    
    # Parse command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == "recorder":
            # Run recorder in background
            print("Starting recorder...")
            run_recorder()
        elif command == "frontend":
            # Run frontend
            print("Starting frontend...")
            run_frontend()
        else:
            print(f"Unknown command: {command}")
            print("Available commands: recorder, frontend")
    else:
        # Default: run frontend
        print("Starting frontend...")
        run_frontend()

if __name__ == "__main__":
    main()
