# Personal Project Assistant

A comprehensive personal assistant application that tracks projects, stores calls, documents, and chats, and uses AI to improve efficiency.

## Features

- **Project Tracking**: Manage projects, team members, timelines, and resources
- **Meeting Recording & Transcription**: Automatically detect and record video calls, transcribe audio, and extract action items
- **Document Management**: Store, search, and analyze documents with AI assistance
- **Slack Integration**: Monitor Slack conversations and match them to projects
- **Task Management**: Create and update tasks in Asana with AI assistance
- **AI Assistant**: Get intelligent assistance using Amazon Bedrock AI models
- **Memory Management**: Store and retrieve information using vector database and GraphRAG

## Architecture

The application is built with a modular architecture:

- **Frontend Layer**: Streamlit interface for user interaction
- **Backend Layer**: Core application logic and AI processing
- **Integration Layer**: Connections to external services (Slack, Asana)
- **Data Layer**: SQL database and vector database for storage

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Set up environment variables:
   ```
   AWS_REGION=us-east-1
   DATABASE_URL=sqlite:///project_assistant.db
   SLACK_API_TOKEN=your_slack_token
   ASANA_ACCESS_TOKEN=your_asana_token
   ```

## Usage

Run the frontend:
```
python main.py frontend
```

Run the meeting recorder:
```
python main.py recorder
```

## Components

- **Database**: SQLAlchemy models for users, projects, meetings, documents, Slack messages, and tasks
- **Vector Database**: Pinecone for storing embeddings of documents, transcripts, and messages
- **AI**: Amazon Bedrock integration with Claude, Titan, and other models
- **Slack**: Integration with Slack API for monitoring conversations
- **Asana**: Integration with Asana API for task management
- **Recorder**: Enhanced recording and transcription of video calls

## Testing

Run the tests:
```
python tests.py
```

## License

MIT
