"""
Tests for the manual ingestion service and action item manager.
"""

import os
import sys
import json
import pytest
from pathlib import Path
from datetime import datetime

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent))

# Import components to test
from src.integrations.manual_ingestion.manual_ingestion_service import ManualIngestionService
from src.integrations.manual_ingestion.action_item_manager import ActionItemManager

class TestManualIngestion:
    """Test cases for the manual ingestion service."""
    
    def test_action_item_manager_initialization(self):
        """Test that the action item manager initializes correctly."""
        manager = ActionItemManager()
        assert manager is not None
        assert os.path.exists(manager.action_items_file)
    
    def test_create_action_item(self):
        """Test creating an action item."""
        manager = ActionItemManager()
        
        # Create a test action item
        action_item = manager.create_action_item(
            task="Test task",
            project_id="test_project",
            assignee="Test User",
            due_date="2025-04-01",
            priority="high",
            notes="Test notes"
        )
        
        # Verify the action item was created correctly
        assert action_item is not None
        assert action_item["task"] == "Test task"
        assert action_item["project_id"] == "test_project"
        assert action_item["assignee"] == "Test User"
        assert action_item["due_date"] == "2025-04-01"
        assert action_item["priority"] == "high"
        assert action_item["notes"] == "Test notes"
        assert action_item["completed"] is False
        
        # Verify the action item was saved to the file
        action_items = manager._load_action_items()
        found = False
        for item in action_items:
            if item["id"] == action_item["id"]:
                found = True
                break
        
        assert found, "Action item was not saved to the file"
        
        # Clean up - delete the test action item
        manager.delete_action_item(action_item["id"])
    
    def test_get_action_items(self):
        """Test retrieving action items."""
        manager = ActionItemManager()
        
        # Create test action items
        item1 = manager.create_action_item(
            task="Test task 1",
            project_id="test_project",
            priority="high"
        )
        
        item2 = manager.create_action_item(
            task="Test task 2",
            project_id="test_project",
            priority="medium"
        )
        
        # Get all action items
        all_items = manager.get_action_items()
        assert len(all_items) >= 2
        
        # Get action items for a specific project
        project_items = manager.get_action_items(project_id="test_project")
        assert len(project_items) >= 2
        
        # Clean up - delete the test action items
        manager.delete_action_item(item1["id"])
        manager.delete_action_item(item2["id"])
    
    def test_update_action_item(self):
        """Test updating an action item."""
        manager = ActionItemManager()
        
        # Create a test action item
        action_item = manager.create_action_item(
            task="Original task",
            priority="medium"
        )
        
        # Update the action item
        updated_item = manager.update_action_item(
            item_id=action_item["id"],
            task="Updated task",
            priority="high",
            completed=True
        )
        
        # Verify the action item was updated correctly
        assert updated_item is not None
        assert updated_item["task"] == "Updated task"
        assert updated_item["priority"] == "high"
        assert updated_item["completed"] is True
        
        # Clean up - delete the test action item
        manager.delete_action_item(action_item["id"])
    
    def test_delete_action_item(self):
        """Test deleting an action item."""
        manager = ActionItemManager()
        
        # Create a test action item
        action_item = manager.create_action_item(
            task="Task to delete"
        )
        
        # Get the ID
        item_id = action_item["id"]
        
        # Delete the action item
        result = manager.delete_action_item(item_id)
        assert result is True
        
        # Verify the action item was deleted
        all_items = manager.get_action_items()
        for item in all_items:
            assert item["id"] != item_id
    
    def test_complete_action_item(self):
        """Test marking an action item as complete."""
        manager = ActionItemManager()
        
        # Create a test action item
        action_item = manager.create_action_item(
            task="Task to complete"
        )
        
        # Complete the action item
        completed_item = manager.complete_action_item(action_item["id"])
        
        # Verify the action item was marked as complete
        assert completed_item is not None
        assert completed_item["completed"] is True
        
        # Clean up - delete the test action item
        manager.delete_action_item(action_item["id"])
    
    def test_create_action_items_from_list(self):
        """Test creating multiple action items from a list."""
        manager = ActionItemManager()
        
        # Create a list of action items
        action_items_data = [
            {
                "task": "Task 1",
                "assignee": "User 1",
                "priority": "high"
            },
            {
                "task": "Task 2",
                "assignee": "User 2",
                "priority": "medium"
            }
        ]
        
        # Create action items from the list
        created_items = manager.create_action_items_from_list(
            action_items=action_items_data,
            project_id="test_project"
        )
        
        # Verify the action items were created correctly
        assert len(created_items) == 2
        assert created_items[0]["task"] == "Task 1"
        assert created_items[0]["project_id"] == "test_project"
        assert created_items[1]["task"] == "Task 2"
        assert created_items[1]["project_id"] == "test_project"
        
        # Clean up - delete the test action items
        for item in created_items:
            manager.delete_action_item(item["id"])
