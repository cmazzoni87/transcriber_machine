# Personal Project Assistant

A comprehensive personal assistant application for senior solution architects to manage projects, record and transcribe calls, capture screenshots, and manage action items.

## Overview

This application helps solution architects track projects and store various types of content including:
- Call recordings and transcriptions
- Screenshots and images
- Text data from various sources
- Action items extracted from content

The application uses Amazon Bedrock with Claude models for AI capabilities and LanceDB with S3 storage for vector database functionality.

## Features

- **Project Management**: Track and organize projects
- **Call Recording & Transcription**: Record and transcribe calls for later reference
- **Manual Text Ingestion**: Import text data from various sources
- **Action Item Management**: Create, track, and manage action items
- **AI-Powered Analysis**: Extract insights, summaries, and action items from content
- **Vector Search**: Find relevant content across projects using semantic search

## Architecture

The application is built with the following components:

- **Frontend**: Streamlit-based UI for user interaction
- **Database**: 
  - SQL database for structured data
  - LanceDB with S3 storage for vector embeddings
- **AI Integration**: Amazon Bedrock with Claude models for:
  - Text generation
  - Summarization
  - Action item extraction
  - Entity recognition
  - Sentiment analysis
- **Manual Ingestion**: Components for importing text and images

## Technology Stack

- **Python**: Core application logic
- **Streamlit**: Web interface
- **SQLAlchemy**: Database ORM
- **LanceDB**: Vector database for embeddings
- **Amazon Bedrock**: AI capabilities with Claude models
- **AWS S3**: Storage for vector database
- **NetworkX**: Graph-based retrieval

## Installation

1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Set up environment variables in a `.env` file:
```
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
BEDROCK_DEFAULT_MODEL=anthropic.claude-3-sonnet-20240229-v1:0
S3_BUCKET_NAME=your_s3_bucket_name
```

## Usage

1. Start the application:
```bash
cd project_assistant
streamlit run src/frontend/app.py
```

2. Log in to the application
3. Navigate through the sidebar to access different features:
   - Dashboard: Overview of projects and recent activity
   - Projects: Manage and view project details
   - Meetings: Record meetings and view transcripts
   - Documents: Upload and manage documents
   - Action Items: Manage tasks and action items
   - Text Ingestion: Manually import text from various sources
   - AI Assistant: Ask questions about your projects and content

## Manual Text Ingestion

The application provides several ways to manually ingest content:

1. **Chat Text**: Paste text from chat conversations
2. **Notes**: Import notes from meetings or other sources
3. **Images**: Upload images of whiteboards, notes, or documents

After ingestion, the AI will automatically:
- Extract action items
- Identify key entities
- Generate a summary
- Analyze sentiment
- Store the content for later retrieval

## Action Item Management

The Action Items page allows you to:
- View all action items across projects
- Filter by project, completion status, and other criteria
- Add new action items manually
- Extract action items from text using AI
- Mark items as complete
- Edit or delete existing items

## Development

### Project Structure

```
project_assistant/
├── src/
│   ├── ai/
│   │   ├── ai_assistant.py
│   │   └── bedrock_ai.py
│   ├── database/
│   │   ├── db_manager.py
│   │   ├── memory_manager.py
│   │   ├── models.py
│   │   └── vector_db.py
│   ├── frontend/
│   │   ├── action_items_page.py
│   │   └── app.py
│   └── integrations/
│       └── manual_ingestion/
│           ├── action_item_manager.py
│           └── manual_ingestion_service.py
└── tests/
    └── test_manual_ingestion.py
```

### Running Tests

```bash
python -m pytest -xvs tests/
```

## Configuration

### Amazon Bedrock Models

The application is configured to use the following Claude models:
- `anthropic.claude-3-sonnet-20240229-v1:0` (default)
- `anthropic.claude-3-haiku-20240307-v1:0`
- `anthropic.claude-3-opus-20240229-v1:0`
- `anthropic.claude-instant-v1`

### LanceDB Configuration

LanceDB is configured to use S3 for storage with the following collections:
- `messages`: For chat messages
- `transcripts`: For meeting transcripts
- `documents`: For document content
- `images`: For image metadata

## Extending the Application

### Adding New Content Types

To add support for new content types:
1. Create a new method in `ManualIngestionService` for the content type
2. Update the frontend to include UI for the new content type
3. Add vector storage support in `VectorDB` if needed

### Customizing AI Capabilities

To modify or extend AI capabilities:
1. Update the `BedrockAI` class in `src/ai/bedrock_ai.py`
2. Add new methods for specific AI tasks
3. Update the frontend to expose the new capabilities

## Troubleshooting

### Common Issues

1. **AWS Credentials**: Ensure your AWS credentials are correctly set up with appropriate permissions for Bedrock and S3
2. **S3 Bucket**: Verify the S3 bucket exists and is accessible
3. **Dependencies**: Make sure all required packages are installed

### Logs

Application logs can be found in:
- Streamlit logs: Console output when running the application
- AWS CloudWatch: If configured for AWS services

## License

This project is licensed under the MIT License - see the LICENSE file for details.
