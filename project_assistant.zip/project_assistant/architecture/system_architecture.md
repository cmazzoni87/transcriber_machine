# System Architecture for Personal Project Assistant

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                        Frontend Layer                           │
│  ┌─────────────────┐              ┌───────────────────────┐    │
│  │   Web Interface │              │   Streamlit Dashboard │    │
│  │   (JavaScript)  │              │                       │    │
│  └─────────────────┘              └───────────────────────┘    │
│                                                                 │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                        Backend Layer                            │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────────┐  │
│  │ API Gateway │  │ Authentication│  │ Project Management    │  │
│  │             │  │ & Security    │  │ Service               │  │
│  └─────────────┘  └──────────────┘  └────────────────────────┘  │
│                                                                 │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────────┐  │
│  │ Recording   │  │ Transcription │  │ Memory Management     │  │
│  │ Service     │  │ Service       │  │ Service               │  │
│  └─────────────┘  └──────────────┘  └────────────────────────┘  │
│                                                                 │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                     Integration Layer                           │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────────┐  │
│  │ Amazon      │  │ Slack        │  │ Asana                  │  │
│  │ Bedrock     │  │ Integration  │  │ Integration            │  │
│  └─────────────┘  └──────────────┘  └────────────────────────┘  │
│                                                                 │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                       Data Layer                                │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────────┐  │
│  │ SQL Database│  │ Vector       │  │ File Storage           │  │
│  │ (PostgreSQL)│  │ Database     │  │ (S3)                   │  │
│  └─────────────┘  └──────────────┘  └────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Frontend Layer
- **Web Interface (JavaScript)**
  - React-based SPA for desktop/mobile access
  - Dashboard for project overview, tasks, and insights
  - Call/meeting management interface
  - Document viewer and search
  
- **Streamlit Dashboard (Alternative)**
  - Python-based dashboard for rapid development
  - Data visualization components
  - Project analytics and insights
  - Simplified interface for core functionality

### 2. Backend Layer
- **API Gateway**
  - RESTful API endpoints for frontend communication
  - Request routing and validation
  - Rate limiting and monitoring

- **Authentication & Security**
  - User authentication and session management
  - API key management for external services
  - Data encryption and secure storage

- **Project Management Service**
  - Project creation, tracking, and organization
  - Document and call association with projects
  - Project analytics and reporting

- **Recording Service** (Enhanced from existing code)
  - Cross-platform call detection (Windows, macOS, Linux)
  - Audio and screen recording
  - Meeting metadata collection
  - Support for additional applications

- **Transcription Service** (Enhanced from existing code)
  - Audio transcription with speaker identification
  - Transcript formatting and storage
  - Transcript search and retrieval
  - Support for multiple languages

- **Memory Management Service**
  - Vector embedding generation for semantic search
  - Context retrieval for AI assistance
  - Knowledge graph construction
  - Long-term and short-term memory management

### 3. Integration Layer
- **Amazon Bedrock Integration**
  - AI model selection and management
  - Prompt engineering and optimization
  - Response generation and processing
  - Fine-tuning capabilities

- **Slack Integration**
  - Authentication and workspace connection
  - Channel and direct message monitoring
  - Message extraction and processing
  - Project matching based on content
  - Notification system

- **Asana Integration**
  - Authentication and workspace connection
  - Task creation, reading, updating, and deletion
  - Project synchronization
  - Task prioritization and scheduling
  - Automated task updates based on project progress

### 4. Data Layer
- **SQL Database (PostgreSQL)**
  - User profiles and authentication
  - Project metadata and relationships
  - Task tracking and status
  - Configuration and settings
  - Structured data storage

- **Vector Database**
  - Document embeddings
  - Transcript embeddings
  - Chat message embeddings
  - Semantic search capabilities
  - Similarity matching

- **File Storage (S3)**
  - Audio recordings
  - Screenshots and screen recordings
  - Document attachments
  - Backup and archival

## Data Flow

1. **Call Recording & Transcription Flow**
   - Call detection → Audio/screen recording → S3 storage → Transcription → Formatting → Database storage
   - Transcript processing → Vector embedding → Vector database storage
   - Project matching → Project association

2. **Slack Integration Flow**
   - Message monitoring → Message extraction → Content analysis → Vector embedding → Vector database storage
   - Project matching → Project association
   - Task identification → Asana task creation/update

3. **Asana Integration Flow**
   - Task synchronization → Local database storage → Task updates
   - Project association → Task prioritization
   - AI-assisted task management → Task recommendations

4. **AI Assistant Flow**
   - User query → Context retrieval from vector database → Prompt construction
   - Amazon Bedrock API call → Response processing → User presentation
   - Memory update → Vector database update

## Database Schema

### SQL Database (PostgreSQL)

#### Users Table
```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Projects Table
```sql
CREATE TABLE projects (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'active',
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Meetings Table
```sql
CREATE TABLE meetings (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id),
    title VARCHAR(255),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    recording_path VARCHAR(255),
    transcript_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Documents Table
```sql
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id),
    title VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(50),
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Slack Messages Table
```sql
CREATE TABLE slack_messages (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id),
    channel VARCHAR(255),
    sender VARCHAR(255),
    message TEXT,
    timestamp TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Tasks Table
```sql
CREATE TABLE tasks (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id),
    asana_id VARCHAR(255),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50),
    due_date TIMESTAMP,
    assigned_to INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Vector Database

#### Document Embeddings Collection
- Document ID (reference to SQL database)
- Text chunks
- Vector embeddings
- Metadata (document type, project, creation date)

#### Transcript Embeddings Collection
- Transcript ID (reference to SQL database)
- Speaker segments
- Vector embeddings
- Metadata (meeting date, project, participants)

#### Message Embeddings Collection
- Message ID (reference to SQL database)
- Message content
- Vector embeddings
- Metadata (sender, channel, timestamp, project)

## Technology Stack

### Backend
- **Language**: Python 3.10+
- **Web Framework**: FastAPI
- **Database**: PostgreSQL
- **Vector Database**: Pinecone or Weaviate
- **Task Queue**: Celery with Redis
- **File Storage**: AWS S3

### Frontend
- **Option 1**: React.js with TypeScript
- **Option 2**: Streamlit

### AI and ML
- **Amazon Bedrock**: Claude, Titan, or other models
- **Embedding Models**: Amazon Titan Embeddings
- **NLP Processing**: spaCy, NLTK

### Integration
- **Slack API**: slack-sdk
- **Asana API**: asana-python
- **AWS SDK**: boto3

### Deployment
- **Containerization**: Docker
- **Orchestration**: Docker Compose (development) / Kubernetes (production)
- **CI/CD**: GitHub Actions

## Security Considerations

1. **Data Protection**
   - Encryption at rest for all databases
   - Encryption in transit for all API communications
   - Secure storage of API keys and credentials

2. **Authentication**
   - JWT-based authentication for API access
   - OAuth integration for Slack and Asana
   - Role-based access control

3. **Privacy**
   - Data retention policies
   - User consent for recording and processing
   - Compliance with relevant regulations (GDPR, CCPA)

## Scalability Considerations

1. **Horizontal Scaling**
   - Stateless API services for easy replication
   - Database read replicas for scaling read operations
   - Sharding strategy for vector database

2. **Performance Optimization**
   - Caching layer for frequent queries
   - Asynchronous processing for non-critical operations
   - Batch processing for large data operations

3. **Resource Management**
   - Efficient vector storage and retrieval
   - Optimized embedding generation
   - Tiered storage for historical data
