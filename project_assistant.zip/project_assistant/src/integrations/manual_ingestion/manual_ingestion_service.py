"""
Manual text ingestion service for the Personal Project Assistant.
This module provides functionality for manually ingesting text data from various sources.
"""

import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional, Union
import base64

# Import database components
from ...database.models import Project
from ...database.db_manager import get_db_session
from ...database.memory_manager import MemoryManager
from ...ai.bedrock_ai import BedrockAI

class ManualIngestionService:
    """
    Manual ingestion service for handling text data from various sources.
    Replaces the Slack and Asana integrations with a manual ingestion mechanism.
    """
    
    def __init__(self, 
                memory_manager: Optional[MemoryManager] = None,
                bedrock_ai: Optional[BedrockAI] = None):
        """
        Initialize the manual ingestion service.
        
        Args:
            memory_manager: Memory manager instance (creates new one if not provided)
            bedrock_ai: Bedrock AI instance (creates new one if not provided)
        """
        self.memory_manager = memory_manager or MemoryManager()
        self.bedrock_ai = bedrock_ai or BedrockAI()
    
    def ingest_text(self, 
                   text: str, 
                   source_type: str, 
                   project_id: Optional[str] = None, 
                   metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Ingest text data and process it for storage and analysis.
        
        Args:
            text: Text content to ingest
            source_type: Type of source (chat, meeting, document, etc.)
            project_id: Optional project ID to associate with the text
            metadata: Optional additional metadata
            
        Returns:
            Processing results including extracted information and action items
        """
        # Generate a unique ID for the ingested text
        text_id = str(uuid.uuid4())
        
        # Create metadata if not provided
        if metadata is None:
            metadata = {}
        
        # Add basic metadata
        metadata.update({
            "id": text_id,
            "source_type": source_type,
            "timestamp": datetime.now().isoformat(),
            "project_id": project_id
        })
        
        # Generate embedding for the text
        embedding = self.bedrock_ai.generate_embeddings(text)
        
        # Store in appropriate vector collection based on source type
        if source_type == "chat":
            self.memory_manager.vector_db.store_message_embedding(
                message_id=text_id,
                embedding=embedding,
                metadata={
                    **metadata,
                    "content": text[:1000]  # Store preview of content
                }
            )
        elif source_type == "meeting":
            self.memory_manager.vector_db.store_transcript_embedding(
                transcript_id=text_id,
                embedding=embedding,
                metadata={
                    **metadata,
                    "content": text[:1000]  # Store preview of content
                }
            )
        else:  # Default to document
            self.memory_manager.vector_db.store_document_embedding(
                document_id=text_id,
                embedding=embedding,
                metadata={
                    **metadata,
                    "content": text[:1000]  # Store preview of content
                }
            )
        
        # Extract action items using AI
        action_items = self.bedrock_ai.extract_action_items(text)
        
        # Extract entities
        entities = self.bedrock_ai.extract_entities(text)
        
        # Generate summary
        summary = self.bedrock_ai.summarize_text(text)
        
        # Analyze sentiment
        sentiment = self.bedrock_ai.analyze_sentiment(text)
        
        # Return processing results
        return {
            "id": text_id,
            "source_type": source_type,
            "project_id": project_id,
            "timestamp": metadata["timestamp"],
            "summary": summary,
            "action_items": action_items,
            "entities": entities,
            "sentiment": sentiment
        }
    
    def ingest_chat(self, 
                   chat_text: str, 
                   project_id: Optional[str] = None, 
                   metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Ingest chat text data.
        
        Args:
            chat_text: Chat text content
            project_id: Optional project ID
            metadata: Optional additional metadata
            
        Returns:
            Processing results
        """
        return self.ingest_text(
            text=chat_text,
            source_type="chat",
            project_id=project_id,
            metadata=metadata
        )
    
    def ingest_meeting_transcript(self, 
                                transcript: str, 
                                project_id: Optional[str] = None, 
                                metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Ingest meeting transcript data.
        
        Args:
            transcript: Meeting transcript content
            project_id: Optional project ID
            metadata: Optional additional metadata
            
        Returns:
            Processing results
        """
        return self.ingest_text(
            text=transcript,
            source_type="meeting",
            project_id=project_id,
            metadata=metadata
        )
    
    def ingest_document(self, 
                       document_text: str, 
                       document_type: str,
                       project_id: Optional[str] = None, 
                       metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Ingest document text data.
        
        Args:
            document_text: Document text content
            document_type: Type of document (notes, report, etc.)
            project_id: Optional project ID
            metadata: Optional additional metadata
            
        Returns:
            Processing results
        """
        # Add document type to metadata
        if metadata is None:
            metadata = {}
        metadata["document_type"] = document_type
        
        return self.ingest_text(
            text=document_text,
            source_type="document",
            project_id=project_id,
            metadata=metadata
        )
    
    def ingest_image(self, 
                    image_data: Union[str, bytes], 
                    project_id: Optional[str] = None, 
                    metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Ingest and process image data.
        
        Args:
            image_data: Image data (base64 string or bytes)
            project_id: Optional project ID
            metadata: Optional additional metadata
            
        Returns:
            Processing results
        """
        # Ensure image_data is a base64 string
        if isinstance(image_data, bytes):
            image_data = base64.b64encode(image_data).decode('utf-8')
        
        # Generate a unique ID for the image
        image_id = str(uuid.uuid4())
        
        # Create metadata if not provided
        if metadata is None:
            metadata = {}
        
        # Add basic metadata
        metadata.update({
            "id": image_id,
            "source_type": "image",
            "timestamp": datetime.now().isoformat(),
            "project_id": project_id
        })
        
        # For now, we'll just store the metadata
        # In a real implementation, we would process the image with AI vision models
        # and extract text, objects, etc.
        
        return {
            "id": image_id,
            "source_type": "image",
            "project_id": project_id,
            "timestamp": metadata["timestamp"],
            "message": "Image ingested successfully"
        }
    
    def get_project_content(self, 
                          project_id: str, 
                          content_type: Optional[str] = None, 
                          limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get content associated with a project.
        
        Args:
            project_id: Project ID
            content_type: Optional content type filter (chat, meeting, document, image)
            limit: Maximum number of items to retrieve
            
        Returns:
            List of content items
        """
        results = []
        
        # Create filter dict
        filter_dict = {"project_id": project_id}
        
        # Get embeddings from vector database based on content type
        if content_type == "chat" or content_type is None:
            # Get chat messages
            query_embedding = [0.0] * 1536  # Dummy embedding for retrieving all
            messages = self.memory_manager.vector_db.search_messages(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(messages)
        
        if content_type == "meeting" or content_type is None:
            # Get meeting transcripts
            query_embedding = [0.0] * 1536  # Dummy embedding for retrieving all
            transcripts = self.memory_manager.vector_db.search_transcripts(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(transcripts)
        
        if content_type == "document" or content_type is None:
            # Get documents
            query_embedding = [0.0] * 1536  # Dummy embedding for retrieving all
            documents = self.memory_manager.vector_db.search_documents(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(documents)
        
        # Sort by timestamp
        results.sort(key=lambda x: x["metadata"].get("timestamp", ""), reverse=True)
        
        # Limit results
        return results[:limit]
    
    def search_content(self, 
                     query: str, 
                     project_id: Optional[str] = None, 
                     content_type: Optional[str] = None, 
                     limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for content using semantic search.
        
        Args:
            query: Search query
            project_id: Optional project ID filter
            content_type: Optional content type filter (chat, meeting, document, image)
            limit: Maximum number of results
            
        Returns:
            List of matching content items
        """
        # Generate embedding for the query
        query_embedding = self.bedrock_ai.generate_embeddings(query)
        
        # Create filter dict if project_id is provided
        filter_dict = {}
        if project_id:
            filter_dict["project_id"] = project_id
        
        results = []
        
        # Search in vector database based on content type
        if content_type == "chat" or content_type is None:
            # Search chat messages
            messages = self.memory_manager.vector_db.search_messages(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(messages)
        
        if content_type == "meeting" or content_type is None:
            # Search meeting transcripts
            transcripts = self.memory_manager.vector_db.search_transcripts(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(transcripts)
        
        if content_type == "document" or content_type is None:
            # Search documents
            documents = self.memory_manager.vector_db.search_documents(
                query_embedding=query_embedding,
                top_k=limit,
                filter_dict=filter_dict
            )
            results.extend(documents)
        
        # Sort by relevance score
        results.sort(key=lambda x: x["score"], reverse=True)
        
        # Limit results
        return results[:limit]
