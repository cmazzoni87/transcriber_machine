"""
Action item manager for the Personal Project Assistant.
This module provides functionality for managing action items extracted from various sources.
"""

import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional, Union

# Import database components
from ...database.db_manager import get_db_session
from ...database.models import Project

class ActionItemManager:
    """
    Action item manager for handling tasks and action items.
    Replaces the Asana integration with a local action item management system.
    """
    
    def __init__(self):
        """Initialize the action item manager."""
        self.action_items_file = os.path.join(os.path.dirname(__file__), "action_items.json")
        self._ensure_action_items_file_exists()
    
    def _ensure_action_items_file_exists(self):
        """Ensure that the action items file exists."""
        if not os.path.exists(self.action_items_file):
            with open(self.action_items_file, 'w') as f:
                json.dump([], f)
    
    def _load_action_items(self) -> List[Dict[str, Any]]:
        """
        Load action items from the JSON file.
        
        Returns:
            List of action items
        """
        try:
            with open(self.action_items_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading action items: {e}")
            return []
    
    def _save_action_items(self, action_items: List[Dict[str, Any]]):
        """
        Save action items to the JSON file.
        
        Args:
            action_items: List of action items to save
        """
        try:
            with open(self.action_items_file, 'w') as f:
                json.dump(action_items, f, indent=2)
        except Exception as e:
            print(f"Error saving action items: {e}")
    
    def get_action_items(self, 
                       project_id: Optional[str] = None, 
                       completed: Optional[bool] = None) -> List[Dict[str, Any]]:
        """
        Get action items, optionally filtered by project and completion status.
        
        Args:
            project_id: Optional project ID to filter by
            completed: Optional completion status to filter by
            
        Returns:
            List of matching action items
        """
        action_items = self._load_action_items()
        
        # Apply filters
        if project_id is not None:
            action_items = [item for item in action_items if item.get("project_id") == project_id]
        
        if completed is not None:
            action_items = [item for item in action_items if item.get("completed", False) == completed]
        
        # Sort by due date (if available), then by creation date
        action_items.sort(key=lambda x: (
            x.get("due_date", "9999-12-31"),
            x.get("created_at", "")
        ))
        
        return action_items
    
    def get_action_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific action item by ID.
        
        Args:
            item_id: Action item ID
            
        Returns:
            Action item if found, None otherwise
        """
        action_items = self._load_action_items()
        
        for item in action_items:
            if item.get("id") == item_id:
                return item
        
        return None
    
    def create_action_item(self, 
                         task: str, 
                         project_id: Optional[str] = None, 
                         assignee: Optional[str] = None, 
                         due_date: Optional[str] = None, 
                         priority: Optional[str] = None, 
                         notes: Optional[str] = None,
                         source_id: Optional[str] = None,
                         source_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new action item.
        
        Args:
            task: Task description
            project_id: Optional project ID
            assignee: Optional assignee name
            due_date: Optional due date (YYYY-MM-DD)
            priority: Optional priority (high, medium, low)
            notes: Optional additional notes
            source_id: Optional ID of the source content
            source_type: Optional type of the source content
            
        Returns:
            Created action item
        """
        action_items = self._load_action_items()
        
        # Generate a unique ID
        item_id = str(uuid.uuid4())
        
        # Create new action item
        new_item = {
            "id": item_id,
            "task": task,
            "project_id": project_id,
            "assignee": assignee,
            "due_date": due_date,
            "priority": priority or "medium",
            "notes": notes or "",
            "completed": False,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "source_id": source_id,
            "source_type": source_type
        }
        
        # Add to list
        action_items.append(new_item)
        
        # Save to file
        self._save_action_items(action_items)
        
        return new_item
    
    def update_action_item(self, 
                         item_id: str, 
                         task: Optional[str] = None, 
                         project_id: Optional[str] = None, 
                         assignee: Optional[str] = None, 
                         due_date: Optional[str] = None, 
                         priority: Optional[str] = None, 
                         notes: Optional[str] = None,
                         completed: Optional[bool] = None) -> Optional[Dict[str, Any]]:
        """
        Update an existing action item.
        
        Args:
            item_id: Action item ID
            task: Optional new task description
            project_id: Optional new project ID
            assignee: Optional new assignee name
            due_date: Optional new due date (YYYY-MM-DD)
            priority: Optional new priority (high, medium, low)
            notes: Optional new additional notes
            completed: Optional new completion status
            
        Returns:
            Updated action item if found, None otherwise
        """
        action_items = self._load_action_items()
        
        # Find the item to update
        for i, item in enumerate(action_items):
            if item.get("id") == item_id:
                # Update fields if provided
                if task is not None:
                    item["task"] = task
                if project_id is not None:
                    item["project_id"] = project_id
                if assignee is not None:
                    item["assignee"] = assignee
                if due_date is not None:
                    item["due_date"] = due_date
                if priority is not None:
                    item["priority"] = priority
                if notes is not None:
                    item["notes"] = notes
                if completed is not None:
                    item["completed"] = completed
                
                # Update timestamp
                item["updated_at"] = datetime.now().isoformat()
                
                # Save to file
                self._save_action_items(action_items)
                
                return item
        
        return None
    
    def delete_action_item(self, item_id: str) -> bool:
        """
        Delete an action item.
        
        Args:
            item_id: Action item ID
            
        Returns:
            True if deleted, False if not found
        """
        action_items = self._load_action_items()
        
        # Find the item to delete
        for i, item in enumerate(action_items):
            if item.get("id") == item_id:
                # Remove from list
                action_items.pop(i)
                
                # Save to file
                self._save_action_items(action_items)
                
                return True
        
        return False
    
    def complete_action_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        Mark an action item as completed.
        
        Args:
            item_id: Action item ID
            
        Returns:
            Updated action item if found, None otherwise
        """
        return self.update_action_item(item_id, completed=True)
    
    def uncomplete_action_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        Mark an action item as not completed.
        
        Args:
            item_id: Action item ID
            
        Returns:
            Updated action item if found, None otherwise
        """
        return self.update_action_item(item_id, completed=False)
    
    def create_action_items_from_list(self, 
                                    action_items: List[Dict[str, Any]], 
                                    project_id: Optional[str] = None,
                                    source_id: Optional[str] = None,
                                    source_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Create multiple action items from a list.
        
        Args:
            action_items: List of action item data
            project_id: Optional project ID to apply to all items
            source_id: Optional ID of the source content
            source_type: Optional type of the source content
            
        Returns:
            List of created action items
        """
        created_items = []
        
        for item_data in action_items:
            # Extract fields from item data
            task = item_data.get("task")
            if not task:
                continue  # Skip items without a task
            
            # Create the action item
            created_item = self.create_action_item(
                task=task,
                project_id=project_id or item_data.get("project_id"),
                assignee=item_data.get("assignee"),
                due_date=item_data.get("deadline") or item_data.get("due_date"),
                priority=item_data.get("priority"),
                notes=item_data.get("notes"),
                source_id=source_id,
                source_type=source_type
            )
            
            created_items.append(created_item)
        
        return created_items
