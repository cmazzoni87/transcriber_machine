"""
Slack analyzer module for the Personal Project Assistant.
This module handles the analysis of Slack messages and project matching.
"""

import os
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json

# Import database components
from ...database.models import SlackMessage, SlackChannel, SlackWorkspace, Project
from ...database.db_manager import get_db_session
from ...database.vector_db import VectorDatabase
from ...database.memory_manager import MemoryManager

# Import AI components
from ...ai.bedrock_ai import BedrockAI
from ...ai.ai_assistant import AIAssistant

# Import Slack client
from .slack_client import SlackIntegration

class SlackAnalyzer:
    """
    Slack analyzer for processing messages and matching them to projects.
    Handles message extraction, content analysis, and project matching.
    """
    
    def __init__(self, 
                slack_client: Optional[SlackIntegration] = None,
                ai_assistant: Optional[AIAssistant] = None,
                vector_db: Optional[VectorDatabase] = None):
        """
        Initialize the Slack analyzer.
        
        Args:
            slack_client: Slack client instance (creates new one if not provided)
            ai_assistant: AI assistant instance (creates new one if not provided)
            vector_db: Vector database instance (creates new one if not provided)
        """
        self.slack_client = slack_client
        self.ai_assistant = ai_assistant or AIAssistant()
        self.vector_db = vector_db or VectorDatabase()
        self.bedrock_ai = BedrockAI()
    
    def analyze_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze a single Slack message.
        
        Args:
            message: Message dictionary from Slack client
            
        Returns:
            Analysis results
        """
        # Extract message text
        text = message.get("text", "")
        
        if not text or len(text) < 10:
            return {
                "message_id": message.get("id", ""),
                "analysis": "Message too short for analysis",
                "entities": [],
                "sentiment": {"sentiment": "neutral", "confidence": 0.5},
                "project_match": None,
                "action_items": []
            }
        
        # Extract entities
        entities = self.bedrock_ai.extract_entities(text)
        
        # Analyze sentiment
        sentiment = self.bedrock_ai.analyze_sentiment(text)
        
        # Generate embeddings for project matching
        embedding = self.bedrock_ai.generate_embeddings(text)
        
        # Analyze message with AI assistant
        analysis_result = self.ai_assistant.analyze_slack_conversation(text)
        
        return {
            "message_id": message.get("id", ""),
            "analysis": analysis_result.get("analysis", ""),
            "entities": entities,
            "sentiment": sentiment,
            "project_match": analysis_result.get("project_match", []),
            "action_items": analysis_result.get("action_items", []),
            "embedding": embedding
        }
    
    def analyze_conversation(self, 
                           messages: List[Dict[str, Any]], 
                           thread: bool = False) -> Dict[str, Any]:
        """
        Analyze a conversation (multiple messages).
        
        Args:
            messages: List of message dictionaries
            thread: Whether this is a thread conversation
            
        Returns:
            Analysis results
        """
        # Combine messages into a conversation
        conversation = ""
        for msg in messages:
            user_name = msg.get("user", {}).get("name", "Unknown")
            text = msg.get("text", "")
            timestamp = msg.get("datetime", "")
            
            conversation += f"[{timestamp}] {user_name}: {text}\n\n"
        
        if not conversation or len(conversation) < 20:
            return {
                "conversation_type": "thread" if thread else "channel",
                "message_count": len(messages),
                "analysis": "Conversation too short for analysis",
                "entities": [],
                "sentiment": {"sentiment": "neutral", "confidence": 0.5},
                "project_match": None,
                "action_items": []
            }
        
        # Analyze conversation with AI assistant
        analysis_result = self.ai_assistant.analyze_slack_conversation(conversation)
        
        # Extract entities from the whole conversation
        entities = self.bedrock_ai.extract_entities(conversation)
        
        # Analyze sentiment of the whole conversation
        sentiment = self.bedrock_ai.analyze_sentiment(conversation)
        
        # Generate embeddings for project matching
        embedding = self.bedrock_ai.generate_embeddings(conversation)
        
        return {
            "conversation_type": "thread" if thread else "channel",
            "message_count": len(messages),
            "analysis": analysis_result.get("analysis", ""),
            "entities": entities,
            "sentiment": sentiment,
            "project_match": analysis_result.get("project_match", []),
            "action_items": analysis_result.get("action_items", []),
            "embedding": embedding
        }
    
    def match_to_project(self, 
                       text: str, 
                       embedding: Optional[List[float]] = None) -> List[Dict[str, Any]]:
        """
        Match a message or conversation to projects.
        
        Args:
            text: Message or conversation text
            embedding: Optional pre-computed embedding
            
        Returns:
            List of matching projects with scores
        """
        # Generate embeddings if not provided
        if not embedding:
            embedding = self.bedrock_ai.generate_embeddings(text)
        
        if not embedding:
            return []
        
        # Get project embeddings from vector database
        # In a real implementation, we would have a separate collection for project embeddings
        # For now, we'll use a simple approach with the AI assistant
        
        # Use AI to identify potential project matches
        system_prompt = """
        You are a project matching expert. Analyze the provided text and identify which projects it might be related to.
        Return a JSON array of objects with 'project_name' and 'confidence' (0-1) fields, sorted by confidence.
        """
        
        user_prompt = f"Match this text to potential projects:\n\n{text}"
        
        response = self.bedrock_ai.generate_response(
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
        
        try:
            # Extract JSON from response
            import re
            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                project_matches = json.loads(json_match.group(0))
                return project_matches
            else:
                return []
        except Exception as e:
            print(f"Error parsing project match response: {e}")
            return []
    
    def store_message(self, 
                    message: Dict[str, Any], 
                    channel: Dict[str, Any], 
                    project_id: Optional[str] = None,
                    analysis: Optional[Dict[str, Any]] = None) -> bool:
        """
        Store a message in the database and vector database.
        
        Args:
            message: Message dictionary
            channel: Channel dictionary
            project_id: Optional project ID
            analysis: Optional pre-computed analysis
            
        Returns:
            Success status
        """
        try:
            # Store in SQL database
            with get_db_session() as session:
                # Check if workspace exists
                workspace = session.query(SlackWorkspace).filter_by(
                    workspace_id=self.slack_client.workspace_id
                ).first()
                
                if not workspace:
                    # Create workspace
                    workspace = SlackWorkspace(
                        workspace_id=self.slack_client.workspace_id,
                        name=self.slack_client.workspace_name
                    )
                    session.add(workspace)
                    session.flush()
                
                # Check if channel exists
                db_channel = session.query(SlackChannel).filter_by(
                    channel_id=channel["id"]
                ).first()
                
                if not db_channel:
                    # Create channel
                    db_channel = SlackChannel(
                        workspace_id=workspace.id,
                        channel_id=channel["id"],
                        name=channel["name"],
                        is_private=channel.get("is_private", False)
                    )
                    session.add(db_channel)
                    session.flush()
                
                # Create message
                db_message = SlackMessage(
                    channel_id=db_channel.id,
                    project_id=project_id,
                    message_id=message["id"],
                    sender=message.get("user", {}).get("name", "Unknown"),
                    message=message.get("text", ""),
                    timestamp=datetime.fromtimestamp(float(message.get("ts", 0)))
                )
                session.add(db_message)
                session.commit()
            
            # Store in vector database if analysis is available
            if analysis and "embedding" in analysis:
                # Create metadata
                metadata = {
                    "content": message.get("text", ""),
                    "sender": message.get("user", {}).get("name", "Unknown"),
                    "channel": channel.get("name", "Unknown"),
                    "project_id": project_id,
                    "timestamp": message.get("datetime", ""),
                    "message_id": message.get("id", ""),
                    "entities": analysis.get("entities", []),
                    "sentiment": analysis.get("sentiment", {})
                }
                
                # Store embedding
                self.vector_db.store_message_embedding(
                    message_id=message["id"],
                    embedding=analysis["embedding"],
                    metadata=metadata
                )
            
            return True
        except Exception as e:
            print(f"Error storing message: {e}")
            return False
    
    def process_new_messages(self, 
                           channel_id: str, 
                           limit: int = 100, 
                           since: Optional[str] = None) -> Dict[str, Any]:
        """
        Process new messages from a channel.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to process
            since: Timestamp to start from (defaults to 1 day ago)
            
        Returns:
            Processing results
        """
        # Set default since timestamp to 1 day ago if not provided
        if not since:
            one_day_ago = datetime.now() - timedelta(days=1)
            since = str(int(one_day_ago.timestamp()))
        
        # Get channel info
        channels = self.slack_client.get_channels()
        channel = next((c for c in channels if c["id"] == channel_id), {"id": channel_id, "name": "Unknown"})
        
        # Get messages
        messages = self.slack_client.get_channel_messages(
            channel_id=channel_id,
            limit=limit,
            oldest=since
        )
        
        if not messages:
            return {
                "channel": channel,
                "message_count": 0,
                "processed_count": 0,
                "project_matches": []
            }
        
        # Analyze conversation
        conversation_analysis = self.analyze_conversation(messages)
        
        # Match to projects
        project_matches = self.match_to_project(
            text="\n".join([m.get("text", "") for m in messages]),
            embedding=conversation_analysis.get("embedding")
        )
        
        # Process individual messages
        processed_count = 0
        for message in messages:
            # Analyze message
            message_analysis = self.analyze_message(message)
            
            # Determine project ID (use the top match from conversation analysis)
            project_id = None
            if project_matches and len(project_matches) > 0:
                project_id = project_matches[0].get("project_id")
            
            # Store message
            success = self.store_message(
                message=message,
                channel=channel,
                project_id=project_id,
                analysis=message_analysis
            )
            
            if success:
                processed_count += 1
        
        return {
            "channel": channel,
            "message_count": len(messages),
            "processed_count": processed_count,
            "project_matches": project_matches,
            "conversation_analysis": {
                "analysis": conversation_analysis.get("analysis", ""),
                "action_items": conversation_analysis.get("action_items", [])
            }
        }
    
    def monitor_channels(self, 
                       channel_ids: Optional[List[str]] = None, 
                       interval: int = 3600) -> None:
        """
        Monitor channels for new messages.
        
        Args:
            channel_ids: List of channel IDs to monitor (defaults to all channels)
            interval: Monitoring interval in seconds
            
        Note: This method runs indefinitely until interrupted.
        """
        # Get all channels if not specified
        if not channel_ids:
            channels = self.slack_client.get_channels()
            channel_ids = [c["id"] for c in channels]
        
        print(f"Monitoring {len(channel_ids)} channels for new messages...")
        
        try:
            while True:
                # Process each channel
                for channel_id in channel_ids:
                    print(f"Processing channel {channel_id}...")
                    result = self.process_new_messages(channel_id)
                    print(f"Processed {result['processed_count']} of {result['message_count']} messages in channel {result['channel']['name']}")
                
                # Wait for next interval
                print(f"Waiting {interval} seconds for next monitoring cycle...")
                time.sleep(interval)
        except KeyboardInterrupt:
            print("Monitoring stopped by user.")
        except Exception as e:
            print(f"Error during monitoring: {e}")
