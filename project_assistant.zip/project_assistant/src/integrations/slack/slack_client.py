"""
Slack integration for the Personal Project Assistant.
This module handles authentication, workspace connection, and message retrieval from Slack.
"""

import os
import time
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class SlackIntegration:
    """
    Slack integration for retrieving and analyzing messages.
    Handles authentication, workspace connection, and message retrieval.
    """
    
    def __init__(self, token: Optional[str] = None):
        """
        Initialize the Slack integration.
        
        Args:
            token: Slack API token (defaults to environment variable)
        """
        self.token = token or os.getenv("SLACK_API_TOKEN")
        
        if not self.token:
            raise ValueError("Slack API token must be provided")
        
        # Initialize Slack client
        self.client = WebClient(token=self.token)
        
        # Test connection
        try:
            auth_test = self.client.auth_test()
            self.workspace_id = auth_test["team_id"]
            self.workspace_name = auth_test["team"]
            self.user_id = auth_test["user_id"]
            self.user_name = auth_test["user"]
            print(f"Connected to Slack workspace: {self.workspace_name}")
        except SlackApiError as e:
            print(f"Error connecting to Slack: {e}")
            raise
    
    def get_channels(self, include_private: bool = False) -> List[Dict[str, Any]]:
        """
        Get list of channels in the workspace.
        
        Args:
            include_private: Whether to include private channels
            
        Returns:
            List of channel information dictionaries
        """
        channels = []
        
        try:
            # Get public channels
            response = self.client.conversations_list(types="public_channel")
            channels.extend(response["channels"])
            
            # Get private channels if requested
            if include_private:
                response = self.client.conversations_list(types="private_channel")
                channels.extend(response["channels"])
            
            # Format channel information
            formatted_channels = []
            for channel in channels:
                formatted_channels.append({
                    "id": channel["id"],
                    "name": channel["name"],
                    "is_private": channel["is_private"],
                    "num_members": channel["num_members"],
                    "topic": channel.get("topic", {}).get("value", ""),
                    "purpose": channel.get("purpose", {}).get("value", "")
                })
            
            return formatted_channels
        except SlackApiError as e:
            print(f"Error getting channels: {e}")
            return []
    
    def get_channel_messages(self, 
                           channel_id: str, 
                           limit: int = 100, 
                           oldest: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get messages from a channel.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to retrieve
            oldest: Timestamp of oldest message to retrieve (defaults to 1 week ago)
            
        Returns:
            List of message dictionaries
        """
        messages = []
        
        # Set default oldest timestamp to 1 week ago if not provided
        if not oldest:
            one_week_ago = datetime.now() - timedelta(days=7)
            oldest = str(int(one_week_ago.timestamp()))
        
        try:
            # Get messages
            response = self.client.conversations_history(
                channel=channel_id,
                limit=limit,
                oldest=oldest
            )
            
            # Format messages
            for msg in response["messages"]:
                # Skip bot messages and system messages
                if msg.get("subtype") in ["bot_message", "channel_join", "channel_leave"]:
                    continue
                
                # Get user info
                user_info = {}
                if "user" in msg:
                    try:
                        user_response = self.client.users_info(user=msg["user"])
                        user = user_response["user"]
                        user_info = {
                            "id": user["id"],
                            "name": user["name"],
                            "real_name": user.get("real_name", ""),
                            "display_name": user.get("profile", {}).get("display_name", ""),
                            "email": user.get("profile", {}).get("email", "")
                        }
                    except SlackApiError:
                        user_info = {
                            "id": msg["user"],
                            "name": "Unknown User"
                        }
                
                # Format message
                formatted_msg = {
                    "id": msg.get("ts", ""),
                    "text": msg.get("text", ""),
                    "user": user_info,
                    "timestamp": msg.get("ts", ""),
                    "datetime": datetime.fromtimestamp(float(msg.get("ts", 0))).isoformat(),
                    "reactions": msg.get("reactions", []),
                    "replies": msg.get("reply_count", 0),
                    "thread_ts": msg.get("thread_ts", None)
                }
                
                messages.append(formatted_msg)
            
            return messages
        except SlackApiError as e:
            print(f"Error getting messages from channel {channel_id}: {e}")
            return []
    
    def get_thread_messages(self, 
                          channel_id: str, 
                          thread_ts: str) -> List[Dict[str, Any]]:
        """
        Get messages from a thread.
        
        Args:
            channel_id: Channel ID
            thread_ts: Thread timestamp
            
        Returns:
            List of message dictionaries
        """
        messages = []
        
        try:
            # Get thread messages
            response = self.client.conversations_replies(
                channel=channel_id,
                ts=thread_ts
            )
            
            # Format messages
            for msg in response["messages"]:
                # Skip the parent message (it's already included in channel messages)
                if msg.get("ts") == thread_ts:
                    continue
                
                # Get user info
                user_info = {}
                if "user" in msg:
                    try:
                        user_response = self.client.users_info(user=msg["user"])
                        user = user_response["user"]
                        user_info = {
                            "id": user["id"],
                            "name": user["name"],
                            "real_name": user.get("real_name", ""),
                            "display_name": user.get("profile", {}).get("display_name", ""),
                            "email": user.get("profile", {}).get("email", "")
                        }
                    except SlackApiError:
                        user_info = {
                            "id": msg["user"],
                            "name": "Unknown User"
                        }
                
                # Format message
                formatted_msg = {
                    "id": msg.get("ts", ""),
                    "text": msg.get("text", ""),
                    "user": user_info,
                    "timestamp": msg.get("ts", ""),
                    "datetime": datetime.fromtimestamp(float(msg.get("ts", 0))).isoformat(),
                    "reactions": msg.get("reactions", []),
                    "parent_ts": thread_ts
                }
                
                messages.append(formatted_msg)
            
            return messages
        except SlackApiError as e:
            print(f"Error getting thread messages from channel {channel_id}: {e}")
            return []
    
    def search_messages(self, 
                      query: str, 
                      count: int = 100, 
                      sort: str = "timestamp", 
                      sort_dir: str = "desc") -> List[Dict[str, Any]]:
        """
        Search for messages across all channels.
        
        Args:
            query: Search query
            count: Maximum number of results
            sort: Sort field (timestamp or score)
            sort_dir: Sort direction (asc or desc)
            
        Returns:
            List of message dictionaries
        """
        messages = []
        
        try:
            # Search messages
            response = self.client.search_messages(
                query=query,
                count=count,
                sort=sort,
                sort_dir=sort_dir
            )
            
            # Format messages
            for match in response["messages"]["matches"]:
                # Get channel info
                channel_info = {}
                if "channel" in match:
                    try:
                        channel_response = self.client.conversations_info(channel=match["channel"]["id"])
                        channel = channel_response["channel"]
                        channel_info = {
                            "id": channel["id"],
                            "name": channel["name"],
                            "is_private": channel.get("is_private", False)
                        }
                    except SlackApiError:
                        channel_info = {
                            "id": match["channel"]["id"],
                            "name": "Unknown Channel"
                        }
                
                # Get user info
                user_info = {}
                if "user" in match:
                    try:
                        user_response = self.client.users_info(user=match["user"])
                        user = user_response["user"]
                        user_info = {
                            "id": user["id"],
                            "name": user["name"],
                            "real_name": user.get("real_name", ""),
                            "display_name": user.get("profile", {}).get("display_name", ""),
                            "email": user.get("profile", {}).get("email", "")
                        }
                    except SlackApiError:
                        user_info = {
                            "id": match["user"],
                            "name": "Unknown User"
                        }
                
                # Format message
                formatted_msg = {
                    "id": match.get("ts", ""),
                    "text": match.get("text", ""),
                    "user": user_info,
                    "channel": channel_info,
                    "timestamp": match.get("ts", ""),
                    "datetime": datetime.fromtimestamp(float(match.get("ts", 0))).isoformat(),
                    "permalink": match.get("permalink", "")
                }
                
                messages.append(formatted_msg)
            
            return messages
        except SlackApiError as e:
            print(f"Error searching messages: {e}")
            return []
    
    def get_user_info(self, user_id: str) -> Dict[str, Any]:
        """
        Get information about a user.
        
        Args:
            user_id: User ID
            
        Returns:
            User information dictionary
        """
        try:
            # Get user info
            response = self.client.users_info(user=user_id)
            user = response["user"]
            
            # Format user info
            user_info = {
                "id": user["id"],
                "name": user["name"],
                "real_name": user.get("real_name", ""),
                "display_name": user.get("profile", {}).get("display_name", ""),
                "email": user.get("profile", {}).get("email", ""),
                "title": user.get("profile", {}).get("title", ""),
                "phone": user.get("profile", {}).get("phone", ""),
                "is_admin": user.get("is_admin", False),
                "is_owner": user.get("is_owner", False),
                "is_bot": user.get("is_bot", False),
                "updated": user.get("updated", 0),
                "timezone": user.get("tz", "")
            }
            
            return user_info
        except SlackApiError as e:
            print(f"Error getting user info for {user_id}: {e}")
            return {}
    
    def send_message(self, 
                   channel_id: str, 
                   text: str, 
                   thread_ts: Optional[str] = None) -> Dict[str, Any]:
        """
        Send a message to a channel.
        
        Args:
            channel_id: Channel ID
            text: Message text
            thread_ts: Optional thread timestamp to reply to
            
        Returns:
            Response dictionary
        """
        try:
            # Send message
            if thread_ts:
                response = self.client.chat_postMessage(
                    channel=channel_id,
                    text=text,
                    thread_ts=thread_ts
                )
            else:
                response = self.client.chat_postMessage(
                    channel=channel_id,
                    text=text
                )
            
            return {
                "success": True,
                "message_id": response["ts"],
                "channel": response["channel"]
            }
        except SlackApiError as e:
            print(f"Error sending message to channel {channel_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_workspace_info(self) -> Dict[str, Any]:
        """
        Get information about the connected workspace.
        
        Returns:
            Workspace information dictionary
        """
        try:
            # Get workspace info
            response = self.client.team_info(team=self.workspace_id)
            team = response["team"]
            
            # Format workspace info
            workspace_info = {
                "id": team["id"],
                "name": team["name"],
                "domain": team.get("domain", ""),
                "email_domain": team.get("email_domain", ""),
                "icon": team.get("icon", {}),
                "enterprise_id": team.get("enterprise_id", ""),
                "enterprise_name": team.get("enterprise_name", "")
            }
            
            return workspace_info
        except SlackApiError as e:
            print(f"Error getting workspace info: {e}")
            return {
                "id": self.workspace_id,
                "name": self.workspace_name
            }
