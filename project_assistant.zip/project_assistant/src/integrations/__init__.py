"""
Integrations package for the Personal Project Assistant.
This package contains modules for integrating with external services and systems.
"""

# Import manual ingestion components
from .manual_ingestion.manual_ingestion_service import ManualIngestionService
from .manual_ingestion.action_item_manager import ActionItemManager
