"""
Asana API integration for the Personal Project Assistant.
This module handles authentication, workspace connection, and task management with Asana.
"""

import os
import time
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
import json
import asana
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class AsanaIntegration:
    """
    Asana integration for task management.
    Handles authentication, workspace connection, and task operations.
    """
    
    def __init__(self, token: Optional[str] = None):
        """
        Initialize the Asana integration.
        
        Args:
            token: Asana API token (defaults to environment variable)
        """
        self.token = token or os.getenv("ASANA_API_TOKEN")
        
        if not self.token:
            raise ValueError("Asana API token must be provided")
        
        # Initialize Asana client
        self.client = asana.Client.access_token(self.token)
        
        # Test connection
        try:
            me = self.client.users.me()
            self.user_id = me["gid"]
            self.user_name = me["name"]
            print(f"Connected to Asana as: {self.user_name}")
        except Exception as e:
            print(f"Error connecting to Asana: {e}")
            raise
    
    def get_workspaces(self) -> List[Dict[str, Any]]:
        """
        Get list of workspaces.
        
        Returns:
            List of workspace information dictionaries
        """
        try:
            workspaces = self.client.workspaces.get_workspaces()
            
            # Format workspace information
            formatted_workspaces = []
            for workspace in workspaces:
                formatted_workspaces.append({
                    "id": workspace["gid"],
                    "name": workspace["name"],
                    "is_organization": workspace.get("is_organization", False)
                })
            
            return formatted_workspaces
        except Exception as e:
            print(f"Error getting workspaces: {e}")
            return []
    
    def get_projects(self, workspace_id: str) -> List[Dict[str, Any]]:
        """
        Get list of projects in a workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            List of project information dictionaries
        """
        try:
            projects = self.client.projects.get_projects({"workspace": workspace_id})
            
            # Format project information
            formatted_projects = []
            for project in projects:
                formatted_projects.append({
                    "id": project["gid"],
                    "name": project["name"],
                    "owner": project.get("owner", {}).get("name", "Unassigned"),
                    "due_date": project.get("due_date"),
                    "created_at": project.get("created_at"),
                    "modified_at": project.get("modified_at"),
                    "public": project.get("public", False),
                    "archived": project.get("archived", False)
                })
            
            return formatted_projects
        except Exception as e:
            print(f"Error getting projects for workspace {workspace_id}: {e}")
            return []
    
    def get_tasks(self, 
                project_id: str, 
                completed: bool = False, 
                limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get list of tasks in a project.
        
        Args:
            project_id: Project ID
            completed: Whether to include completed tasks
            limit: Maximum number of tasks to retrieve
            
        Returns:
            List of task information dictionaries
        """
        try:
            # Set up parameters
            params = {
                "project": project_id,
                "limit": limit,
                "opt_fields": "gid,name,notes,assignee,due_date,due_on,completed,completed_at,created_at,modified_at,tags"
            }
            
            if not completed:
                params["completed"] = False
            
            tasks = self.client.tasks.get_tasks(params)
            
            # Format task information
            formatted_tasks = []
            for task in tasks:
                # Get assignee information
                assignee = None
                if task.get("assignee"):
                    assignee = {
                        "id": task["assignee"]["gid"],
                        "name": task["assignee"]["name"]
                    }
                
                formatted_tasks.append({
                    "id": task["gid"],
                    "name": task["name"],
                    "notes": task.get("notes", ""),
                    "assignee": assignee,
                    "due_date": task.get("due_on") or task.get("due_date"),
                    "completed": task.get("completed", False),
                    "completed_at": task.get("completed_at"),
                    "created_at": task.get("created_at"),
                    "modified_at": task.get("modified_at"),
                    "tags": [tag["name"] for tag in task.get("tags", [])]
                })
            
            return formatted_tasks
        except Exception as e:
            print(f"Error getting tasks for project {project_id}: {e}")
            return []
    
    def get_task(self, task_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            Task information dictionary
        """
        try:
            task = self.client.tasks.get_task(task_id, {
                "opt_fields": "gid,name,notes,assignee,due_date,due_on,completed,completed_at,created_at,modified_at,tags,projects,parent,subtasks"
            })
            
            # Get assignee information
            assignee = None
            if task.get("assignee"):
                assignee = {
                    "id": task["assignee"]["gid"],
                    "name": task["assignee"]["name"]
                }
            
            # Get project information
            projects = []
            if task.get("projects"):
                for project in task["projects"]:
                    projects.append({
                        "id": project["gid"],
                        "name": project["name"]
                    })
            
            # Get subtasks
            subtasks = []
            if task.get("subtasks"):
                for subtask in task["subtasks"]:
                    subtasks.append({
                        "id": subtask["gid"],
                        "name": subtask["name"]
                    })
            
            # Format task information
            formatted_task = {
                "id": task["gid"],
                "name": task["name"],
                "notes": task.get("notes", ""),
                "assignee": assignee,
                "due_date": task.get("due_on") or task.get("due_date"),
                "completed": task.get("completed", False),
                "completed_at": task.get("completed_at"),
                "created_at": task.get("created_at"),
                "modified_at": task.get("modified_at"),
                "tags": [tag["name"] for tag in task.get("tags", [])],
                "projects": projects,
                "parent": task.get("parent", {}).get("gid") if task.get("parent") else None,
                "subtasks": subtasks
            }
            
            return formatted_task
        except Exception as e:
            print(f"Error getting task {task_id}: {e}")
            return {}
    
    def create_task(self, 
                  name: str, 
                  project_id: str, 
                  notes: Optional[str] = None, 
                  assignee: Optional[str] = None, 
                  due_date: Optional[str] = None, 
                  tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Create a new task in a project.
        
        Args:
            name: Task name
            project_id: Project ID
            notes: Optional task description
            assignee: Optional assignee user ID
            due_date: Optional due date (YYYY-MM-DD)
            tags: Optional list of tag names
            
        Returns:
            Created task information
        """
        try:
            # Set up task data
            task_data = {
                "name": name,
                "projects": [project_id]
            }
            
            if notes:
                task_data["notes"] = notes
            
            if assignee:
                task_data["assignee"] = assignee
            
            if due_date:
                task_data["due_on"] = due_date
            
            # Create task
            task = self.client.tasks.create_task(task_data)
            
            # Add tags if provided
            if tags and len(tags) > 0:
                for tag_name in tags:
                    # Find or create tag
                    try:
                        # Get project to find workspace
                        project = self.client.projects.get_project(project_id)
                        workspace_id = project["workspace"]["gid"]
                        
                        # Find tags in workspace
                        workspace_tags = self.client.tags.get_tags({"workspace": workspace_id})
                        tag = next((t for t in workspace_tags if t["name"] == tag_name), None)
                        
                        if not tag:
                            # Create tag if it doesn't exist
                            tag = self.client.tags.create_tag({
                                "name": tag_name,
                                "workspace": workspace_id
                            })
                        
                        # Add tag to task
                        self.client.tasks.add_tag(task["gid"], {"tag": tag["gid"]})
                    except Exception as tag_error:
                        print(f"Error adding tag {tag_name} to task: {tag_error}")
            
            # Get complete task information
            return self.get_task(task["gid"])
        except Exception as e:
            print(f"Error creating task: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_task(self, 
                  task_id: str, 
                  name: Optional[str] = None, 
                  notes: Optional[str] = None, 
                  assignee: Optional[str] = None, 
                  due_date: Optional[str] = None, 
                  completed: Optional[bool] = None) -> Dict[str, Any]:
        """
        Update an existing task.
        
        Args:
            task_id: Task ID
            name: Optional new task name
            notes: Optional new task description
            assignee: Optional new assignee user ID
            due_date: Optional new due date (YYYY-MM-DD)
            completed: Optional completion status
            
        Returns:
            Updated task information
        """
        try:
            # Set up task data
            task_data = {}
            
            if name:
                task_data["name"] = name
            
            if notes:
                task_data["notes"] = notes
            
            if assignee:
                task_data["assignee"] = assignee
            elif assignee == "":
                task_data["assignee"] = None  # Remove assignee
            
            if due_date:
                task_data["due_on"] = due_date
            elif due_date == "":
                task_data["due_on"] = None  # Remove due date
            
            if completed is not None:
                task_data["completed"] = completed
            
            # Update task
            task = self.client.tasks.update_task(task_id, task_data)
            
            # Get complete task information
            return self.get_task(task["gid"])
        except Exception as e:
            print(f"Error updating task {task_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def delete_task(self, task_id: str) -> Dict[str, bool]:
        """
        Delete a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            Success status
        """
        try:
            self.client.tasks.delete_task(task_id)
            return {"success": True}
        except Exception as e:
            print(f"Error deleting task {task_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def create_subtask(self, 
                     parent_id: str, 
                     name: str, 
                     notes: Optional[str] = None, 
                     assignee: Optional[str] = None, 
                     due_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a subtask under a parent task.
        
        Args:
            parent_id: Parent task ID
            name: Subtask name
            notes: Optional subtask description
            assignee: Optional assignee user ID
            due_date: Optional due date (YYYY-MM-DD)
            
        Returns:
            Created subtask information
        """
        try:
            # Set up subtask data
            subtask_data = {
                "name": name,
                "parent": parent_id
            }
            
            if notes:
                subtask_data["notes"] = notes
            
            if assignee:
                subtask_data["assignee"] = assignee
            
            if due_date:
                subtask_data["due_on"] = due_date
            
            # Create subtask
            subtask = self.client.tasks.create_subtask_for_task(parent_id, subtask_data)
            
            # Get complete subtask information
            return self.get_task(subtask["gid"])
        except Exception as e:
            print(f"Error creating subtask for {parent_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def add_comment(self, 
                  task_id: str, 
                  text: str) -> Dict[str, Any]:
        """
        Add a comment to a task.
        
        Args:
            task_id: Task ID
            text: Comment text
            
        Returns:
            Created comment information
        """
        try:
            # Create comment
            comment = self.client.stories.create_story_for_task(task_id, {
                "text": text
            })
            
            return {
                "success": True,
                "id": comment["gid"],
                "text": comment["text"],
                "created_at": comment["created_at"],
                "created_by": {
                    "id": comment["created_by"]["gid"],
                    "name": comment["created_by"]["name"]
                }
            }
        except Exception as e:
            print(f"Error adding comment to task {task_id}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_task_comments(self, task_id: str) -> List[Dict[str, Any]]:
        """
        Get comments on a task.
        
        Args:
            task_id: Task ID
            
        Returns:
            List of comment information dictionaries
        """
        try:
            # Get stories (comments)
            stories = self.client.stories.get_stories_for_task(task_id)
            
            # Format comment information
            <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>