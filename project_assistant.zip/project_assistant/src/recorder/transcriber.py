"""
Transcriber module for the Personal Project Assistant.
This module handles the transcription of audio recordings using AWS Transcribe.
"""

import boto3
import time
import requests
import json
import os
from pathlib import Path
import sys

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import utils for transcript formatting
from src.recorder.utils import format_transcript

def upload_to_s3(file_path, bucket_name, object_name):
    """Uploads a file to S3."""
    s3 = boto3.client('s3')
    try:
        s3.upload_file(file_path, bucket_name, object_name)
        print(f"File {file_path} uploaded to S3 bucket {bucket_name} as {object_name}.")
    except Exception as e:
        print(f"Error uploading to S3: {e}")
        raise

def start_transcription_job(job_name, bucket_name, object_name, region='us-east-1'):
    """Starts a transcription job with speaker identification."""
    transcribe = boto3.client('transcribe', region_name=region)
    file_uri = f"s3://{bucket_name}/{object_name}"
    try:
        response = transcribe.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={'MediaFileUri': file_uri},
            MediaFormat='wav',  # Change format if needed (e.g., wav, mp4)
            LanguageCode='en-US',
            Settings={'ShowSpeakerLabels': True, 'MaxSpeakerLabels': 10}
        )
        print(f"Transcription job {job_name} started.")
        return response
    except Exception as e:
        print(f"Error starting transcription job: {e}")
        raise

def get_transcription_result(job_name, region='us-east-1'):
    """Gets the result of a transcription job."""
    transcribe = boto3.client('transcribe', region_name=region)
    while True:
        status = transcribe.get_transcription_job(TranscriptionJobName=job_name)
        job_status = status['TranscriptionJob']['TranscriptionJobStatus']
        if job_status in ['COMPLETED', 'FAILED']:
            break
        print("Waiting for transcription to complete...")
        time.sleep(10)

    if job_status == 'COMPLETED':
        result_url = status['TranscriptionJob']['Transcript']['TranscriptFileUri']
        print(f"Transcription completed. Result URL: {result_url}")
        return result_url
    else:
        print("Transcription failed.")
        raise Exception("Transcription job failed.")

def download_transcription_result(result_url, output_file):
    """Downloads the transcription result JSON file."""
    response = requests.get(result_url)
    if response.status_code == 200:
        with open(output_file, 'w') as f:
            f.write(response.text)
        print(f"Transcription result saved to {output_file}.")
    else:
        print(f"Error downloading transcription result: {response.status_code}")
        raise

def transcribe(file_path):
    """
    Transcribe an audio file using AWS Transcribe.
    
    Args:
        file_path: Path to the audio file
        
    Returns:
        Path to the transcript text file
    """
    # Local audio file
    file_name = file_path.split('/')[-1]
    bucket_name = "my-work-transcripts"        # S3 bucket name
    object_name = f"audio/{file_name}"            # S3 object name
    job_title = file_name.replace('.wav','')
    job_name = f"dialogs-transcription-job-name-{job_title}"  # Unique transcription job name
    region = "us-east-1"                      # AWS region
    
    # Create output directory if it doesn't exist
    output_dir = os.path.join(os.path.dirname(os.path.dirname(file_path)), "transcripts")
    os.makedirs(output_dir, exist_ok=True)
    
    output_file = os.path.join(output_dir, f"{job_title}.json")  # JSON output file
    
    # Steps
    try:
        # Step 1: Upload audio file to S3
        upload_to_s3(file_path, bucket_name, object_name)
        
        # Step 2: Start transcription job
        start_transcription_job(job_name, bucket_name, object_name, region)
        
        # Step 3: Wait for the transcription job to complete and get the result URL
        result_url = get_transcription_result(job_name, region)
        
        # Step 4: Download the transcription result
        download_transcription_result(result_url, output_file)
        
        # Step 5: Format transcript
        labeled_transcript = format_transcript(output_file)
        
        # Step 6: Save formatted transcript
        clean_transcript = output_file.replace('.json','.txt')
        with open(clean_transcript, "w") as file:
            file.write(labeled_transcript)
        
        return clean_transcript
    except Exception as e:
        print(f"Error: {e}")
        return None
