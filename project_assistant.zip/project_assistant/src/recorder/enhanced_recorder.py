"""
Enhanced recorder module for the Personal Project Assistant.
This module extends the existing recorder.py functionality to integrate with the project assistant.
"""

import os
import psutil
import subprocess
import time
import datetime
import threading
import sys
from pathlib import Path

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import database components
from src.database.db_manager import get_db_session
from src.database.models import Meeting, Project
from src.database.vector_db import VectorDatabase

# Import AI components
from src.ai.ai_assistant import AIAssistant

# Import original transcriber
from src.recorder.transcriber import transcribe

# Target applications to monitor for video calls
TARGET_APPS_KEYWORDS = {
    "Slack": ["Call", "Meeting", "Video", "🎤", "Huddle"],
    "Amazon Chime": ["Call", "Meeting", "Standup"],
    "Cisco Webex": ["Call", "Cisco Webex Webinars", "Webex", "Join the webinar", "Webex"],
    "Webex Meetings": ["Call", "Meeting", "Webex", "Webinars", "Join the webinar", "Claudio"],
    "Webex": ["Call", "Meeting", "Webinars", "Join the webinar", "Webex"],
    "Cisco Webex Meetings": ["Join the webinar", "Webex"],
    "zoom.us": ["Call", "Meeting"]
}


def is_app_running(app_name):
    """Return True if any running process name contains app_name (case-insensitive)."""
    for proc in psutil.process_iter(['name']):
        try:
            proc_name = proc.info['name']
            if proc_name and app_name.lower() in proc_name.lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return False


def get_window_titles(app_name):
    """
    Returns a list of window titles for the given application by calling AppleScript.
    If the app isn't running or an error occurs, returns an empty list.
    """
    try:
        script = f'''
        tell application "System Events"
            set procList to every process whose name is "{app_name}"
            set titleList to {{}}
            repeat with proc in procList
                repeat with win in windows of proc
                    try
                        set end of titleList to name of win
                    end try
                end repeat
            end repeat
            return titleList
        end tell
        '''
        result = subprocess.run(["osascript", "-e", script],
                                capture_output=True, text=True)
        output = result.stdout.strip()
        if not output:
            return []
        titles = [t.strip() for t in output.split(",") if t.strip()]
        return titles
    except Exception as e:
        print(f"Error getting window titles for {app_name}: {e}")
        return []


def is_target_call_active():
    """
    Checks each target application.
    If any running app's window title contains one of the specified keywords,
    returns True to indicate a call is active.
    """
    for app, keywords in TARGET_APPS_KEYWORDS.items():
        if is_app_running(app):
            titles = get_window_titles(app)
            print(f"Window titles for {app}: {titles}")  # Debug output
            for title in titles:
                for keyword in keywords:
                    if keyword.lower() in title.lower() and title.lower() != 'amazon chime: meeting controls':
                        print(f"Active call detected in {app}: {title}")
                        return True, app, title
    return False, None, None


def start_audio_recording(meeting_folder):
    """
    Starts an FFmpeg process that records audio from the aggregate device.
    It uses avfoundation with input string ":0" (assumed that the aggregate device is at index 0).
    The output is saved inside meeting_folder.
    Returns the subprocess.Popen object.
    """
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(meeting_folder, f"audio_recording_{timestamp}.wav")
    print(f"Starting audio recording: {output_file}")
    cmd = [
        "ffmpeg",
        "-f", "avfoundation",
        "-i", ":0",  # adjust this if you use a different device
        "-acodec", "pcm_s16le",
        "-ar", "48000",
        output_file
    ]

    proc = subprocess.Popen(cmd,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    return proc, output_file


def screenshot_loop(mode, meeting_folder, stop_event):
    """
    Continuously takes screenshots every 5 seconds until stop_event is set.
    mode: "dual" for dual monitor (captures display 1 and 2), "single" for one display.
    Screenshots are saved inside a subfolder in meeting_folder.
    """
    if mode == "dual":
        output_dir = os.path.join(meeting_folder, "dual_screenshots")
        os.makedirs(output_dir, exist_ok=True)
        while not stop_event.is_set():
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            subprocess.run(["screencapture", "-x", "-D", "1", os.path.join(output_dir, f"screen1_{timestamp}.png")])
            subprocess.run(["screencapture", "-x", "-D", "2", os.path.join(output_dir, f"screen2_{timestamp}.png")])
            stop_event.wait(10)
    else:  # single mode
        output_dir = os.path.join(meeting_folder, "laptop_screenshots")
        os.makedirs(output_dir, exist_ok=True)
        while not stop_event.is_set():
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            subprocess.run(["screencapture", "-x", os.path.join(output_dir, f"screen_{timestamp}.png")])
            stop_event.wait(5)


def create_meeting_folder():
    """
    Creates (if necessary) a "meeting_files" folder in the same directory as this script,
    then creates a new subfolder named "meeting_YYYYMMDDHMS" based on the current time.
    Returns the full path to the meeting folder.
    """
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "meetings_files")
    os.makedirs(base_dir, exist_ok=True)
    meeting_folder = os.path.join(base_dir, f"meeting_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}")
    os.makedirs(meeting_folder, exist_ok=True)
    print(f"Created meeting folder: {meeting_folder}")
    return meeting_folder


def process_meeting_transcript(transcript_file, app_name, meeting_title):
    """
    Process a meeting transcript using AI assistant and store in database.
    
    Args:
        transcript_file: Path to the transcript file
        app_name: Name of the application where the meeting was detected
        meeting_title: Title of the meeting window
        
    Returns:
        Meeting ID in the database
    """
    try:
        # Read transcript content
        with open(transcript_file, 'r') as f:
            transcript_content = f.read()
        
        # Initialize AI assistant
        ai_assistant = AIAssistant()
        
        # Analyze transcript
        meeting_summary = ai_assistant.summarize_meeting(transcript_content)
        
        # Extract meeting details
        summary = meeting_summary.get("summary", "")
        action_items = meeting_summary.get("action_items", [])
        decisions = meeting_summary.get("decisions", [])
        
        # Determine project based on meeting title
        project_id = None
        
        # Store in database
        with get_db_session() as session:
            # Create meeting record
            meeting = Meeting(
                title=meeting_title or f"{app_name} Meeting",
                date=datetime.datetime.now(),
                duration=0,  # Will be updated when meeting ends
                project_id=project_id,
                recording_path=os.path.dirname(transcript_file),
                transcript_path=transcript_file,
                summary=summary
            )
            session.add(meeting)
            session.commit()
            
            # Store action items as tasks
            # This would typically create tasks in the database and in Asana
            
            return meeting.id
    except Exception as e:
        print(f"Error processing meeting transcript: {e}")
        return None


def store_transcript_embedding(transcript_file, meeting_id):
    """
    Store transcript embedding in vector database.
    
    Args:
        transcript_file: Path to the transcript file
        meeting_id: Meeting ID in the database
        
    Returns:
        Success status
    """
    try:
        # Read transcript content
        with open(transcript_file, 'r') as f:
            transcript_content = f.read()
        
        # Initialize AI assistant and vector database
        ai_assistant = AIAssistant()
        vector_db = VectorDatabase()
        
        # Generate embedding
        embedding = ai_assistant.generate_embeddings(transcript_content)
        
        if not embedding:
            print("Error generating embedding for transcript")
            return False
        
        # Get meeting details from database
        with get_db_session() as session:
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                print(f"Meeting with ID {meeting_id} not found")
                return False
            
            # Create metadata
            metadata = {
                "content": transcript_content,
                "title": meeting.title,
                "meeting_date": meeting.date.isoformat(),
                "project_id": meeting.project_id,
                "meeting_id": meeting_id
            }
            
            # Store embedding
            vector_db.store_transcript_embedding(
                transcript_id=str(meeting_id),
                embedding=embedding,
                metadata=metadata
            )
            
            return True
    except Exception as e:
        print(f"Error storing transcript embedding: {e}")
        return False


def main():
    """
    Main function to monitor for video calls and record them.
    """
    # Set mode to "dual" for dual monitor; change to "single" for laptop-only.
    mode = "dual"
    recording_active = False
    audio_proc = None
    screenshot_thread = None
    screenshot_stop_event = None
    meeting_folder = None
    current_meeting_id = None
    current_app = None
    current_title = None

    print("Monitoring for video calls...")
    try:
        while True:
            is_call_active, app_name, window_title = is_target_call_active()
            
            if is_call_active:
                if not recording_active:
                    # Create a new meeting folder for this call.
                    meeting_folder = create_meeting_folder()
                    print(f"Video call detected in {app_name}: {window_title}. Starting recording...")
                    audio_proc, output_file = start_audio_recording(meeting_folder)
                    screenshot_stop_event = threading.Event()
                    screenshot_thread = threading.Thread(target=screenshot_loop, args=(mode, meeting_folder, screenshot_stop_event))
                    screenshot_thread.start()
                    recording_active = True
                    current_app = app_name
                    current_title = window_title
            else:
                if recording_active:
                    print("No active video call. Stopping recordings...")
                    if audio_proc:
                        audio_proc.terminate()
                        try:
                            audio_proc.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            audio_proc.kill()
                        audio_proc = None
                    if screenshot_stop_event:
                        screenshot_stop_event.set()
                    if screenshot_thread:
                        screenshot_thread.join()
                        screenshot_thread = None
                    
                    # Process the recording
                    transcript_file = transcribe(output_file)
                    
                    # Store in database and process with AI
                    current_meeting_id = process_meeting_transcript(transcript_file, current_app, current_title)
                    
                    # Store embedding in vector database
                    if current_meeting_id:
                        store_transcript_embedding(transcript_file, current_meeting_id)
                    
                    recording_active = False
                    current_app = None
                    current_title = None
            
            time.sleep(5)  # Poll every 5 seconds.
    except KeyboardInterrupt:
        print("Exiting...")
        if audio_proc:
            audio_proc.terminate()
        if screenshot_stop_event:
            screenshot_stop_event.set()
        if screenshot_thread:
            screenshot_thread.join()


if __name__ == "__main__":
    main()
