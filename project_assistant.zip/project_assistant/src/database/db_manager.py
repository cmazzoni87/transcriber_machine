"""
Database initialization and connection management for the Personal Project Assistant.
This module handles database setup, connection pooling, and session management.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.pool import QueuePool
from dotenv import load_dotenv
from contextlib import contextmanager

# Import models
from .models import Base

# Load environment variables
load_dotenv()

class DatabaseManager:
    """
    Database connection manager for SQL database operations.
    Handles connection pooling and session management.
    """
    
    def __init__(self, db_url=None):
        """
        Initialize the database manager.
        
        Args:
            db_url: Database connection URL (defaults to environment variable)
        """
        self.db_url = db_url or os.getenv("DATABASE_URL", "sqlite:///project_assistant.db")
        
        # Create engine with connection pooling
        self.engine = create_engine(
            self.db_url,
            poolclass=QueuePool,
            pool_size=5,
            max_overflow=10,
            pool_timeout=30,
            pool_recycle=1800
        )
        
        # Create session factory
        self.session_factory = sessionmaker(bind=self.engine)
        self.Session = scoped_session(self.session_factory)
    
    def init_db(self):
        """Initialize the database schema."""
        Base.metadata.create_all(self.engine)
    
    @contextmanager
    def session_scope(self):
        """
        Provide a transactional scope around a series of operations.
        
        Yields:
            SQLAlchemy session
        """
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    def close(self):
        """Close all connections in the connection pool."""
        self.Session.remove()
        self.engine.dispose()


# Create a default database manager instance
db_manager = DatabaseManager()

# Context manager for database sessions
@contextmanager
def get_db_session():
    """
    Context manager for database sessions.
    
    Yields:
        SQLAlchemy session
    """
    with db_manager.session_scope() as session:
        yield session
