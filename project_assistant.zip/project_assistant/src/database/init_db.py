"""
Database initialization script for the Personal Project Assistant.
This script creates the necessary database tables and initializes the vector database.
"""

import os
import sys
from dotenv import load_dotenv

# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import database components
from database.models import Base, init_db
from database.db_manager import DatabaseManager
from database.vector_db import VectorDatabase
from database.memory_manager import MemoryManager

def initialize_databases():
    """Initialize SQL and vector databases."""
    # Load environment variables
    load_dotenv()
    
    # Get database URL from environment or use default
    db_url = os.getenv("DATABASE_URL", "sqlite:///project_assistant.db")
    
    print("Initializing SQL database...")
    # Initialize SQL database
    db_manager = DatabaseManager(db_url)
    db_manager.init_db()
    print("SQL database initialized successfully.")
    
    print("Initializing vector database...")
    try:
        # Initialize vector database
        vector_db = VectorDatabase()
        print("Vector database initialized successfully.")
        
        # Initialize memory manager
        memory_manager = MemoryManager(vector_db)
        print("Memory manager initialized successfully.")
        
        return True
    except Exception as e:
        print(f"Error initializing vector database: {e}")
        return False

if __name__ == "__main__":
    success = initialize_databases()
    if success:
        print("All databases initialized successfully.")
    else:
        print("Database initialization failed.")
