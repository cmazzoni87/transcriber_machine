"""
Vector database implementation for the Personal Project Assistant application.
This module handles the creation and management of vector embeddings for semantic search.
Uses LanceDB with S3 storage instead of Pinecone.
"""

import os
import boto3
import lancedb
import pyarrow as pa
from typing import List, Dict, Any, Optional, Union
import numpy as np
from dotenv import load_dotenv
import uuid
import json

# Load environment variables
load_dotenv()

class VectorDatabase:
    """
    Vector database manager for storing and retrieving embeddings.
    Uses LanceDB with S3 storage as the vector database service.
    """
    
    def __init__(self, 
                s3_bucket: Optional[str] = None, 
                aws_region: Optional[str] = None,
                aws_access_key: Optional[str] = None,
                aws_secret_key: Optional[str] = None):
        """
        Initialize the vector database connection.
        
        Args:
            s3_bucket: S3 bucket name (defaults to environment variable)
            aws_region: AWS region (defaults to environment variable)
            aws_access_key: AWS access key (defaults to environment variable)
            aws_secret_key: AWS secret key (defaults to environment variable)
        """
        self.s3_bucket = s3_bucket or os.getenv("S3_BUCKET_NAME")
        self.aws_region = aws_region or os.getenv("AWS_REGION", "us-east-1")
        self.aws_access_key = aws_access_key or os.getenv("AWS_ACCESS_KEY_ID")
        self.aws_secret_key = aws_secret_key or os.getenv("AWS_SECRET_ACCESS_KEY")
        
        if not self.s3_bucket:
            raise ValueError("S3 bucket name must be provided")
        
        # Initialize S3 client
        self.s3_client = boto3.client(
            's3',
            region_name=self.aws_region,
            aws_access_key_id=self.aws_access_key,
            aws_secret_access_key=self.aws_secret_key
        )
        
        # Initialize LanceDB with S3 URI
        self.s3_uri = f"s3://{self.s3_bucket}/lancedb"
        self.db = lancedb.connect(self.s3_uri)
        
        # Collection names
        self.DOCUMENT_COLLECTION = "document_embeddings"
        self.TRANSCRIPT_COLLECTION = "transcript_embeddings"
        self.MESSAGE_COLLECTION = "message_embeddings"
        
        # Ensure collections exist
        self._ensure_collections_exist()
    
    def _ensure_collections_exist(self):
        """Ensure that all required collections exist in LanceDB."""
        existing_tables = self.db.table_names()
        
        for collection_name in [self.DOCUMENT_COLLECTION, self.TRANSCRIPT_COLLECTION, self.MESSAGE_COLLECTION]:
            if collection_name not in existing_tables:
                # Create the table with appropriate schema for the embedding model
                # Using 1536 dimensions for OpenAI embeddings or 768 for smaller models
                schema = pa.schema([
                    pa.field("id", pa.string()),
                    pa.field("vector", pa.list_(pa.float32(), 1536)),  # Adjust based on embedding model
                    pa.field("metadata", pa.string())  # Store metadata as JSON string
                ])
                
                # Create empty table with schema
                self.db.create_table(collection_name, schema=schema)
    
    def get_collection(self, collection_name: str):
        """
        Get a LanceDB table by name.
        
        Args:
            collection_name: Name of the collection/table
            
        Returns:
            LanceDB table object
        """
        return self.db.open_table(collection_name)
    
    def store_document_embedding(self, 
                                document_id: str, 
                                embedding: List[float], 
                                metadata: Dict[str, Any]):
        """
        Store a document embedding in the vector database.
        
        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding of the document
            metadata: Additional metadata about the document
        """
        table = self.get_collection(self.DOCUMENT_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Convert metadata to JSON string
        metadata_str = json.dumps(metadata)
        
        # Upsert the embedding
        data = [{"id": document_id, "vector": embedding, "metadata": metadata_str}]
        table.add(data=data, mode="overwrite", id_field="id")
    
    def store_transcript_embedding(self, 
                                  transcript_id: str, 
                                  embedding: List[float], 
                                  metadata: Dict[str, Any]):
        """
        Store a transcript embedding in the vector database.
        
        Args:
            transcript_id: Unique identifier for the transcript
            embedding: Vector embedding of the transcript
            metadata: Additional metadata about the transcript
        """
        table = self.get_collection(self.TRANSCRIPT_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Convert metadata to JSON string
        metadata_str = json.dumps(metadata)
        
        # Upsert the embedding
        data = [{"id": transcript_id, "vector": embedding, "metadata": metadata_str}]
        table.add(data=data, mode="overwrite", id_field="id")
    
    def store_message_embedding(self, 
                               message_id: str, 
                               embedding: List[float], 
                               metadata: Dict[str, Any]):
        """
        Store a message embedding in the vector database.
        
        Args:
            message_id: Unique identifier for the message
            embedding: Vector embedding of the message
            metadata: Additional metadata about the message
        """
        table = self.get_collection(self.MESSAGE_COLLECTION)
        
        # Ensure embedding is a list of floats
        embedding = [float(x) for x in embedding]
        
        # Convert metadata to JSON string
        metadata_str = json.dumps(metadata)
        
        # Upsert the embedding
        data = [{"id": message_id, "vector": embedding, "metadata": metadata_str}]
        table.add(data=data, mode="overwrite", id_field="id")
    
    def search_documents(self, 
                        query_embedding: List[float], 
                        top_k: int = 5, 
                        filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar documents using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching documents with scores and metadata
        """
        table = self.get_collection(self.DOCUMENT_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Build query
        query = table.search(query_embedding).limit(top_k)
        
        # Apply filter if provided
        if filter_dict:
            filter_conditions = []
            for key, value in filter_dict.items():
                # We need to search within the JSON metadata string
                filter_conditions.append(f"json_extract_scalar(metadata, '$.{key}') = '{value}'")
            
            if filter_conditions:
                filter_expr = " AND ".join(filter_conditions)
                query = query.where(filter_expr)
        
        # Execute query
        results = query.to_pandas()
        
        # Format results to match the expected output format
        matches = []
        for _, row in results.iterrows():
            # Parse metadata from JSON string
            metadata = json.loads(row['metadata'])
            
            matches.append({
                'id': row['id'],
                'score': float(row['_distance']),
                'metadata': metadata
            })
        
        return matches
    
    def search_transcripts(self, 
                          query_embedding: List[float], 
                          top_k: int = 5, 
                          filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar transcripts using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching transcripts with scores and metadata
        """
        table = self.get_collection(self.TRANSCRIPT_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Build query
        query = table.search(query_embedding).limit(top_k)
        
        # Apply filter if provided
        if filter_dict:
            filter_conditions = []
            for key, value in filter_dict.items():
                # We need to search within the JSON metadata string
                filter_conditions.append(f"json_extract_scalar(metadata, '$.{key}') = '{value}'")
            
            if filter_conditions:
                filter_expr = " AND ".join(filter_conditions)
                query = query.where(filter_expr)
        
        # Execute query
        results = query.to_pandas()
        
        # Format results to match the expected output format
        matches = []
        for _, row in results.iterrows():
            # Parse metadata from JSON string
            metadata = json.loads(row['metadata'])
            
            matches.append({
                'id': row['id'],
                'score': float(row['_distance']),
                'metadata': metadata
            })
        
        return matches
    
    def search_messages(self, 
                       query_embedding: List[float], 
                       top_k: int = 5, 
                       filter_dict: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar messages using a query embedding.
        
        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            filter_dict: Optional filter criteria
            
        Returns:
            List of matching messages with scores and metadata
        """
        table = self.get_collection(self.MESSAGE_COLLECTION)
        
        # Ensure embedding is a list of floats
        query_embedding = [float(x) for x in query_embedding]
        
        # Build query
        query = table.search(query_embedding).limit(top_k)
        
        # Apply filter if provided
        if filter_dict:
            filter_conditions = []
            for key, value in filter_dict.items():
                # We need to search within the JSON metadata string
                filter_conditions.append(f"json_extract_scalar(metadata, '$.{key}') = '{value}'")
            
            if filter_conditions:
                filter_expr = " AND ".join(filter_conditions)
                query = query.where(filter_expr)
        
        # Execute query
        results = query.to_pandas()
        
        # Format results to match the expected output format
        matches = []
        for _, row in results.iterrows():
            # Parse metadata from JSON string
            metadata = json.loads(row['metadata'])
            
            matches.append({
                'id': row['id'],
                'score': float(row['_distance']),
                'metadata': metadata
            })
        
        return matches
    
    def delete_document(self, document_id: str):
        """
        Delete a document embedding from the vector database.
        
        Args:
            document_id: Unique identifier for the document
        """
        table = self.get_collection(self.DOCUMENT_COLLECTION)
        table.delete(f"id = '{document_id}'")
    
    def delete_transcript(self, transcript_id: str):
        """
        Delete a transcript embedding from the vector database.
        
        Args:
            transcript_id: Unique identifier for the transcript
        """
        table = self.get_collection(self.TRANSCRIPT_COLLECTION)
        table.delete(f"id = '{transcript_id}'")
    
    def delete_message(self, message_id: str):
        """
        Delete a message embedding from the vector database.
        
        Args:
            message_id: Unique identifier for the message
        """
        table = self.get_collection(self.MESSAGE_COLLECTION)
        table.delete(f"id = '{message_id}'")
    
    def close(self):
        """Close the connection to the vector database."""
        # LanceDB doesn't require explicit connection closing
        pass
