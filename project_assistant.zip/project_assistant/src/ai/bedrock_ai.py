"""
Amazon Bedrock AI integration for the Personal Project Assistant.
This module handles interactions with Amazon Bedrock models for AI capabilities.
"""

import os
import json
import boto3
from typing import List, Dict, Any, Optional, Union
from dotenv import load_dotenv
import time

# Load environment variables
load_dotenv()

class BedrockAI:
    """
    Amazon Bedrock AI integration for intelligent processing.
    Handles model selection, prompt engineering, and response processing.
    Uses exclusively Anthropic Claude models as specified.
    """
    
    def __init__(self, 
                region_name: Optional[str] = None, 
                default_model_id: Optional[str] = None):
        """
        Initialize the Bedrock AI client.
        
        Args:
            region_name: AWS region name (defaults to environment variable)
            default_model_id: Default model ID to use (defaults to environment variable)
        """
        self.region_name = region_name or os.getenv("AWS_REGION", "us-east-1")
        self.default_model_id = default_model_id or os.getenv("BEDROCK_DEFAULT_MODEL", "anthropic.claude-3-sonnet-20240229-v1:0")
        
        # Initialize Bedrock client
        self.bedrock_runtime = boto3.client(
            service_name="bedrock-runtime",
            region_name=self.region_name
        )
        
        # Model configurations - Only using Anthropic Claude models as specified
        self.model_configs = {
            # Anthropic Claude models
            "anthropic.claude-3-sonnet-20240229-v1:0": {
                "provider": "anthropic",
                "max_tokens": 4096,
                "temperature": 0.7,
                "top_p": 0.9,
                "format": "claude"
            },
            "anthropic.claude-3-haiku-20240307-v1:0": {
                "provider": "anthropic",
                "max_tokens": 4096,
                "temperature": 0.7,
                "top_p": 0.9,
                "format": "claude"
            },
            "anthropic.claude-3-opus-20240229-v1:0": {
                "provider": "anthropic",
                "max_tokens": 4096,
                "temperature": 0.7,
                "top_p": 0.9,
                "format": "claude"
            },
            "anthropic.claude-instant-v1": {
                "provider": "anthropic",
                "max_tokens": 4096,
                "temperature": 0.7,
                "top_p": 0.9,
                "format": "claude"
            }
        }
        
        # Ensure default model is a Claude model
        if not self.default_model_id.startswith("anthropic.claude"):
            self.default_model_id = "anthropic.claude-3-sonnet-20240229-v1:0"
    
    def _format_prompt_for_model(self, 
                               system_prompt: str, 
                               user_prompt: str, 
                               context: Optional[str] = None, 
                               model_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Format the prompt according to the model's requirements.
        
        Args:
            system_prompt: System instructions
            user_prompt: User query or instruction
            context: Optional context information
            model_id: Model ID to use (defaults to default_model_id)
            
        Returns:
            Formatted prompt as a dictionary
        """
        model_id = model_id or self.default_model_id
        
        # Ensure we're using a Claude model
        if not model_id.startswith("anthropic.claude"):
            model_id = self.default_model_id
            
        model_config = self.model_configs.get(model_id, self.model_configs[self.default_model_id])
        
        # Include context if provided
        full_user_prompt = user_prompt
        if context:
            full_user_prompt = f"Context:\n{context}\n\nQuery: {user_prompt}"
        
        # Claude format
        return {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": model_config["max_tokens"],
            "temperature": model_config["temperature"],
            "top_p": model_config["top_p"],
            "messages": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": full_user_prompt
                }
            ]
        }
    
    def _parse_response(self, 
                      response: Dict[str, Any], 
                      model_id: str) -> str:
        """
        Parse the response from the model.
        
        Args:
            response: Raw response from the model
            model_id: Model ID used for the request
            
        Returns:
            Extracted text response
        """
        # Claude format
        response_body = json.loads(response.get("body").read())
        return response_body.get("content", [{}])[0].get("text", "")
    
    def generate_response(self, 
                         system_prompt: str, 
                         user_prompt: str, 
                         context: Optional[str] = None, 
                         model_id: Optional[str] = None) -> str:
        """
        Generate a response using the specified Claude model.
        
        Args:
            system_prompt: System instructions
            user_prompt: User query or instruction
            context: Optional context information
            model_id: Model ID to use (defaults to default_model_id)
            
        Returns:
            Generated response text
        """
        model_id = model_id or self.default_model_id
        
        # Ensure we're using a Claude model
        if not model_id.startswith("anthropic.claude"):
            model_id = self.default_model_id
        
        # Format prompt
        prompt = self._format_prompt_for_model(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            context=context,
            model_id=model_id
        )
        
        # Invoke model
        try:
            response = self.bedrock_runtime.invoke_model(
                modelId=model_id,
                body=json.dumps(prompt)
            )
            
            # Parse response
            return self._parse_response(response, model_id)
        except Exception as e:
            print(f"Error invoking Bedrock model: {e}")
            return f"Error generating response: {str(e)}"
    
    def generate_embeddings(self, 
                          text: str, 
                          model_id: Optional[str] = None) -> List[float]:
        """
        Generate embeddings for the given text.
        
        Args:
            text: Text to generate embeddings for
            model_id: Model ID to use (defaults to Amazon Titan Embeddings)
            
        Returns:
            Vector embedding as a list of floats
        """
        # Use Amazon Titan Embeddings for embedding generation
        # This is acceptable as it's just for vector embeddings, not LLM responses
        embedding_model_id = "amazon.titan-embed-text-v1"
        
        try:
            # Format request
            request_body = {
                "inputText": text
            }
            
            # Invoke embedding model
            response = self.bedrock_runtime.invoke_model(
                modelId=embedding_model_id,
                body=json.dumps(request_body)
            )
            
            # Parse response
            response_body = json.loads(response.get("body").read())
            embedding = response_body.get("embedding", [])
            
            return embedding
        except Exception as e:
            print(f"Error generating embeddings: {e}")
            return []
    
    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """
        Analyze sentiment of the given text using Claude.
        
        Args:
            text: Text to analyze
            
        Returns:
            Sentiment analysis results
        """
        system_prompt = """
        You are a sentiment analysis expert. Analyze the sentiment of the provided text and return a JSON object with the following fields:
        - sentiment: overall sentiment (positive, negative, or neutral)
        - confidence: confidence score (0-1)
        - emotions: list of detected emotions with their confidence scores
        - key_phrases: list of key phrases that influenced the sentiment
        """
        
        user_prompt = f"Analyze the sentiment of the following text: {text}"
        
        response = self.generate_response(
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
        
        try:
            # Extract JSON from response
            import re
            json_match = re.search(r'```json\n(.*?)\n```', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response
            
            # Clean up the string
            json_str = json_str.strip()
            if json_str.startswith('```') and json_str.endswith('```'):
                json_str = json_str[3:-3].strip()
            
            # Parse JSON
            sentiment_data = json.loads(json_str)
            return sentiment_data
        except Exception as e:
            print(f"Error parsing sentiment analysis response: {e}")
            return {
                "sentiment": "neutral",
                "confidence": 0.5,
                "emotions": [],
                "key_phrases": [],
                "error": str(e)
            }
    
    def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract entities from the given text using Claude.
        
        Args:
            text: Text to extract entities from
            
        Returns:
            List of extracted entities with their types and metadata
        """
        system_prompt = """
        You are an entity extraction expert. Extract entities from the provided text and return a JSON array of objects with the following fields:
        - entity: the entity text
        - type: entity type (person, organization, location, date, etc.)
        - metadata: any additional information about the entity
        """
        
        user_prompt = f"Extract entities from the following text: {text}"
        
        response = self.generate_response(
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
        
        try:
            # Extract JSON from response
            import re
            json_match = re.search(r'```json\n(.*?)\n```', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response
            
            # Clean up the string
            json_str = json_str.strip()
            if json_str.startswith('```') and json_str.endswith('```'):
                json_str = json_str[3:-3].strip()
            
            # Parse JSON
            entities = json.loads(json_str)
            return entities
        except Exception as e:
            print(f"Error parsing entity extraction response: {e}")
            return []
    
    def summarize_text(self, text: str, max_length: int = 500) -> str:
        """
        Summarize the given text using Claude.
        
        Args:
            text: Text to summarize
            max_length: Maximum length of the summary in characters
            
        Returns:
            Summarized text
        """
        system_prompt = f"""
        You are a summarization expert. Summarize the provided text concisely while preserving the key information.
        Your summary should be no longer than {max_length} characters.
        """
        
        user_prompt = f"Summarize the following text: {text}"
        
        return self.generate_response(
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
    
    def extract_action_items(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract action items from the given text using Claude.
        
        Args:
            text: Text to extract action items from
            
        Returns:
            List of action items with assignees and deadlines
        """
        system_prompt = """
        You are an action item extraction expert. Extract all action items, tasks, and to-dos from the provided text.
        Return a JSON array of objects with the following fields:
        - task: the action item description
        - assignee: the person assigned to the task (if specified)
        - deadline: the deadline for the task (if specified)
        - priority: the priority level (if specified, otherwise "medium")
        """
        
        user_prompt = f"Extract action items from the following text: {text}"
        
        response = self.generate_response(
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
        
        try:
            # Extract JSON from response
            import re
            json_match = re.search(r'```json\n(.*?)\n```', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response
            
            # Clean up the string
            json_str = json_str.strip()
            if json_str.startswith('```') and json_str.endswith('```'):
                json_str = json_str[3:-3].strip()
            
            # Parse JSON
            action_items = json.loads(json_str)
            return action_items
        except Exception as e:
            print(f"Error parsing action items response: {e}")
            return []
