"""
AI Assistant module for the Personal Project Assistant.
This module integrates all AI components to provide a unified interface for AI capabilities.
"""

import os
from typing import List, Dict, Any, Optional, Union
from dotenv import load_dotenv

# Import AI components
from .bedrock_ai import BedrockAI
from .prompt_manager import PromptManager
from .context_retriever import ContextRetriever

# Load environment variables
load_dotenv()

class AIAssistant:
    """
    AI Assistant that integrates all AI components for the Personal Project Assistant.
    Provides a unified interface for AI capabilities.
    """
    
    def __init__(self, 
                bedrock_ai: Optional[BedrockAI] = None,
                prompt_manager: Optional[PromptManager] = None,
                context_retriever: Optional[ContextRetriever] = None):
        """
        Initialize the AI Assistant.
        
        Args:
            bedrock_ai: Bedrock AI instance (creates new one if not provided)
            prompt_manager: Prompt manager instance (creates new one if not provided)
            context_retriever: Context retriever instance (creates new one if not provided)
        """
        self.bedrock_ai = bedrock_ai or BedrockAI()
        self.prompt_manager = prompt_manager or PromptManager()
        self.context_retriever = context_retriever or ContextRetriever(bedrock_ai=self.bedrock_ai)
    
    def answer_question(self, 
                       query: str, 
                       project_id: Optional[str] = None,
                       use_context: bool = True) -> str:
        """
        Answer a user question using AI and context retrieval.
        
        Args:
            query: User question
            project_id: Optional project ID to filter context
            use_context: Whether to use context retrieval
            
        Returns:
            AI-generated answer
        """
        # Retrieve context if needed
        context_items = []
        if use_context:
            context_items = self.context_retriever.retrieve_context_for_query(
                query=query,
                project_id=project_id
            )
        
        # Create prompt
        prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="general_assistant",
            user_prompt_template="general_query",
            context_items=context_items,
            query=query
        )
        
        # Generate response
        response = self.bedrock_ai.generate_response(
            system_prompt=prompt["system_prompt"],
            user_prompt=prompt["user_prompt"]
        )
        
        return response
    
    def summarize_meeting(self, transcript: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Summarize a meeting transcript.
        
        Args:
            transcript: Meeting transcript
            project_id: Optional project ID for context
            
        Returns:
            Dictionary with summary, action items, and decisions
        """
        # Retrieve project context if project_id is provided
        context_items = []
        if project_id:
            context_items = self.context_retriever.retrieve_project_context(project_id)
        
        # Create prompt
        prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="meeting_assistant",
            user_prompt_template="meeting_summary",
            context_items=context_items,
            transcript=transcript
        )
        
        # Generate summary
        summary_text = self.bedrock_ai.generate_response(
            system_prompt=prompt["system_prompt"],
            user_prompt=prompt["user_prompt"]
        )
        
        # Extract action items
        action_items_prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="meeting_assistant",
            user_prompt_template="general_query",
            context_items=[],
            query=f"Extract all action items from this meeting transcript as a JSON array of objects with 'task', 'assignee', and 'deadline' fields:\n\n{transcript}"
        )
        
        action_items_response = self.bedrock_ai.generate_response(
            system_prompt=action_items_prompt["system_prompt"],
            user_prompt=action_items_prompt["user_prompt"]
        )
        
        # Extract decisions
        decisions_prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="meeting_assistant",
            user_prompt_template="general_query",
            context_items=[],
            query=f"Extract all decisions made in this meeting transcript as a JSON array of strings:\n\n{transcript}"
        )
        
        decisions_response = self.bedrock_ai.generate_response(
            system_prompt=decisions_prompt["system_prompt"],
            user_prompt=decisions_prompt["user_prompt"]
        )
        
        # Parse JSON responses (would need more robust parsing in production)
        try:
            import json
            import re
            
            # Extract JSON from action items response
            action_items_match = re.search(r'\[.*\]', action_items_response, re.DOTALL)
            action_items = json.loads(action_items_match.group(0)) if action_items_match else []
            
            # Extract JSON from decisions response
            decisions_match = re.search(r'\[.*\]', decisions_response, re.DOTALL)
            decisions = json.loads(decisions_match.group(0)) if decisions_match else []
        except Exception as e:
            print(f"Error parsing JSON responses: {e}")
            action_items = []
            decisions = []
        
        return {
            "summary": summary_text,
            "action_items": action_items,
            "decisions": decisions
        }
    
    def analyze_document(self, document_content: str, query: Optional[str] = None) -> str:
        """
        Analyze a document and answer a query about it.
        
        Args:
            document_content: Document content
            query: Optional query about the document
            
        Returns:
            Analysis or answer to the query
        """
        # Default query if none provided
        if not query:
            query = "Summarize this document and extract the key points."
        
        # Create prompt
        prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="document_analyzer",
            user_prompt_template="document_query",
            context_items=[],
            document_content=document_content,
            query=query
        )
        
        # Generate response
        response = self.bedrock_ai.generate_response(
            system_prompt=prompt["system_prompt"],
            user_prompt=prompt["user_prompt"]
        )
        
        return response
    
    def analyze_slack_conversation(self, conversation: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a Slack conversation.
        
        Args:
            conversation: Slack conversation text
            project_id: Optional project ID for context
            
        Returns:
            Dictionary with analysis, action items, and project matching
        """
        # Retrieve project context if project_id is provided
        context_items = []
        if project_id:
            context_items = self.context_retriever.retrieve_project_context(project_id)
        
        # Create prompt
        prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="slack_analyzer",
            user_prompt_template="slack_analysis",
            context_items=context_items,
            conversation=conversation
        )
        
        # Generate analysis
        analysis = self.bedrock_ai.generate_response(
            system_prompt=prompt["system_prompt"],
            user_prompt=prompt["user_prompt"]
        )
        
        # Extract action items
        action_items_prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="slack_analyzer",
            user_prompt_template="general_query",
            context_items=[],
            query=f"Extract all action items from this Slack conversation as a JSON array of objects with 'task', 'assignee', and 'deadline' fields:\n\n{conversation}"
        )
        
        action_items_response = self.bedrock_ai.generate_response(
            system_prompt=action_items_prompt["system_prompt"],
            user_prompt=action_items_prompt["user_prompt"]
        )
        
        # Determine project relevance if project_id not provided
        project_match = None
        if not project_id:
            # This would typically query multiple projects and use embeddings to find matches
            # For now, we'll just use a simple prompt
            project_match_prompt = self.prompt_manager.create_prompt_with_context(
                system_prompt_type="slack_analyzer",
                user_prompt_template="general_query",
                context_items=[],
                query=f"Based on this conversation, what project topics does it relate to? List the top 3 possible project areas as a JSON array of strings:\n\n{conversation}"
            )
            
            project_match_response = self.bedrock_ai.generate_response(
                system_prompt=project_match_prompt["system_prompt"],
                user_prompt=project_match_prompt["user_prompt"]
            )
            
            # Extract JSON (would need more robust parsing in production)
            try:
                import json
                import re
                
                # Extract JSON from project match response
                match = re.search(r'\[.*\]', project_match_response, re.DOTALL)
                project_match = json.loads(match.group(0)) if match else []
                
                # Extract JSON from action items response
                action_items_match = re.search(r'\[.*\]', action_items_response, re.DOTALL)
                action_items = json.loads(action_items_match.group(0)) if action_items_match else []
            except Exception as e:
                print(f"Error parsing JSON responses: {e}")
                project_match = []
                action_items = []
        else:
            # Parse action items JSON
            try:
                import json
                import re
                
                # Extract JSON from action items response
                action_items_match = re.search(r'\[.*\]', action_items_response, re.DOTALL)
                action_items = json.loads(action_items_match.group(0)) if action_items_match else []
            except Exception as e:
                print(f"Error parsing action items JSON: {e}")
                action_items = []
        
        return {
            "analysis": analysis,
            "action_items": action_items,
            "project_match": project_match
        }
    
    def create_task(self, 
                  project: str, 
                  description: str, 
                  deadline: Optional[str] = None, 
                  assignee: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a task with AI assistance.
        
        Args:
            project: Project name
            description: Task description
            deadline: Optional deadline
            assignee: Optional assignee
            
        Returns:
            Dictionary with formatted task details
        """
        # Create prompt
        prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="task_manager",
            user_prompt_template="task_creation",
            context_items=[],
            project=project,
            description=description,
            deadline=deadline or "Not specified",
            assignee=assignee or "Unassigned"
        )
        
        # Generate task
        task_response = self.bedrock_ai.generate_response(
            system_prompt=prompt["system_prompt"],
            user_prompt=prompt["user_prompt"]
        )
        
        # Extract structured task data
        task_data_prompt = self.prompt_manager.create_prompt_with_context(
            system_prompt_type="task_manager",
            user_prompt_template="general_query",
            context_items=[],
            query=f"Convert this task description into a JSON object with 'title', 'description', 'due_date', and 'assignee' fields:\n\n{task_response}"
        )
        
        task_data_response = self.bedrock_ai.generate_response(
            system_prompt=task_data_prompt["system_prompt"],
            user_prompt=task_data_prompt["user_prompt"]
        )
        
        # Parse JSON (would need more robust parsing in production)
        try:
            import json
            import re
            
            # Extract JSON from task data response
            match = re.search(r'\{.*\}', task_data_response, re.DOTALL)
            task_data = json.loads(match.group(0)) if match else {}
        except Exception as e:
            print(f"Error parsing task data JSON: {e}")
            task_data = {
                "title": description[:50] + ("..." if len(description) > 50 else ""),
                "description": description,
                "due_date": deadline,
                "assignee": assignee
            }
        
        return {
            "formatted_task": task_response,
            "task_data": task_data
        }
    
    def generate_embeddings(self, text: str) -> List[float]:
        """
        Generate embeddings for the given text.
        
        Args:
            text: Text to generate embeddings for
            
        Returns:
            Vector embedding as a list of floats
        """
        return self.bedrock_ai.generate_embeddings(text)
    
    def close(self):
        """Close connections and clean up resources."""
        if self.context_retriever:
            self.context_retriever.close()
