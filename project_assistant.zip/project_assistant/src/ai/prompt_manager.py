"""
Prompt engineering module for the Personal Project Assistant.
This module handles the creation and management of prompts for different use cases.
"""

import os
from typing import List, Dict, Any, Optional, Union
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class PromptManager:
    """
    Prompt manager for creating and managing prompts for different use cases.
    Implements templates and context management for effective AI interactions.
    """
    
    def __init__(self):
        """Initialize the prompt manager."""
        # System prompts for different use cases
        self.system_prompts = {
            "general_assistant": """
            You are a personal project assistant that helps manage projects, meetings, documents, and tasks.
            Your goal is to provide helpful, accurate, and concise responses to user queries.
            Use the provided context to inform your responses, but don't mention the context explicitly.
            If you don't know the answer, say so rather than making up information.
            """,
            
            "meeting_assistant": """
            You are a meeting assistant that helps analyze and summarize meeting transcripts.
            Your goal is to extract key information, action items, decisions, and follow-ups from meeting transcripts.
            Provide concise summaries that capture the essential points while omitting unnecessary details.
            Focus on identifying tasks, responsibilities, deadlines, and important discussions.
            """,
            
            "document_analyzer": """
            You are a document analysis assistant that helps extract insights from documents.
            Your goal is to understand document content, answer questions about documents, and provide summaries.
            Focus on extracting key information, identifying main themes, and connecting documents to projects.
            Provide accurate information based on document content without adding unsupported details.
            """,
            
            "slack_analyzer": """
            You are a Slack conversation analyzer that helps extract insights from chat messages.
            Your goal is to identify important discussions, decisions, and action items from Slack conversations.
            Focus on connecting conversations to projects, extracting tasks, and identifying key information.
            Provide concise summaries that capture the essential points of conversations.
            """,
            
            "task_manager": """
            You are a task management assistant that helps create, update, and track tasks.
            Your goal is to help users manage their tasks effectively, set priorities, and track progress.
            Focus on creating clear, actionable tasks with appropriate deadlines and assignments.
            Help users organize tasks by project and provide updates on task status.
            """,
            
            "project_planner": """
            You are a project planning assistant that helps create and manage project plans.
            Your goal is to help users define project scope, milestones, tasks, and timelines.
            Focus on creating realistic plans, identifying dependencies, and tracking progress.
            Help users adjust plans as needed and provide insights on project status.
            """
        }
        
        # User prompt templates for different use cases
        self.user_prompt_templates = {
            "general_query": """
            {query}
            """,
            
            "meeting_summary": """
            Please summarize the following meeting transcript:
            
            {transcript}
            
            Focus on:
            1. Key discussion points
            2. Decisions made
            3. Action items and who's responsible
            4. Deadlines mentioned
            5. Follow-up items
            """,
            
            "document_query": """
            I have the following document:
            
            {document_content}
            
            {query}
            """,
            
            "slack_analysis": """
            Please analyze the following Slack conversation:
            
            {conversation}
            
            Focus on:
            1. Key discussion points
            2. Decisions made
            3. Action items and who's responsible
            4. Questions that need answers
            5. Important information shared
            """,
            
            "task_creation": """
            Please help me create a task based on the following information:
            
            Project: {project}
            Description: {description}
            Deadline: {deadline}
            Assigned to: {assignee}
            
            Format the task in a clear, actionable way suitable for Asana.
            """,
            
            "project_planning": """
            Please help me create a project plan for:
            
            Project name: {project_name}
            Project description: {description}
            Timeline: {timeline}
            Team members: {team_members}
            
            Include key milestones, main tasks, and suggested timeline.
            """
        }
    
    def get_system_prompt(self, prompt_type: str) -> str:
        """
        Get a system prompt by type.
        
        Args:
            prompt_type: Type of system prompt to retrieve
            
        Returns:
            System prompt text
        """
        return self.system_prompts.get(
            prompt_type, 
            self.system_prompts["general_assistant"]
        ).strip()
    
    def format_user_prompt(self, 
                         template_name: str, 
                         **kwargs) -> str:
        """
        Format a user prompt template with the provided parameters.
        
        Args:
            template_name: Name of the template to use
            **kwargs: Parameters to fill in the template
            
        Returns:
            Formatted user prompt
        """
        template = self.user_prompt_templates.get(
            template_name, 
            self.user_prompt_templates["general_query"]
        )
        
        try:
            return template.format(**kwargs).strip()
        except KeyError as e:
            # If a required parameter is missing, return error message
            return f"Error formatting prompt: missing parameter {e}"
    
    def create_context_string(self, 
                            context_items: List[Dict[str, Any]], 
                            max_length: int = 8000) -> str:
        """
        Create a context string from a list of context items.
        
        Args:
            context_items: List of context items (documents, transcripts, messages)
            max_length: Maximum length of the context string
            
        Returns:
            Formatted context string
        """
        context_parts = []
        current_length = 0
        
        for item in context_items:
            item_type = item.get("type", "unknown")
            content = item.get("content", "")
            metadata = item.get("metadata", {})
            
            # Format based on item type
            if item_type == "document":
                formatted_item = f"DOCUMENT: {metadata.get('title', 'Untitled')}\n{content}\n\n"
            elif item_type == "transcript":
                formatted_item = f"MEETING TRANSCRIPT: {metadata.get('title', 'Untitled Meeting')}\n{content}\n\n"
            elif item_type == "message":
                formatted_item = f"MESSAGE: From {metadata.get('sender', 'Unknown')} in {metadata.get('channel', 'Unknown')}\n{content}\n\n"
            else:
                formatted_item = f"{content}\n\n"
            
            # Check if adding this item would exceed max length
            if current_length + len(formatted_item) > max_length:
                # If we already have some context, stop adding more
                if context_parts:
                    break
                
                # If this is the first item and it's too long, truncate it
                formatted_item = formatted_item[:max_length - 100] + "...\n\n"
            
            context_parts.append(formatted_item)
            current_length += len(formatted_item)
        
        return "".join(context_parts).strip()
    
    def create_prompt_with_context(self, 
                                 system_prompt_type: str, 
                                 user_prompt_template: str, 
                                 context_items: List[Dict[str, Any]], 
                                 **kwargs) -> Dict[str, str]:
        """
        Create a complete prompt with system message, user message, and context.
        
        Args:
            system_prompt_type: Type of system prompt to use
            user_prompt_template: Template for user prompt
            context_items: List of context items for retrieval augmentation
            **kwargs: Parameters for user prompt template
            
        Returns:
            Dictionary with system_prompt and user_prompt
        """
        # Get system prompt
        system_prompt = self.get_system_prompt(system_prompt_type)
        
        # Create context string
        context_string = self.create_context_string(context_items)
        
        # Format user prompt
        user_prompt = self.format_user_prompt(user_prompt_template, **kwargs)
        
        # Combine with context if available
        if context_string:
            user_prompt = f"Context information:\n{context_string}\n\n{user_prompt}"
        
        return {
            "system_prompt": system_prompt,
            "user_prompt": user_prompt
        }
