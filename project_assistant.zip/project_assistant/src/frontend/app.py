"""
Main Streamlit application for the Personal Project Assistant.
This module provides the frontend interface for the application.
"""

import os
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import json
import sys
from pathlib import Path

# Add the parent directory to the path to import from src
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import database components
from src.database.db_manager import get_db_session
from src.database.models import Project, Meeting, Document, Task, User

# Import AI components
from src.ai.ai_assistant import AIAssistant

# Import integration components
from src.integrations.manual_ingestion.manual_ingestion_service import ManualIngestionService
from src.integrations.manual_ingestion.action_item_manager import ActionItemManager

# Import frontend components
from src.frontend.action_items_page import action_items_page

# Set page configuration
st.set_page_config(
    page_title="Personal Project Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "current_user" not in st.session_state:
    st.session_state.current_user = None
if "ai_assistant" not in st.session_state:
    st.session_state.ai_assistant = None
if "manual_ingestion_service" not in st.session_state:
    st.session_state.manual_ingestion_service = None
if "action_item_manager" not in st.session_state:
    st.session_state.action_item_manager = None
if "current_project" not in st.session_state:
    st.session_state.current_project = None

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .section-header {
        font-size: 1.8rem;
        font-weight: bold;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .card {
        padding: 1.5rem;
        border-radius: 0.5rem;
        background-color: #f8f9fa;
        margin-bottom: 1rem;
    }
    .highlight {
        background-color: #e9f5ff;
        padding: 0.5rem;
        border-radius: 0.3rem;
    }
    .sidebar-header {
        font-size: 1.2rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

def login_page():
    """Display the login page."""
    st.markdown('<div class="main-header">Personal Project Assistant</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown('<div class="section-header">Login</div>', unsafe_allow_html=True)
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            # In a real application, this would validate against a database
            # For now, we'll use a simple check
            if username and password:
                st.session_state.authenticated = True
                st.session_state.current_user = {
                    "id": "1",
                    "username": username,
                    "name": username.capitalize()
                }
                
                # Initialize services
                try:
                    st.session_state.ai_assistant = AIAssistant()
                    st.success("AI Assistant initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing AI Assistant: {e}")
                
                try:
                    # Initialize manual ingestion service
                    st.session_state.manual_ingestion_service = ManualIngestionService()
                    st.success("Manual ingestion service initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing manual ingestion service: {e}")
                
                try:
                    # Initialize action item manager
                    st.session_state.action_item_manager = ActionItemManager()
                    st.success("Action item manager initialized successfully")
                except Exception as e:
                    st.error(f"Error initializing action item manager: {e}")
                
                st.rerun()
            else:
                st.error("Please enter both username and password")
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="section-header">Welcome to Personal Project Assistant</div>', unsafe_allow_html=True)
        st.markdown("""
        Your intelligent assistant for managing projects, meetings, and tasks.
        
        Features:
        - 📊 Project tracking and management
        - 🎤 Meeting recording and transcription
        - 📝 Manual text ingestion
        - ✅ Action item management
        - 🤖 AI-powered assistance
        
        Login to get started!
        """)
        st.markdown('</div>', unsafe_allow_html=True)

def sidebar():
    """Display the sidebar navigation."""
    st.sidebar.markdown('<div class="sidebar-header">Personal Project Assistant</div>', unsafe_allow_html=True)
    st.sidebar.markdown(f"Welcome, {st.session_state.current_user['name']}!")
    
    # Navigation
    page = st.sidebar.radio(
        "Navigation",
        ["Dashboard", "Projects", "Meetings", "Documents", "Action Items", "Text Ingestion", "AI Assistant"]
    )
    
    # Project selector (if not on Dashboard)
    if page != "Dashboard":
        st.sidebar.markdown("---")
        st.sidebar.markdown('<div class="sidebar-header">Select Project</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch projects from the database
        # For now, we'll use placeholder data
        projects = [
            {"id": "1", "name": "Project Alpha"},
            {"id": "2", "name": "Project Beta"},
            {"id": "3", "name": "Project Gamma"}
        ]
        
        project_names = [p["name"] for p in projects]
        selected_project = st.sidebar.selectbox("Project", project_names)
        
        # Update current project in session state
        for project in projects:
            if project["name"] == selected_project:
                st.session_state.current_project = project
    
    # Logout button
    st.sidebar.markdown("---")
    if st.sidebar.button("Logout"):
        st.session_state.authenticated = False
        st.session_state.current_user = None
        st.session_state.ai_assistant = None
        st.session_state.manual_ingestion_service = None
        st.session_state.action_item_manager = None
        st.session_state.current_project = None
        st.rerun()
    
    return page

def dashboard_page():
    """Display the dashboard page."""
    st.markdown('<div class="main-header">Dashboard</div>', unsafe_allow_html=True)
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Active Projects", value="3")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Recent Meetings", value="5")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col3:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Open Tasks", value="12")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col4:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.metric(label="Documents", value="24")
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Recent activity
    st.markdown('<div class="section-header">Recent Activity</div>', unsafe_allow_html=True)
    
    # In a real application, we would fetch recent activity from the database
    # For now, we'll use placeholder data
    activities = [
        {"timestamp": "2025-03-17 15:30", "type": "Meeting", "description": "Team Standup", "project": "Project Alpha"},
        {"timestamp": "2025-03-17 14:15", "type": "Task", "description": "Update documentation", "project": "Project Beta"},
        {"timestamp": "2025-03-17 11:45", "type": "Chat", "description": "Discussion about API design", "project": "Project Alpha"},
        {"timestamp": "2025-03-17 10:30", "type": "Document", "description": "Requirements specification uploaded", "project": "Project Gamma"},
        {"timestamp": "2025-03-16 16:20", "type": "Meeting", "description": "Client presentation", "project": "Project Beta"}
    ]
    
    activity_df = pd.DataFrame(activities)
    st.dataframe(activity_df, use_container_width=True)
    
    # Project status
    st.markdown('<div class="section-header">Project Status</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-header">Task Completion</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch task data from the database
        # For now, we'll use placeholder data
        task_data = {
            "Project Alpha": {"completed": 8, "total": 15},
            "Project Beta": {"completed": 12, "total": 20},
            "Project Gamma": {"completed": 5, "total": 10}
        }
        
        for project, data in task_data.items():
            completion_rate = data["completed"] / data["total"]
            st.write(f"{project}: {data['completed']}/{data['total']} tasks completed")
            st.progress(completion_rate)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-header">Upcoming Deadlines</div>', unsafe_allow_html=True)
        
        # In a real application, we would fetch deadline data from the database
        # For now, we'll use placeholder data
        deadlines = [
            {"project": "Project Alpha", "task": "Finalize design", "deadline": "2025-03-20"},
            {"project": "Project Beta", "task": "Client presentation", "deadline": "2025-03-22"},
            {"project": "Project Gamma", "task": "Code review", "deadline": "2025-03-25"}
        ]
        
        for deadline in deadlines:
            st.write(f"**{deadline['project']}**: {deadline['task']} (Due: {deadline['deadline']})")
        
        st.markdown('</div>', unsafe_allow_html=True)

def projects_page():
    """Display the projects page."""
    st.markdown('<div class="main-header">Projects</div>', unsafe_allow_html=True)
    
    # Project details
    if st.session_state.current_project:
        st.markdown(f'<div class="section-header">{st.session_state.current_project["name"]}</div>', unsafe_allow_html=True)
        
        # Project tabs
        tab1, tab2, tab3 = st.tabs(["Overview", "Activity", "Resources"])
        
        with tab1:
            # Project overview
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.markdown('<div class="sidebar-header">Project Details</div>', unsafe_allow_html=True)
                
                # In a real application, we would fetch project details from the database
                # For now, we'll use placeholder data
                st.write(f"**ID:** {st.session_state.current_project['id']}")
                st.write(f"**Name:** {st.session_state.current_project['name']}")
                st.write(f"**Status:** Active")
                st.write(f"**Start Date:** 2025-01-15")
                st.write(f"**Target Completion:** 2025-06-30")
                
                st.markdown('</div>', unsafe_allow_html=True)
            
            with col2:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.markdown('<div class="sidebar-header">Project Stats</div>', unsafe_allow_html=True)
                
                # In a real application, we would fetch project stats from the database
                # For now, we'll use placeholder data
                col1, col2 = st.columns(2)
                col1.metric(label="Tasks", value="15")
                col2.metric(label="Completed", value="8")
                
                col1, col2 = st.columns(2)
                col1.metric(label="Meetings", value="12")
                col2.metric(label="Documents", value="8")
                
                st.markdown('</div>', unsafe_allow_html=True)
        
        with tab2:
            # Project activity
            st.markdown('<div class="sidebar-header">Recent Activity</div>', unsafe_allow_html=True)
            
            # In a real application, we would fetch project activity from the database
            # For now, we'll use placeholder data
            activities = [
                {"timestamp": "2025-03-17 15:30", "type": "Meeting", "description": "Team Standup"},
                {"timestamp": "2025-03-16 14:15", "type": "Task", "description": "Update documentation"},
                {"timestamp": "2025-03-15 11:45", "type": "Chat", "description": "Discussion about API design"},
                {"timestamp": "2025-03-14 10:30", "type": "Document", "description": "Requirements specification uploaded"},
                {"timestamp": "2025-03-13 16:20", "type": "Meeting", "description": "Client presentation"}
            ]
            
            activity_df = pd.DataFrame(activities)
            st.dataframe(activity_df, use_container_width=True)
        
        with tab3:
            # Project resources
            st.markdown('<div class="sidebar-header">Project Resources</div>', unsafe_allow_html=True)
            
            # In a real application, we would fetch project resources from the database
            # For now, we'll use placeholder data
            resources = [
                {"name": "Project Plan", "type": "Document", "created": "2025-01-15"},
                {"name": "Requirements Specification", "type": "Document", "created": "2025-01-20"},
                {"name": "Design Document", "type": "Document", "created": "2025-02-05"},
                {"name": "API Documentation", "type": "Document", "created": "2025-02-15"},
                {"name": "Test Plan", "type": "Document", "created": "2025-03-01"}
            ]
            
            resources_df = pd.DataFrame(resources)
            st.dataframe(resources_df, use_container_width=True)
    else:
        st.info("Please select a project from the sidebar.")

def meetings_page():
    """Display the meetings page."""
    st.markdown('<div class="main-header">Meetings</div>', unsafe_allow_html=True)
    
    # Tabs for different meeting functions
    tab1, tab2, tab3 = st.tabs(["Recent Meetings", "Record Meeting", "Upload Transcript"])
    
    with tab1:
        # Recent meetings
        st.markdown('<div class="section-header">Recent Meetings</div>', unsafe_allow_html=True)
        
        # Filter by project if one is selected
        if st.session_state.current_project:
            st.info(f"Showing meetings for {st.session_state.current_project['name']}")
        
        # In a real application, we would fetch meetings from the database
        # For now, we'll use placeholder data
        meetings = [
            {"date": "2025-03-17", "title": "Team Standup", "duration": "30 min", "participants": "5", "project": "Project Alpha"},
            {"date": "2025-03-16", "title": "Client Presentation", "duration": "60 min", "participants": "8", "project": "Project Beta"},
            {"date": "2025-03-15", "title": "Sprint Planning", "duration": "90 min", "participants": "6", "project": "Project Alpha"},
            {"date": "2025-03-14", "title": "Design Review", "duration": "45 min", "participants": "4", "project": "Project Gamma"},
            {"date": "2025-03-13", "title": "Stakeholder Update", "duration": "60 min", "participants": "10", "project": "Project Beta"}
        ]
        
        # Filter by project if one is selected
        if st.session_state.current_project:
            meetings = [m for m in meetings if m["project"] == st.session_state.current_project["name"]]
        
        if not meetings:
            st.info("No meetings found for the selected project.")
        else:
            for meeting in meetings:
                with st.expander(f"{meeting['date']} - {meeting['title']} ({meeting['project']})"):
                    col1, col2, col3 = st.columns(3)
                    col1.write(f"**Duration:** {meeting['duration']}")
                    col2.write(f"**Participants:** {meeting['participants']}")
                    col3.write(f"**Project:** {meeting['project']}")
                    
                    st.markdown("### Summary")
                    st.write("This is a placeholder for the meeting summary.")
                    
                    st.markdown("### Action Items")
                    st.write("- Action item 1")
                    st.write("- Action item 2")
                    st.write("- Action item 3")
                    
                    st.button("View Full Transcript", key=f"transcript_{meeting['date']}_{meeting['title']}")
    
    with tab2:
        # Record meeting
        st.markdown('<div class="section-header">Record Meeting</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Use this feature to record a meeting and automatically transcribe it.
        The AI will analyze the transcript to extract action items and key points.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            meeting_title = st.text_input("Meeting Title")
            
            # Project selection (use current project if available)
            if st.session_state.current_project:
                project_for_meeting = st.session_state.current_project["name"]
                st.info(f"Recording for project: {project_for_meeting}")
            else:
                projects = ["Project Alpha", "Project Beta", "Project Gamma"]
                project_for_meeting = st.selectbox("Project", projects)
        
        with col2:
            participants = st.text_input("Participants (comma-separated)")
            meeting_type = st.selectbox("Meeting Type", ["Standup", "Planning", "Review", "Client", "Other"])
        
        if st.button("Start Recording"):
            st.error("Recording functionality is not implemented in this demo.")
            st.info("In a real implementation, this would start recording the meeting.")
    
    with tab3:
        # Upload transcript
        st.markdown('<div class="section-header">Upload Transcript</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Upload a meeting transcript for analysis.
        The AI will extract action items, key points, and generate a summary.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            meeting_title = st.text_input("Meeting Title", key="upload_title")
            
            # Project selection (use current project if available)
            if st.session_state.current_project:
                project_for_transcript = st.session_state.current_project["name"]
                st.info(f"Uploading for project: {project_for_transcript}")
            else:
                projects = ["Project Alpha", "Project Beta", "Project Gamma"]
                project_for_transcript = st.selectbox("Project", projects, key="upload_project")
        
        with col2:
            meeting_date = st.date_input("Meeting Date")
            participants = st.text_input("Participants (comma-separated)", key="upload_participants")
        
        transcript_text = st.text_area("Paste transcript text here", height=200)
        
        if st.button("Process Transcript") and transcript_text:
            # In a real implementation, this would process the transcript using the AI
            # For now, we'll just show a success message
            st.success("Transcript processed successfully!")
            
            # This would use the manual ingestion service in a real implementation
            if st.session_state.manual_ingestion_service:
                project_id = st.session_state.current_project["id"] if st.session_state.current_project else None
                
                # Create metadata
                metadata = {
                    "title": meeting_title,
                    "date": meeting_date.isoformat(),
                    "participants": participants,
                    "project_id": project_id
                }
                
                st.info("In a real implementation, this would process the transcript using the manual ingestion service.")

def documents_page():
    """Display the documents page."""
    st.markdown('<div class="main-header">Documents</div>', unsafe_allow_html=True)
    
    # Tabs for different document functions
    tab1, tab2 = st.tabs(["Document Library", "Upload Document"])
    
    with tab1:
        # Document library
        st.markdown('<div class="section-header">Document Library</div>', unsafe_allow_html=True)
        
        # Filter by project if one is selected
        if st.session_state.current_project:
            st.info(f"Showing documents for {st.session_state.current_project['name']}")
        
        # In a real application, we would fetch documents from the database
        # For now, we'll use placeholder data
        documents = [
            {"date": "2025-03-15", "title": "Project Plan", "type": "PDF", "size": "2.4 MB", "project": "Project Alpha"},
            {"date": "2025-03-10", "title": "Requirements Specification", "type": "DOCX", "size": "1.8 MB", "project": "Project Beta"},
            {"date": "2025-03-05", "title": "Design Document", "type": "PDF", "size": "3.2 MB", "project": "Project Alpha"},
            {"date": "2025-02-28", "title": "API Documentation", "type": "HTML", "size": "1.1 MB", "project": "Project Gamma"},
            {"date": "2025-02-20", "title": "Test Plan", "type": "DOCX", "size": "1.5 MB", "project": "Project Beta"}
        ]
        
        # Filter by project if one is selected
        if st.session_state.current_project:
            documents = [d for d in documents if d["project"] == st.session_state.current_project["name"]]
        
        if not documents:
            st.info("No documents found for the selected project.")
        else:
            for document in documents:
                with st.expander(f"{document['date']} - {document['title']} ({document['project']})"):
                    col1, col2, col3 = st.columns(3)
                    col1.write(f"**Type:** {document['type']}")
                    col2.write(f"**Size:** {document['size']}")
                    col3.write(f"**Project:** {document['project']}")
                    
                    st.markdown("### Summary")
                    st.write("This is a placeholder for the document summary.")
                    
                    st.markdown("### Key Points")
                    st.write("- Key point 1")
                    st.write("- Key point 2")
                    st.write("- Key point 3")
                    
                    st.button("View Document", key=f"view_{document['date']}_{document['title']}")
    
    with tab2:
        # Upload document
        st.markdown('<div class="section-header">Upload Document</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Upload a document for analysis.
        The AI will extract key information, generate a summary, and identify action items.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            document_title = st.text_input("Document Title")
            
            # Project selection (use current project if available)
            if st.session_state.current_project:
                project_for_document = st.session_state.current_project["name"]
                st.info(f"Uploading for project: {project_for_document}")
            else:
                projects = ["Project Alpha", "Project Beta", "Project Gamma"]
                project_for_document = st.selectbox("Project", projects)
        
        with col2:
            document_type = st.selectbox("Document Type", ["Project Plan", "Requirements", "Design", "API Documentation", "Test Plan", "Other"])
            document_date = st.date_input("Document Date")
        
        document_text = st.text_area("Paste document text here", height=200)
        
        if st.button("Process Document") and document_text:
            # In a real implementation, this would process the document using the AI
            # For now, we'll just show a success message
            st.success("Document processed successfully!")
            
            # This would use the manual ingestion service in a real implementation
            if st.session_state.manual_ingestion_service:
                project_id = st.session_state.current_project["id"] if st.session_state.current_project else None
                
                # Create metadata
                metadata = {
                    "title": document_title,
                    "date": document_date.isoformat(),
                    "type": document_type,
                    "project_id": project_id
                }
                
                st.info("In a real implementation, this would process the document using the manual ingestion service.")

def text_ingestion_page():
    """Display the text ingestion page."""
    st.markdown('<div class="main-header">Text Ingestion</div>', unsafe_allow_html=True)
    
    st.markdown("""
    This page allows you to manually ingest text from various sources such as chat conversations, emails, or notes.
    The AI will analyze the text to extract action items, key points, and other relevant information.
    """)
    
    # Tabs for different ingestion types
    tab1, tab2, tab3 = st.tabs(["Chat Text", "Notes", "Image Upload"])
    
    with tab1:
        # Chat text ingestion
        st.markdown('<div class="section-header">Chat Text Ingestion</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Paste text from chat conversations to extract action items and key information.
        """)
        
        # Project selection (use current project if available)
        if st.session_state.current_project:
            project_for_chat = st.session_state.current_project["name"]
            project_id = st.session_state.current_project["id"]
            st.info(f"Ingesting for project: {project_for_chat}")
        else:
            projects = ["Project Alpha", "Project Beta", "Project Gamma"]
            project_for_chat = st.selectbox("Project", projects)
            project_id = {"Project Alpha": "1", "Project Beta": "2", "Project Gamma": "3"}.get(project_for_chat)
        
        chat_source = st.text_input("Source (e.g., Slack, Teams, Email)")
        chat_text = st.text_area("Paste chat text here", height=200)
        
        if st.button("Process Chat Text") and chat_text:
            # In a real implementation, this would process the chat text using the manual ingestion service
            if st.session_state.manual_ingestion_service:
                # Create metadata
                metadata = {
                    "source": chat_source,
                    "timestamp": datetime.now().isoformat()
                }
                
                with st.spinner("Processing chat text..."):
                    # This would actually call the service in a real implementation
                    st.success("Chat text processed successfully!")
                    st.info("In a real implementation, this would extract action items and key information.")
                    
                    # Show extracted action items (placeholder)
                    st.markdown("### Extracted Action Items")
                    st.write("- Action item 1")
                    st.write("- Action item 2")
                    st.write("- Action item 3")
                    
                    if st.button("Add Action Items"):
                        st.success("Action items added successfully!")
    
    with tab2:
        # Notes ingestion
        st.markdown('<div class="section-header">Notes Ingestion</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Paste notes from meetings, brainstorming sessions, or other sources to extract action items and key information.
        """)
        
        # Project selection (use current project if available)
        if st.session_state.current_project:
            project_for_notes = st.session_state.current_project["name"]
            project_id = st.session_state.current_project["id"]
            st.info(f"Ingesting for project: {project_for_notes}")
        else:
            projects = ["Project Alpha", "Project Beta", "Project Gamma"]
            project_for_notes = st.selectbox("Project", projects, key="notes_project")
            project_id = {"Project Alpha": "1", "Project Beta": "2", "Project Gamma": "3"}.get(project_for_notes)
        
        notes_title = st.text_input("Notes Title")
        notes_text = st.text_area("Paste notes here", height=200)
        
        if st.button("Process Notes") and notes_text:
            # In a real implementation, this would process the notes using the manual ingestion service
            if st.session_state.manual_ingestion_service:
                # Create metadata
                metadata = {
                    "title": notes_title,
                    "timestamp": datetime.now().isoformat()
                }
                
                with st.spinner("Processing notes..."):
                    # This would actually call the service in a real implementation
                    st.success("Notes processed successfully!")
                    st.info("In a real implementation, this would extract action items and key information.")
                    
                    # Show extracted action items (placeholder)
                    st.markdown("### Extracted Action Items")
                    st.write("- Action item 1")
                    st.write("- Action item 2")
                    st.write("- Action item 3")
                    
                    if st.button("Add Action Items", key="notes_add"):
                        st.success("Action items added successfully!")
    
    with tab3:
        # Image upload
        st.markdown('<div class="section-header">Image Upload</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Upload images of whiteboards, notes, or documents to extract text and action items.
        """)
        
        # Project selection (use current project if available)
        if st.session_state.current_project:
            project_for_image = st.session_state.current_project["name"]
            project_id = st.session_state.current_project["id"]
            st.info(f"Ingesting for project: {project_for_image}")
        else:
            projects = ["Project Alpha", "Project Beta", "Project Gamma"]
            project_for_image = st.selectbox("Project", projects, key="image_project")
            project_id = {"Project Alpha": "1", "Project Beta": "2", "Project Gamma": "3"}.get(project_for_image)
        
        image_title = st.text_input("Image Title")
        image_file = st.file_uploader("Upload Image", type=["jpg", "jpeg", "png"])
        
        if st.button("Process Image") and image_file:
            # In a real implementation, this would process the image using the manual ingestion service
            st.image(image_file, caption=image_title, use_column_width=True)
            st.success("Image uploaded successfully!")
            st.info("In a real implementation, this would extract text and action items from the image.")

def ai_assistant_page():
    """Display the AI assistant page."""
    st.markdown('<div class="main-header">AI Assistant</div>', unsafe_allow_html=True)
    
    st.markdown("""
    Ask questions about your projects, meetings, documents, or any other information.
    The AI assistant will use the context from your data to provide relevant answers.
    """)
    
    # Initialize chat history if not exists
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    
    # Display chat history
    for message in st.session_state.chat_history:
        if message["role"] == "user":
            st.markdown(f'<div style="background-color: #e9f5ff; padding: 10px; border-radius: 5px; margin-bottom: 10px;"><strong>You:</strong> {message["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div style="background-color: #f0f0f0; padding: 10px; border-radius: 5px; margin-bottom: 10px;"><strong>AI:</strong> {message["content"]}</div>', unsafe_allow_html=True)
    
    # User input
    user_input = st.text_input("Ask a question")
    
    if st.button("Send") and user_input:
        # Add user message to chat history
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        
        # In a real implementation, this would use the AI assistant to generate a response
        if st.session_state.ai_assistant:
            with st.spinner("Thinking..."):
                # This would actually call the AI assistant in a real implementation
                # For now, we'll just use a placeholder response
                response = "This is a placeholder response. In a real implementation, this would use the AI assistant to generate a response based on your question and the context from your data."
                
                # Add AI response to chat history
                st.session_state.chat_history.append({"role": "assistant", "content": response})
                
                st.rerun()

# Main application
def main():
    """Main application function."""
    if not st.session_state.authenticated:
        login_page()
    else:
        page = sidebar()
        
        if page == "Dashboard":
            dashboard_page()
        elif page == "Projects":
            projects_page()
        elif page == "Meetings":
            meetings_page()
        elif page == "Documents":
            documents_page()
        elif page == "Action Items":
            # Use the current project ID if available
            project_id = st.session_state.current_project["id"] if st.session_state.current_project else None
            action_items_page(project_id)
        elif page == "Text Ingestion":
            text_ingestion_page()
        elif page == "AI Assistant":
            ai_assistant_page()

if __name__ == "__main__":
    main()
