"""
Frontend package for the Personal Project Assistant.
This package contains modules for the user interface.
"""

# Import page components
from .action_items_page import action_items_page
