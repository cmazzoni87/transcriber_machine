"""
Action items page for the Personal Project Assistant.
This module provides the UI for managing action items.
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import json
import os

# Import manual ingestion components
from ..integrations.manual_ingestion.action_item_manager import ActionItemManager

def action_items_page(project_id=None):
    """Display the action items management page."""
    st.markdown('<div class="main-header">Action Items</div>', unsafe_allow_html=True)
    
    # Initialize action item manager
    action_manager = ActionItemManager()
    
    # Create tabs for different views
    tab1, tab2, tab3 = st.tabs(["All Action Items", "Add New Item", "Import from Text"])
    
    with tab1:
        # Action items list
        st.markdown('<div class="section-header">Action Items</div>', unsafe_allow_html=True)
        
        # Filter controls
        col1, col2, col3 = st.columns(3)
        with col1:
            filter_project = st.checkbox("Filter by current project", value=True if project_id else False)
        with col2:
            show_completed = st.checkbox("Show completed items", value=False)
        with col3:
            sort_by = st.selectbox("Sort by", ["Due Date", "Priority", "Created Date"])
        
        # Get action items based on filters
        if filter_project and project_id:
            action_items = action_manager.get_action_items(project_id=project_id, completed=show_completed)
        else:
            action_items = action_manager.get_action_items(completed=show_completed)
        
        # Sort action items
        if sort_by == "Due Date":
            action_items.sort(key=lambda x: x.get("due_date", "9999-12-31"))
        elif sort_by == "Priority":
            priority_order = {"high": 0, "medium": 1, "low": 2}
            action_items.sort(key=lambda x: priority_order.get(x.get("priority", "medium"), 1))
        else:  # Created Date
            action_items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        
        if not action_items:
            st.info("No action items found. Add some using the 'Add New Item' tab.")
        else:
            # Display action items in an interactive table
            for i, item in enumerate(action_items):
                with st.container():
                    col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
                    
                    with col1:
                        task_text = item.get("task", "")
                        if item.get("completed", False):
                            task_text = f"~~{task_text}~~"
                        st.markdown(f"**{task_text}**")
                        if item.get("notes"):
                            st.markdown(f"*{item.get('notes')}*")
                    
                    with col2:
                        if item.get("assignee"):
                            st.write(f"Assignee: {item.get('assignee')}")
                        if item.get("due_date"):
                            st.write(f"Due: {item.get('due_date')}")
                    
                    with col3:
                        priority = item.get("priority", "medium")
                        priority_color = {
                            "high": "🔴",
                            "medium": "🟠",
                            "low": "🟢"
                        }.get(priority, "🟠")
                        st.write(f"{priority_color} {priority.capitalize()}")
                    
                    with col4:
                        # Action buttons
                        col4_1, col4_2 = st.columns(2)
                        with col4_1:
                            if item.get("completed", False):
                                if st.button("Undo", key=f"undo_{i}"):
                                    action_manager.uncomplete_action_item(item.get("id"))
                                    st.rerun()
                            else:
                                if st.button("Done", key=f"done_{i}"):
                                    action_manager.complete_action_item(item.get("id"))
                                    st.rerun()
                        with col4_2:
                            if st.button("Delete", key=f"delete_{i}"):
                                action_manager.delete_action_item(item.get("id"))
                                st.rerun()
                    
                    # Edit button and form
                    if st.button("Edit", key=f"edit_{i}"):
                        st.session_state[f"edit_item_{i}"] = True
                    
                    if st.session_state.get(f"edit_item_{i}", False):
                        with st.form(key=f"edit_form_{i}"):
                            edit_task = st.text_input("Task", value=item.get("task", ""))
                            edit_notes = st.text_area("Notes", value=item.get("notes", ""))
                            
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                edit_assignee = st.text_input("Assignee", value=item.get("assignee", ""))
                            with col2:
                                edit_due_date = st.date_input("Due Date", 
                                                            value=datetime.strptime(item.get("due_date", datetime.now().strftime("%Y-%m-%d")), "%Y-%m-%d") if item.get("due_date") else datetime.now())
                            with col3:
                                edit_priority = st.selectbox("Priority", ["high", "medium", "low"], 
                                                            index=["high", "medium", "low"].index(item.get("priority", "medium")))
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.form_submit_button("Save Changes"):
                                    action_manager.update_action_item(
                                        item_id=item.get("id"),
                                        task=edit_task,
                                        notes=edit_notes,
                                        assignee=edit_assignee,
                                        due_date=edit_due_date.strftime("%Y-%m-%d"),
                                        priority=edit_priority
                                    )
                                    st.session_state[f"edit_item_{i}"] = False
                                    st.rerun()
                            with col2:
                                if st.form_submit_button("Cancel"):
                                    st.session_state[f"edit_item_{i}"] = False
                                    st.rerun()
                
                st.markdown("---")
    
    with tab2:
        # Add new action item form
        st.markdown('<div class="section-header">Add New Action Item</div>', unsafe_allow_html=True)
        
        with st.form(key="add_item_form"):
            new_task = st.text_input("Task")
            new_notes = st.text_area("Notes")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                new_assignee = st.text_input("Assignee")
            with col2:
                new_due_date = st.date_input("Due Date", value=datetime.now() + timedelta(days=7))
            with col3:
                new_priority = st.selectbox("Priority", ["high", "medium", "low"], index=1)
            
            # Use current project if available
            if project_id:
                st.info(f"This item will be associated with the current project.")
            
            if st.form_submit_button("Add Action Item"):
                if new_task:
                    action_manager.create_action_item(
                        task=new_task,
                        notes=new_notes,
                        assignee=new_assignee,
                        due_date=new_due_date.strftime("%Y-%m-%d"),
                        priority=new_priority,
                        project_id=project_id
                    )
                    st.success("Action item added successfully!")
                    st.rerun()
                else:
                    st.error("Task description is required.")
    
    with tab3:
        # Import action items from text
        st.markdown('<div class="section-header">Import from Text</div>', unsafe_allow_html=True)
        
        st.markdown("""
        Paste text from chat conversations, meeting transcripts, or other sources to automatically extract action items.
        The AI will analyze the text and identify potential action items.
        """)
        
        import_text = st.text_area("Paste text here", height=200)
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Extract Action Items") and import_text:
                # Initialize AI components
                from ...ai.bedrock_ai import BedrockAI
                bedrock_ai = BedrockAI()
                
                with st.spinner("Analyzing text and extracting action items..."):
                    # Extract action items using AI
                    extracted_items = bedrock_ai.extract_action_items(import_text)
                    
                    if extracted_items:
                        st.session_state.extracted_items = extracted_items
                        st.success(f"Found {len(extracted_items)} potential action items!")
                    else:
                        st.warning("No action items found in the text.")
        
        with col2:
            if st.button("Clear") and import_text:
                st.session_state.extracted_items = []
                st.rerun()
        
        # Display extracted items
        if hasattr(st.session_state, 'extracted_items') and st.session_state.extracted_items:
            st.markdown("### Extracted Action Items")
            st.markdown("Review the extracted items and select which ones to add:")
            
            for i, item in enumerate(st.session_state.extracted_items):
                col1, col2 = st.columns([4, 1])
                with col1:
                    st.markdown(f"**{item.get('task', '')}**")
                    if item.get('assignee'):
                        st.markdown(f"Assignee: {item.get('assignee')}")
                    if item.get('deadline'):
                        st.markdown(f"Due: {item.get('deadline')}")
                    if item.get('priority'):
                        st.markdown(f"Priority: {item.get('priority')}")
                
                with col2:
                    if st.button("Add", key=f"add_extracted_{i}"):
                        action_manager.create_action_item(
                            task=item.get('task', ''),
                            assignee=item.get('assignee'),
                            due_date=item.get('deadline'),
                            priority=item.get('priority', 'medium'),
                            project_id=project_id
                        )
                        st.success(f"Added: {item.get('task', '')}")
            
            if st.button("Add All Items"):
                action_manager.create_action_items_from_list(
                    st.session_state.extracted_items,
                    project_id=project_id
                )
                st.success("All items added successfully!")
                st.session_state.extracted_items = []
                st.rerun()
